$(function () {
   
	$(".del").click(function () {
            $(".mask").show();
            $(".tipDel").show();

            var url = "cartshopdel?esid="+$(this).attr('datasrc');
            $.get(url, function(data){});
            index = $(this).parents(".th").index() - 1;
            $(".cer").click(function () {
                $(".mask").hide();
                $(".tipDel").hide();
                $(".th").eq(index).remove();
                $(".cer").off("click");
                if ($(".th").length == 0) {
                    $(".table .goOn").show()
                }
            })
    });
    $(".cancel").click(function () {
        $(".mask").hide();
        $(".tipDel").hide()
    })
});