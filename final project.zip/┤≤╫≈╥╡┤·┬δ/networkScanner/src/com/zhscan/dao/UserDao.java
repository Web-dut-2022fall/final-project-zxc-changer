package com.zhscan.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.zhscan.entity.User;
import com.zhscan.util.AESUtils;
import com.zhscan.util.DataSourceUtils;

public class UserDao {
	private final static String key="f575da863df24770";
	
	public static String getKey() {
		return key;
	}
	
	//根据用户名与密码查找用户
			public User findUserByUsernameAndPassword(String userName, String userPass) throws SQLException {
				String sql="select * from user where userName=? and userPass=?";
				QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
				User u =findUserByUserName(userName);
				return runner.query(sql, new BeanHandler<User>(User.class),userName, AESUtils.encryptData(key, userPass));
			}
			
	//根据电话与密码查找用户
			public User findUserByPhoneAndPassword(String phoneNum, String userPass) throws SQLException {
				String sql="select * from user where phoneNum=? and userPass=?";
				QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
				User u =findUserByUserPhone(phoneNum);
				return runner.query(sql, new BeanHandler<User>(User.class),phoneNum,AESUtils.encryptData(key, userPass));
			}
		
			
			public User findUserByUserName(String userName) throws SQLException {
				String sql="select * from user where userName=?";
				QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
				return runner.query(sql, new BeanHandler<User>(User.class),userName);
			}
			
			public User findUserByUserPhone (String phoneNum) throws SQLException {
				String sql="select * from user where phoneNum=?";
				QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
				return runner.query(sql, new BeanHandler<User>(User.class),phoneNum);
			}
			
			//添加新用户
	public void addUser(User user) throws SQLException {
		  String sql =
		  "insert into user(userName,userPass,userRole,phoneNum, email) values(?,?,?,?,?)" ; 
		  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql,user.getUserName(), AESUtils.encryptData(key, user.getUserPass()), user.getUserRole(), user.getPhoneNum(), user.getEmail());
		  if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
	
	//修改用户信息
	public void updateUser(User user, int userID) throws SQLException {
		  String sql =
				  "update user set  userName=?,  phoneNum=?,  email=? where userID=?"  ; 
		  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, user.getUserName(),  user.getPhoneNum(), user.getEmail(), userID);
		  if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
	
	//修改用户密码
	public String updateUserPass(String newPass, int userID) throws SQLException {
		  String sql =
				  "update user set  userPass=? where userID=?"  ; 
		  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		   runner.update(sql, AESUtils.encryptData(key, newPass), userID);
		  return key;
		 
	}
	
	//根据ID删除用户
	public void delUser(String userID) throws SQLException {
		 String sql =
				  "delete from user where userID=?" ; 
		 QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		 int row = runner.update(sql, userID);
		  if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
	
	//显示所有用户
	public List<User> listAllUsers() throws SQLException {
		 String sql =
				  "select * from user" ; 
		 QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <User>(User.class));
	}
	
	//根据ID修改用户权限
	
	public void updateUserRole(int userRole, int userID) throws SQLException {
		  String sql =
				  "update user set  userRole=? where userID=?" ; 
		  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, userRole,  userID);
		  if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
	
	  //根据userID查询用户 
	public User findUserById(int userID) throws SQLException {
	  String sql = "select * from user where userID=?" ; 
	  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
	  return runner.query(sql, new BeanHandler<User>(User.class),userID); }
	 
}
