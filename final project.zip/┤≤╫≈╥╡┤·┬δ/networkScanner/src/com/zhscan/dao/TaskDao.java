package com.zhscan.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.zhscan.entity.Host;
import com.zhscan.entity.Host_Task_User;
import com.zhscan.entity.Port;
import com.zhscan.entity.Port_Task_User;
import com.zhscan.entity.Task;
import com.zhscan.entity.Task_User;
import com.zhscan.entity.Vul;
import com.zhscan.entity.Vul_Task_User;
import com.zhscan.util.DataSourceUtils;

public class TaskDao {
	
	//根据用户ID查找该用户添加的所有任务
	public List<Task> findTaskByUserID(int userID) throws SQLException {
		String sql="select * from task where userID=? ";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Task>(Task.class),userID);
	}
	
	//根据用户姓名模糊查找该用户添加的所有任务
		public List<Task> findTaskByUserName(String userName) throws SQLException {
			String sql="select * from task t inner join user u on t.userID=u.userID  where u.userName like '%"+userName+"%' ";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Task>(Task.class));
		}
		
		//根据用户姓名模糊查找该用户添加的所有任务
				public List<Task> findTaskByUserNameAndState(String userName, int taskState) throws SQLException {
					String sql="select * from task t inner join user u on t.userID=u.userID  where u.userName like '%"+userName+"%' and t.taskState=?";
					QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
					return runner.query(sql, new  BeanListHandler <Task>(Task.class), taskState);
				}
				
				//根据用户姓名模糊查找该用户添加的所有任务
				public List<Task> findTaskByUserNameAndType(String userName, int taskType) throws SQLException {
					String sql="select * from task t inner join user u on t.userID=u.userID  where u.userName like '%"+userName+"%' and t.taskType=?";
					QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
					return runner.query(sql, new  BeanListHandler <Task>(Task.class), taskType);
				}
		
		//根据用户名、任务类型、任务状态查找扫描任务
		public List<Task> findTaskByUserNameAndTypeAndState(String userName, int taskType, int taskState) throws SQLException {
			String sql="select * from task t inner join user u on t.userID=u.userID where u.userName like '%"+userName+"%' and t.taskType=? and t.taskState=?";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Task>(Task.class), taskType, taskState);
		}
		
	
	  //根据任务类型查找该类型的所有任务
		public List<Task> findTaskByType(int taskType) throws SQLException {
			String sql="select * from task where taskType=? "; 
	  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
	  return  runner.query(sql, new BeanListHandler <Task>(Task.class), taskType);
	  }
	 
		public List<Task> findTaskByStateAndType(int taskState, int taskType) throws SQLException{
			String sql="select * from task where taskState=? and taskType=? "; 
			  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
			  return  runner.query(sql, new BeanListHandler <Task>(Task.class), taskState, taskType);
		}
	
	//根据任务状态查找任务
	public List<Task> findTaskByState(int taskState) throws SQLException {
		String sql="select * from task where taskState=? ";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Task>(Task.class), taskState);
	}
	
	//根据用户ID和任务状态查找该用户添加的所有任务
	public List<Task> findTaskByUserIDAndState(int userID, int taskState) throws SQLException{
		String sql="select * from task where userID=? and taskState=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Task>(Task.class),userID, taskState);
	}
		
	public List<Task> findTaskByUserIDAndStateAndType(int userID ,int  taskState, int taskType) throws SQLException{
		String sql="select * from task where userID=? and taskState=? and taskType=? ";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Task>(Task.class),userID, taskState, taskType);
	}
	
	public List<Task> findTaskByUserIDAndType(int userID , int taskType) throws SQLException{
		String sql="select * from task where userID=? and taskType=? ";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Task>(Task.class),userID, taskType);
	}
	

	//列举所有用户的所有任务
	public List<Task> listAllTasks() throws SQLException{
		String sql = "select * from task ";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Task>(Task.class));
	}
	
	//根据任务ID连表查询
	public Task_User findTaskByTaskID (int taskID) throws SQLException {
		String sql = "select t.taskID, t.taskName,t.taskState,t.taskType,t.beginIP, t.endIP, t.beginPort, t.endPort,t.destHostIP, t.userID, u.userName "
				+ " from task t "
				+ " inner join user u on t.userID=u.userID"
				+ " where t.taskID =?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanHandler <Task_User>(Task_User.class), taskID);
	}
	
	//增加新任务
	public int addTask(Task task) throws SQLException {
		  String sql =
				  "insert into task(taskName,taskState,taskType,beginIP, endIP, beginPort, endPort,destHostIP, userID) values(?,?,?,?,?,?,?,?,?)" ; 
		  String sql2="select @@identity";

				  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
				  int row = runner.update(sql,task.getTaskName(), task.getTaskState(), task.getTaskType(), task.getBeginIP(), task.getEndIP(),  task.getBeginPort(),task.getEndPort(), task.getDestHostIP(),task.getUserID());
				  Number num=   runner.query(sql2, new ScalarHandler<>());
				  System.out.println(num);
				  int id=num.intValue();
				  
				  System.out.println(id);
		/*
		 * if (row == 0) { throw new RuntimeException(); }
		 */
				  return id;
	}
	
	//更新任务信息
	public void updateTask(Task newTask, int taskID) throws SQLException {
		String sql="update task set taskName=?, taskState=?, taskType=?, beginIP=?, endIP=?, beginPort=?, endPort=?, destHostIP=? where taskID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql,newTask.getTaskName(), newTask.getTaskState(), newTask.getTaskType(), newTask.getBeginIP(), newTask.getEndIP(),  newTask.getBeginPort(),newTask.getEndPort(), newTask.getDestHostIP(),taskID);
		/*
		 * if (row == 0) { throw new RuntimeException(); }
		 */
	}
	
	//任务启动或完成后更新任务状态
	public void updateTaskState(int taskState, int taskID) throws SQLException {
		String sql="update task set taskState=? where taskID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, taskState, taskID);
		/*
		 * if (row == 0) { throw new RuntimeException(); }
		 */
	}
	
	
	//根据任务ID删除任务
	public void delTask(int taskID) throws SQLException {
		String sql="delete from task where taskID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, taskID);
		
		  if (row == 0) { throw new RuntimeException(); }
		 
	}
	
	
	//添加主机扫描结果
	public void addHostResult(Host host) throws SQLException {
		String sql=  "insert into host(hostIP, hostName, hostMAC, responseTime, taskID,userID) values(?,?,?,?,?,?)" ; 
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, host.getHostIP(), host.getHostName(), host.getHostMAC(),host.getResponseTime(), host.getTaskID(),host.getUserID());
		/*
		 * if (row == 0) { throw new RuntimeException(); }
		 */
	}
	
	//添加端口扫描结果
	public void addPortResult(Port port) throws SQLException {
		String sql=  "insert into port(destHostIP, openPort, resTime, taskID,userID) values(?,?,?,?,?)" ; 
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, port.getDestHostIP(), port.getOpenPort(), port.getResTime(),  port.getTaskID(),  port.getUserID());
		  if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
	
	//显示所有主机扫描结果
	public List<Host_Task_User> listAllHostResults() throws SQLException {
		String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime, t.taskName, u.userName from host h "
				+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
	}
	
	
	//根据用户名模糊查询所有主机扫描结果
	public List<Host_Task_User> listHostResultsByUserName(String userName) throws SQLException {
		String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime, t.taskName, u.userName from host h "
				+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where u.userName like '%"+userName+"%'";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
	}
	
	//根据用户名模糊查询所有端口扫描结果
		public List<Port_Task_User> listPortResultsByUserName(String userName) throws SQLException {
			String sql ="select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName , i.portType, i.portDesp from port p "
					+ "inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where u.userName like '%"+userName+"%' ";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
		}
		
		//根据用户名模糊查询所有漏洞扫描结果
		public List<Vul_Task_User> listVulResultsByUserName(String userName) throws SQLException {
			String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
					+ "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where u.userName like '%"+userName+"%' ";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
		}
	
		
	public List<Host_Task_User> listHostResultsByUserID(int userid) throws SQLException{
		String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
				+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where u.userid=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class),userid);
	}
	
	//显示所有端口扫描结果
	public List<Port> listAllPortResult() throws SQLException {
		String sql = "select * from port ";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Port>(Port.class));
	}

	public List<Port_Task_User> listPortResultsByUserID(int userid)throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName , i.portType, i.portDesp from port p "
				+ "inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where u.userid=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class),userid);
	}
	
	
	public List<Port_Task_User> listAllPortResults()  throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p "
				+ "inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	
	
	public List<Vul_Task_User> listAllVulResults() throws SQLException{
		String sql = "select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
				+ "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID ";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
	}
	
	public List<Vul_Task_User> listVulResultsByUserID(int userid) throws SQLException{
		String sql = "select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
				+ "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where u.userid=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class),userid);
	}

	
	public void delHostResult(int hostResultID)  throws SQLException{
		String sql="delete from host where hostResultID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  runner.update(sql, hostResultID);
	}
	
	public void delPortResult(int portResultID)  throws SQLException{
		String sql="delete from port where portResultID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  runner.update(sql, portResultID);
	}
	
	public void delVulResult(int vulResultID) throws SQLException{
		String sql="delete from vul where vulID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  runner.update(sql, vulResultID);
	}
	
	public Host  findHostByHostResultID(long resultID)throws SQLException{
		String sql = "select * from host where hostResultID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanHandler <Host>(Host.class),resultID);
	}

	public void addVulResult(Vul v) throws SQLException{
		String sql=  "insert into vul(vulName, vulDesp, vulResultTime, taskID,userID) values(?,?,?,?,?)" ; 
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, v.getVulName(), v.getVulDesp(),v.getVulResultTime(), v.getTaskID(),v.getUserID());
		/*
		 * if (row == 0) { throw new RuntimeException(); }
		 */
	}
	
	public  List<Host_Task_User> listHostResultsByUserNameAndTime0(String userName) throws SQLException{
		String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
				+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where u.userName like '%"+userName+"%' and to_days(h.resultTime) = to_days(now())";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
	}
	
	public  List<Host_Task_User> listHostResultsByUserNameAndTime1(String userName) throws SQLException{
		String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
				+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where u.userName like '%"+userName+"%' and TO_DAYS( NOW( ) ) - TO_DAYS(h.resultTime) <= 1";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
	}
	
	public  List<Host_Task_User> listHostResultsByUserNameAndTime2(String userName) throws SQLException{
		String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
				+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where u.userName like '%"+userName+"%' and DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(h.resultTime)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
	}
	
	public  List<Host_Task_User> listHostResultsByUserNameAndTime3(String userName) throws SQLException{
		String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
				+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where u.userName like '%"+userName+"%' DATE_SUB(CURDATE(), INTERVAL 30 DAY) <= date(h.resultTime)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
	}
	
	public  List<Port_Task_User> listPortResultsByUserNameAndTime0 (String userName) throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p " + 
				 "inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where u.userName like '%"+userName+"%' and  to_days(p.portResultTime) = to_days(now())";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	
	public  List<Port_Task_User> listPortResultsByUserNameAndTime1 (String userName) throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p " + 
				"inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where u.userName like '%"+userName+"%' and TO_DAYS( NOW( ) ) - TO_DAYS(p.portResultTime) <= 1";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	
	public  List<Port_Task_User> listPortResultsByUserNameAndTime2 (String userName) throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p " + 
				"inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where u.userName like '%"+userName+"%' and DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(p.portResultTime)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	
	public  List<Port_Task_User> listPortResultsByUserNameAndTime3 (String userName) throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p " + 
			"inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where u.userName like '%"+userName+"%' and DATE_SUB(CURDATE(), INTERVAL 30 DAY) <= date(p.portResultTime)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	
	public  List<Vul_Task_User> listVulResultsByUserNameAndTime0 (String userName) throws SQLException{
		String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
	        + "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where u.userName like '%"+userName+"%' and  to_days(v.vulResultTime) = to_days(now())";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
	}
	
	public  List<Vul_Task_User> listVulResultsByUserNameAndTime1 (String userName) throws SQLException{
		String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
	        + "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where u.userName like '%"+userName+"%' and TO_DAYS( NOW( ) ) - TO_DAYS(v.vulResultTime) <= 1";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
	}
	public  List<Vul_Task_User> listVulResultsByUserNameAndTime2 (String userName) throws SQLException{
		String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
	        + "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where u.userName like '%"+userName+"%' and DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(v.vulResultTime)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
	}
	public  List<Vul_Task_User> listVulResultsByUserNameAndTime3 (String userName) throws SQLException{
		String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
	        + "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where u.userName like '%"+userName+"%' and DATE_SUB(CURDATE(), INTERVAL 30 DAY) <= date(v.vulResultTime)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
	}
	
	public List<Host_Task_User> listHostResultsByTime0() throws SQLException{
		String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
				+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where  to_days(h.resultTime) = to_days(now())";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
	}
public List<Host_Task_User> listHostResultsByTime1() throws SQLException{
	String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
			+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where TO_DAYS( NOW( ) ) - TO_DAYS(h.resultTime) <= 1";
	QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
	return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
	}
public List<Host_Task_User> listHostResultsByTime2() throws SQLException{
	String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
			+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(h.resultTime)";
	QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
	return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
}
public List<Host_Task_User> listHostResultsByTime3() throws SQLException{
	String sql = "select h.hostResultID, h.hostIP, h.hostName, h.hostMAC, h.responseTime, h.resultTime,  t.taskName, u.userName from host h "
			+ "inner join user u on h.userID=u.userID inner join task t on t.taskID=h.taskID where  DATE_SUB(CURDATE(), INTERVAL 30 DAY) <= date(h.resultTime)";
	QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
	return runner.query(sql, new  BeanListHandler <Host_Task_User>(Host_Task_User.class));
}
	
	public List<Port_Task_User> listPortResultsByTime0() throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p " + 
				"inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where  to_days(p.portResultTime) = to_days(now())";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	public List<Port_Task_User> listPortResultsByTime1() throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p " + 
				"inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where TO_DAYS( NOW( ) ) - TO_DAYS(p.portResultTime) <= 1";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	public List<Port_Task_User> listPortResultsByTime2() throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p " + 
				"inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(p.portResultTime)";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	public List<Port_Task_User> listPortResultsByTime3() throws SQLException{
		String sql = "select p.portResultID, p.destHostIP, p.openPort, p.resTime, p.portResultTime,  t.taskName, u.userName, i.portType, i.portDesp from port p " + 
				"inner join user u on p.userID=u.userID inner join task t on t.taskID=p.taskID left join portinfo i on p.openPort=i.portID where  DATE_SUB(CURDATE(), INTERVAL 30 DAY) <= date(p.portResultTime)";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Port_Task_User>(Port_Task_User.class));
	}
	
	
	public List<Vul_Task_User> listVulResultsByTime0() throws SQLException{
		String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
		        + "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where  to_days(v.vulResultTime) = to_days(now())";
			QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
			return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
	}
public List<Vul_Task_User> listVulResultsByTime1() throws SQLException{
	String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
	        + "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where TO_DAYS( NOW( ) ) - TO_DAYS(v.vulResultTime) <= 1";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
	}
public List<Vul_Task_User> listVulResultsByTime2() throws SQLException{
	String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
	        + "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(v.vulResultTime)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
}
public List<Vul_Task_User> listVulResultsByTime3() throws SQLException{
	String sql ="select v.vulID, v.vulName, v.vulDesp, v.vulResultTime,  t.taskName, u.userName from vul v "
	        + "inner join user u on v.userID=u.userID inner join task t on t.taskID=v.taskID where DATE_SUB(CURDATE(), INTERVAL 30 DAY) <= date(v.vulResultTime)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Vul_Task_User>(Vul_Task_User.class));
}
}
