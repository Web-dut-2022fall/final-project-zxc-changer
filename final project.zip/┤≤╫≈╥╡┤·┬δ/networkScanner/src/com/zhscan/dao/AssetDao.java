package com.zhscan.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.zhscan.entity.Asset;
import com.zhscan.entity.Asset_User;
import com.zhscan.util.DataSourceUtils;

public class AssetDao {
	public List<Asset_User> listAssetsByUserID(int userid)throws SQLException{
		String sql = "select a.assetID, a.assetName, a.assetIP, a.osType, u.userName from asset a "
				+ "inner join user u on a.userID=u.userID where u.userid=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Asset_User>(Asset_User.class),userid);
	}
	
	
	public List<Asset_User> listAllAssets()  throws SQLException{
		String sql = "select a.assetID, a.assetName, a.assetIP, a.osType, u.userName from asset a "
				+ "inner join user u on a.userID=u.userID";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Asset_User>(Asset_User.class));
	}
	
	public void delAsset(int assetID) throws SQLException {
		String sql="delete from asset where assetID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, assetID);
		/*
		 * if (row == 0) { throw new RuntimeException(); }
		 */
	}
	
	public Asset findAssetByID(int assetID) throws SQLException{
		
		String sql="select * from asset where assetID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		return runner.query(sql, new  BeanHandler <Asset>(Asset.class),assetID);
	}
	
	public void addAsset(Asset a) throws SQLException {
		String sql="insert into asset (assetName, assetIP, osType, userID) values(?,?,?,?)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql, a.getAssetName(), a.getAssetIP(), a.getOsType(), a.getUserID());
		
		  if (row == 0) { throw new RuntimeException(); }

	}
	
	public void updateAssetByIPAndUserID(String osType, String ip, int userid) throws SQLException {
		String sql="update asset set osType=?  where assetIP=? and userID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update( sql, osType, ip, userid);
		  if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
	
}
