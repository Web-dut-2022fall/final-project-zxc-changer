package com.zhscan.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.zhscan.entity.WeakPwd;
import com.zhscan.util.DataSourceUtils;

public class VulDao {
public WeakPwd findAssetByID(int weakPwdID) throws SQLException{
		
		String sql="select * from weakpwd where weakPwdID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		return runner.query(sql, new  BeanHandler <WeakPwd>(WeakPwd.class),weakPwdID);
	}


}
