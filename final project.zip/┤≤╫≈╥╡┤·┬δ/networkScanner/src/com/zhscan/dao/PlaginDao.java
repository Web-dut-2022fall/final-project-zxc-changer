package com.zhscan.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.zhscan.entity.Plagin;
import com.zhscan.util.DataSourceUtils;

public class PlaginDao {
	public List<Plagin> listAllPlagins() throws SQLException{
		String sql = "select * from plagin";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Plagin>(Plagin.class));
	}
	
	public List<Plagin> listPlaginByUserID(int userid)throws SQLException{
		String sql = "select * from plagin p where p.userID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanListHandler <Plagin>(Plagin.class), userid);
	}
	
	public Plagin findPlaginByNameAndUserID(String plaginname, int userid)throws SQLException {
		String sql = "select * from plagin  where plaginName=? and userID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		return runner.query(sql, new  BeanHandler <Plagin>(Plagin.class), plaginname, userid);
	}
	
	
	  public Plagin findPlaginByPlaginID(int plaginid) throws SQLException{ String
	  sql = "select * from plagin  where plaginID=?"; QueryRunner runner = new
	  QueryRunner(DataSourceUtils.getDataSource()); return runner.query(sql, new
	  BeanHandler <Plagin>(Plagin.class), plaginid); }
	 
	
	public void addPlagin(Plagin p) throws SQLException {
		 String sql =
				  "insert into plagin(plaginName, plaginPath, config, userID) values(?,?,?,?)" ; 
		  QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		  int row = runner.update(sql,p.getPlaginName(), p.getPlaginPath(), p.getConfig(), p.getUserID());
		  if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
	
	public void delPlagin(int plaginID) throws SQLException{
		String sql = "delete from plagin where plaginID=?" ; 
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		int row  = runner.update(sql, plaginID);
		if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
	
	public void modifyInfo(Plagin newPlag, int plaginID) throws SQLException{
		String sql="update plagin set plaginName=?,plaginPath=?,  config=? where plaginID=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		int row  = runner.update(sql, newPlag.getPlaginName(), newPlag.getPlaginPath(), newPlag.getConfig(), plaginID);
		if (row == 0) { 
			  throw new RuntimeException(); 
			  }
	}
}
