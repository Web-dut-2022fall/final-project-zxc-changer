package com.zhscan.servlet.asset;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhscan.entity.Asset;
import com.zhscan.entity.Host;
import com.zhscan.service.AssetService;
import com.zhscan.service.TaskService;

@WebServlet(name = "addToAsset", urlPatterns = { "/addToAsset" })
public class AddToAssetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AddToAssetServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String resultID=request.getParameter("resultID");
		long id = Long.parseLong(resultID);
		TaskService ts= new TaskService();
		Host h =ts.findHostByHostResultID(id);
		Asset asset =new Asset(h.getHostName(), h.getHostIP(),"", h.getUserID());
		AssetService as = new AssetService();
		as.addAsset(asset);
		
		request.setAttribute("success", 1);
 		request.getRequestDispatcher("showAsset?w=0") .forward(request,response);
		
	}

}
