package com.zhscan.servlet.asset;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Asset_User;
import com.zhscan.service.AssetService;

@WebServlet(name = "delAsset", urlPatterns = { "/delAsset" })
public class DelAssetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DelAssetServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	       
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		response.setContentType("text/html; charset=utf-8");
		AssetService service = new AssetService();
		int assetID =Integer.parseInt( request.getParameter("assetID"));
	    service.delAsset(assetID);
		   HttpSession hs=request.getSession();
		   List<Asset_User> as = (List<Asset_User>) hs.getAttribute("assets"); 
		   if(null!=as) {
			   for(int i=0;i<as.size();i++) {
				   if(as.get(i).getAssetID()==assetID) {
					   as.remove(i); 
					   i--;
				   }
			   }
			
		   }
		   hs.setAttribute("assets", as);
					// 更改成功，跳转到mytask.jsp
		   request.setAttribute("delsuccess", 1);
				   request.getRequestDispatcher("assetmanager.jsp") .forward(request,response);
	}
	}
