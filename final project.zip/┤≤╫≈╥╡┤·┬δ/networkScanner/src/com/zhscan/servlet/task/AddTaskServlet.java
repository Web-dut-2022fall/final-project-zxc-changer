package com.zhscan.servlet.task;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhscan.entity.Asset;
import com.zhscan.entity.Task;
import com.zhscan.entity.User;
import com.zhscan.service.AssetService;
import com.zhscan.service.TaskService;
import com.zhscan.util.TaskMapUtil;

@WebServlet(name = "addTask", urlPatterns = { "/addTask" })
public class AddTaskServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AddTaskServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String tt = request.getParameter("taskType");
		int taskType=Integer.parseInt(tt);
		Map<Integer ,String> map = TaskMapUtil.getMap();
		String taskName = map.get(taskType);  //根据任务类型，通过键值对获取任务名称

		User u = (User)request.getSession().getAttribute("user");
		int uID=u.getUserID();
		String  assetID=request.getParameter("assetID");
		//Task orgTask =(Task)request.getSession().getAttribute("task");
		Task  task=null;
		if(null!=assetID && !("").equals(assetID)){
			int aid = Integer.parseInt(assetID);
			AssetService as =new AssetService();
			Asset asset  = as.findAssetByID(aid);
			String destIP = asset.getAssetIP();
			//System.out.println(destIP);
			 task= new Task(taskName, 0, taskType, "", "", 0,0, destIP , uID);
			 request.getSession().setAttribute("destIP",destIP);
		}else {
		   task= new Task(taskName, 0, taskType, "", "", 0,0,"", uID);
		}
		
		
		TaskService service = new TaskService();
		 int taskid=service.addTask(task);   //将该任务添加到数据库
		  
		 System.out.println(taskid);
		 if(taskid!=0) {
			 task.setTaskID(taskid);
		 }
		 
		request.getSession().setAttribute("task", task);
		
		if(taskType==0) {
			 request.getRequestDispatcher("ipmanager.jsp") .forward(request,response);
		}else if(taskType==1||taskType==2) {
			 request.getRequestDispatcher("portmanager.jsp") .forward(request,response);
		} else if(taskType==3) { 
				  request.getRequestDispatcher("vulmanager.jsp") .forward(request,response);
		 } 

	}

}
