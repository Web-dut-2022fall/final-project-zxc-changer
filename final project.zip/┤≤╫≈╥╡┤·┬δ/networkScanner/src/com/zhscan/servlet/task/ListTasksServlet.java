package com.zhscan.servlet.task;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Task;
import com.zhscan.entity.User;
import com.zhscan.service.TaskService;

@WebServlet(name = "listTasks", urlPatterns = { "/listTasks" })
public class ListTasksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ListTasksServlet() {
        super();
        
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		HttpSession session =request.getSession();
		User u =(User)session.getAttribute("user");
		String taskType = request.getParameter("tType");
		String userName = request.getParameter("name");
		String s = request.getParameter("taskState");
		int state=-1;
		if(null!=s) {
			state = Integer.parseInt(request.getParameter("taskState"));
		}
		
		List<Task> tasks =null;
		TaskService service = new TaskService();
		
		if(null!=taskType&&!("").equals(taskType)) {
	//		if(state>-1) {
				int tType=Integer.parseInt(taskType);
				System.out.println(tType);
				if(null==userName||("").equals(userName)) {                //没有指定任务发起者
					if(u.getUserRole()==0) {    //普通用户只能看到自己添加的扫描任务
						int userID =u.getUserID();
						System.out.println(userID);
						
						//System.out.println(tType);
						if(tType==-1) {         //没有指定任务类型
						switch(state) {
						case 0:
							tasks=  service.findTaskByUserIDAndState(userID, 0);
							session.setAttribute("nostartedtasks", tasks);
						    request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
							break;
						case 1:
							tasks=  service.findTaskByUserIDAndState(userID,1);
							session.setAttribute("underwaytasks", tasks);
						    request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
							break;
						case 2:
							tasks=  service.findTaskByUserIDAndState(userID,2);
							session.setAttribute("fininshedtasks", tasks);
						    request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
							break;
						default:
							tasks=  service.findTaskByUserID(userID);
							session.setAttribute("tasks", tasks);
						    request.getRequestDispatcher("mytask.jsp") .forward(request,response);
							break;
						}
						}else {
							switch(state) {
							case 0:
								tasks=  service.findTaskByUserIDAndStateAndType(userID, 0, tType);
								session.setAttribute("nostartedtasks", tasks);
							    request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
								break;
							case 1:
								tasks=  service.findTaskByUserIDAndStateAndType(userID,1,tType);
								session.setAttribute("underwaytasks", tasks);
							    request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
								break;
							case 2:
								tasks=  service.findTaskByUserIDAndStateAndType(userID,2,tType);
								session.setAttribute("fininshedtasks", tasks);
							    request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
								break;
							default:
								tasks=  service.findTaskByUserIDAndType(userID,tType);
								session.setAttribute("tasks", tasks);
							    request.getRequestDispatcher("mytask.jsp") .forward(request,response);
								break;
							}
						}
					}else if(u.getUserRole()==1){   //管理员用户可以查看和管理所有用户添加的任务
						String way=request.getParameter("way");
						if(null!=way) {       
							if(way.equals("1")) {   //如果管理员只要求查看自己的任务
								int userID =u.getUserID();
								System.out.println(userID);
								if(tType==-1) {         //没有指定任务类型
									switch(state) {
									case 0:
										tasks=  service.findTaskByUserIDAndState(userID, 0);
										session.setAttribute("nostartedtasks", tasks);
									    request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
										break;
									case 1:
										tasks=  service.findTaskByUserIDAndState(userID,1);
										session.setAttribute("underwaytasks", tasks);
									    request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
										break;
									case 2:
										tasks=  service.findTaskByUserIDAndState(userID,2);
										session.setAttribute("fininshedtasks", tasks);
									    request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
										break;
									default:
										tasks=  service.findTaskByUserID(userID);
										session.setAttribute("tasks", tasks);
									    request.getRequestDispatcher("mytask.jsp") .forward(request,response);
										break;
									}
									}else {
										switch(state) {
										case 0:
											tasks=  service.findTaskByUserIDAndStateAndType(userID, 0, tType);
											session.setAttribute("nostartedtasks", tasks);
										    request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
											break;
										case 1:
											tasks=  service.findTaskByUserIDAndStateAndType(userID,1,tType);
											session.setAttribute("underwaytasks", tasks);
										    request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
											break;
										case 2:
											tasks=  service.findTaskByUserIDAndStateAndType(userID,2,tType);
											session.setAttribute("fininshedtasks", tasks);
										    request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
											break;
										default:
											tasks=  service.findTaskByUserIDAndType(userID,tType);
											session.setAttribute("tasks", tasks);
										    request.getRequestDispatcher("mytask.jsp") .forward(request,response);
											break;
										}
									}
							}
						}	else {	
							if(tType==-1) {
								switch(state) {
								case 0:
									tasks=  service.findTaskByState(0);
									session.setAttribute("nostartedtasks", tasks);
								    request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
									break;
								case 1:
									tasks= service.findTaskByState(1);
									session.setAttribute("underwaytasks", tasks);
								    request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
									break;
								case 2:
									tasks=  service.findTaskByState(2);
									session.setAttribute("fininshedtasks", tasks);
								    request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
									break;
								default:
									tasks=  service.listAllTasks();
									session.setAttribute("tasks", tasks);
								    request.getRequestDispatcher("mytask.jsp") .forward(request,response);
									break;
								}
							}else {
								switch(state) {
								case 0:
									tasks=  service.findTaskByStateAndType(0,tType);
									session.setAttribute("nostartedtasks", tasks);
								    request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
									break;
								case 1:
									tasks= service.findTaskByStateAndType(1,tType);
									session.setAttribute("underwaytasks", tasks);
								    request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
									break;
								case 2:
									tasks=  service.findTaskByStateAndType(2,tType);
									session.setAttribute("fininshedtasks", tasks);
								    request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
									break;
								default:
									tasks=  service.findTaskByType(tType);
									/*
									 * System.out.println("-----------------------------------"); for(int
									 * i=0;i<tasks.size();i++) { System.out.println(tasks.get(i).getTaskName()); }
									 */
									session.setAttribute("tasks", tasks);
								    request.getRequestDispatcher("mytask.jsp") .forward(request,response);
									break;
								}
							}
	
						}
					}
				}else{           //指定了任务发起者
					//System.out.println(userName);
					//System.out.println(tType);
					if(tType==-1) {         //没有指定任务类型
						switch(state) {
						case 0:
							tasks=  service.findTaskByUserNameAndState(userName, 0);
						
							session.setAttribute("nostartedtasks", tasks);
						    request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
							break;
						case 1:
							tasks=  service.findTaskByUserNameAndState(userName,1);
							session.setAttribute("underwaytasks", tasks);
						    request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
							break;
						case 2:
							tasks=  service.findTaskByUserNameAndState(userName,2);
							session.setAttribute("fininshedtasks", tasks);
						    request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
							break;
						default:
							tasks=  service.findTaskByUserName(userName);
							/*
							 * System.out.println(tasks.size()); for(int i=0;i<tasks.size();i++) {
							 * System.out.println(tasks.get(i).getTaskName()); }
							 */
							session.setAttribute("tasks", tasks);
						    request.getRequestDispatcher("mytask.jsp") .forward(request,response);
							break;
						}
					}else {   //指定了任务类型
						switch(state) {
						case 0:
							tasks=  service.findTaskByUserNameAndTypeAndState(userName, tType, 0);
							session.setAttribute("nostartedtasks", tasks);
						    request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
							break;
						case 1:
							tasks=  service.findTaskByUserNameAndTypeAndState(userName, tType, 1);
							session.setAttribute("underwaytasks", tasks);
						    request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
							break;
						case 2:
							tasks=  service.findTaskByUserNameAndTypeAndState(userName, tType, 2);
							session.setAttribute("fininshedtasks", tasks);
						    request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
							break;
						default:
							tasks=  service.findTaskByUserNameAndType(userName,  tType);
							session.setAttribute("tasks", tasks);
						    request.getRequestDispatcher("mytask.jsp") .forward(request,response);
							break;
						}
					}
					
				}
		}
		/*
			 * else { switch(state) { case 0: tasks= service.findTaskByState(0);
			 * session.setAttribute("nostartedtasks", tasks);
			 * request.getRequestDispatcher("nostartedtask.jsp") .forward(request,response);
			 * break; case 1: tasks= service.findTaskByState(1);
			 * session.setAttribute("underwaytasks", tasks);
			 * request.getRequestDispatcher("underwaytask.jsp") .forward(request,response);
			 * break; case 2: tasks= service.findTaskByState(2);
			 * session.setAttribute("fininshedtasks", tasks);
			 * request.getRequestDispatcher("finishedtask.jsp") .forward(request,response);
			 * break; default: tasks= service.listAllTasks(); session.setAttribute("tasks",
			 * tasks); request.getRequestDispatcher("mytask.jsp")
			 * .forward(request,response); break; } }
			 */
	}

}
