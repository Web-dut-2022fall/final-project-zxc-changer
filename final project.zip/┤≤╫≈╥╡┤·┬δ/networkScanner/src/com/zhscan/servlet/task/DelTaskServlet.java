package com.zhscan.servlet.task;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Task;
import com.zhscan.service.TaskService;

@WebServlet(name = "delTask", urlPatterns = { "/delTask" })
public class DelTaskServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DelTaskServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	            doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		TaskService service = new TaskService();
		int taskID =Integer.parseInt( request.getParameter("taskID"));
	    service.delTask(taskID);
		   HttpSession hs=request.getSession();
		   List<Task> ts = (List<Task>) hs.getAttribute("tasks"); 
		   if(null!=ts) {
			   for(int i=0;i<ts.size();i++) {
				   if(ts.get(i).getTaskID()==taskID) {
					   ts.remove(i); 
					   i--;
				   }
			   }
			   hs.setAttribute("tasks", ts);
				// 更改成功，跳转到mytask.jsp
			   request.setAttribute("success", 1);
			   request.getRequestDispatcher("mytask.jsp") .forward(request,response);
		   }else {
			   request.setAttribute("success", 0);
			   request.getRequestDispatcher("mytask.jsp") .forward(request,response);
		   }
		 
		  
	}

}
