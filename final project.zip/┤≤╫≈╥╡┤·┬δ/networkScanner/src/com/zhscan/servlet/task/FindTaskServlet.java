package com.zhscan.servlet.task;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.zhscan.entity.Task_User;
import com.zhscan.service.TaskService;
import com.zhscan.util.TaskMapUtil;

@WebServlet(name = "findTask", urlPatterns = { "/findTask" })
public class FindTaskServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FindTaskServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json; charset=utf-8");
		int taskID=Integer.parseInt(request.getParameter("tid"));
		
		System.out.println(taskID);
		
		TaskService ts=new TaskService();
		Task_User tu = ts.findTaskByTaskID(taskID);
		if(null!=tu) {
			System.out.println(tu.getUserName());
			//request.getSession().setAttribute("tu", tu);
			JSONObject json=new JSONObject();
			try {
				json.put("taskname", tu.getTaskName());
				int tstate=tu.getTaskState();
				Map<Integer,String> map =TaskMapUtil.getMap2();
				String state=map.get(tstate);
				json.put("taskstate", state);
				json.put("beginip", tu.getBeginIP());
				json.put("endip", tu.getEndIP());
				json.put("beginport", tu.getBeginPort());
				json.put("endport", tu.getEndPort());
				json.put("desthost", tu.getDestHostIP());
				json.put("userid", tu.getUserID());
				json.put("username", tu.getUserName());
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			PrintWriter out = response.getWriter();
			out.println(json);
			out.close();
		}
	}

}
