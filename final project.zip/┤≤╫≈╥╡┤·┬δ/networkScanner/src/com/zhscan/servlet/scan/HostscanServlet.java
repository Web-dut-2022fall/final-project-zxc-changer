package com.zhscan.servlet.scan;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;

import com.zhscan.entity.Host;
import com.zhscan.entity.Task;
import com.zhscan.entity.User;
import com.zhscan.service.TaskService;
import com.zhscan.service.hostscan.HostScanService;
import com.zhscan.service.hostscan.ScanHandler;
import com.zhscan.util.IpUtils;

@WebServlet(name = "hostscan", urlPatterns = { "/hostscan" })
public class HostscanServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public HostscanServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/json; charset=utf-8");

		// 1.获取主机扫描页面输入的起始IP和结束IP
		String ip1 = request.getParameter("ip1");
		String ip2 = request.getParameter("ip2");
		String ip3 = request.getParameter("ip3");
		String ip4 = request.getParameter("ip4");
		String ipe1 = request.getParameter("ipe1");
		String ipe2 = request.getParameter("ipe2");
		String ipe3 = request.getParameter("ipe3");
		String ipe4 = request.getParameter("ipe4");

		if("".equals(ip1)|| "".equals(ip2 )|| "".equals(ip3) || "".equals(ip4) ||  "".equals(ipe1 )|| "".equals(ipe2) || "".equals(ipe3) || "".equals(ipe4)) {
		    response.sendRedirect("ipmanager.jsp?ipempty=yes");
	}else {
		String ip_start=ip1+"."+ip2+"."+ip3+"."+ip4;
		String ip_end=ipe1+"."+ipe2+"."+ipe3+"."+ipe4;
		
			long ipStart = IpUtils.ipToLong(ip_start);
			long ipEnd = IpUtils.ipToLong(ip_end);
			
			//先判断输入的ip地址范围是否合法
			if(ipStart>ipEnd) {  
					response.sendRedirect("ipmanager.jsp?iperror=yes");
			}else {
				
				HttpSession session = request.getSession();
				User user = (User) session.getAttribute("user");
				Task orgTask =(Task)session.getAttribute("task");
				
				if(null== orgTask) {
				    request.getRequestDispatcher("hostscan.jsp").forward(request,response);
				    return;
				}
				int userId = user.getUserID();
				int taskId = orgTask.getTaskID();
				
				System.err.println(taskId);
				Task hosttask = new Task("主机扫描", 1 , 0,  ip_start, ip_end, "",userId);
				hosttask.setTaskID(taskId);
				TaskService ts= new TaskService();
				ts.updateTask(hosttask, taskId);     //更新数据库里存放的任务属性
				
				String count=(String)session.getAttribute("hostcount");
				//任务状态：0表示未开始 ，1表示进行中，2表示已完成
				//任务种类：0表示主机扫描, 1表示常用端口扫描，2表示选定范围扫描， 3表示漏洞扫描, 4表示系统识别
				HostScanService hss ;
				if(null!=count&&(!("").equals(count))) {
					int hostCount = Integer.parseInt(count);
					System.out.println(hostCount);
					hss= new HostScanService(hostCount, hosttask);
				}else {
					hss= new HostScanService(10, hosttask);    //默认情况每个线程扫描10个主机
				}	
					
				session.setAttribute("hss", hss);
				session.setAttribute("taskid", taskId);
				session.setAttribute("userid", userId);
				session.setAttribute("ts", ts);
				response.sendRedirect("threadCtrl");
				}
	        
		}
	}
	
	
}
