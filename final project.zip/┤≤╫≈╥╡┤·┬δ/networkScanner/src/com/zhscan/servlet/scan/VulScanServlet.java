package com.zhscan.servlet.scan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.dao.UserDao;
import com.zhscan.entity.Plagin;
import com.zhscan.entity.Task;
import com.zhscan.entity.User;
import com.zhscan.entity.Vul;
import com.zhscan.service.CheckPwd;
import com.zhscan.service.PlaginService;
import com.zhscan.service.TaskService;
import com.zhscan.service.UserService;
import com.zhscan.service.VulService;
import com.zhscan.util.AESUtils;

@WebServlet(name = "vulscan", urlPatterns = { "/vulscan" })
public class VulScanServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public VulScanServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		User u =(User) request.getSession().getAttribute("user");
	   UserService us =new UserService();
	   Task t =(Task) request.getSession().getAttribute("task");
	   HttpSession session = request.getSession();
	   String type=request.getParameter("identity");
	   TaskService ts =new TaskService();
		int userId = u.getUserID();
		int taskId = t.getTaskID();
		System.out.println(userId);
		System.out.println(taskId);
		Task vultask1=null;
		VulService vs=null;
	    switch (type) {
	    case "usual":
			int userRole=u.getUserRole();
			 boolean flag = false;
			 int weakPwdID=0;
			 String weakPwdType="";
			 List<Integer> wlist =null;
			 
			if(userRole==1) {    //管理员用户
				List<User> users = us.listAllUsers();
			//	 boolean flags[] = new boolean[users.size()];
				 int index=0;
				List<Vul> weakPass = new ArrayList<Vul>();
			     vultask1 = new Task("弱口令扫描", 1 , 3, 0 , 0, "", userId); 
				 ts.updateTask(vultask1, taskId);     //更新数据库里存放的任务属性
				
				for(User user  :users) {     //对每个用户的口令进行弱口令检测
					String password = user.getUserPass();
					String key = UserDao.getKey();
						//System.out.printf("testpass[%d] = %s\n", i,testPass[i]);
					String pw = AESUtils.decryptData(key, password);
					System.out.println(pw);
		            flag = CheckPwd.EvalPWD(pw);
		           wlist= CheckPwd.getWeakList();
		            	vs = new VulService();
		            if (!flag) {      //扫描到弱口令
		            	for(int i =0; i<wlist.size();i++) {
		            		weakPwdID=wlist.get(i);
		            		weakPwdType=weakPwdType+vs.findWeakPwdByID(weakPwdID).getWeakPwdType()+" | ";
		            	}
		            //	flags[index]=false;
	   		             Vul v =new Vul("弱口令",weakPwdType,"",  t.getTaskID(), user.getUserID());  
						  weakPass.add(v);
					
   		            }else{
   		            	index++;
   		            }
					weakPwdType="";
		 			}
				  
			
				  if(index==users.size()) {    //如果全都合格
					  session.setAttribute("flag",1);
				  }else {
					  session.setAttribute("flag",0);
				  }
					
	           session.setAttribute("weakPass", weakPass);
			}else {
				String password = u.getUserPass();
				String key = UserDao.getKey();
				//System.out.printf("testpass[%d] = %s\n", i,testPass[i]);
			String pw = AESUtils.decryptData(key, password);
				  flag = CheckPwd.EvalPWD(pw);
				  if (flag) {    
		               System.out.println("secret pass.\n");
		            	session.setAttribute("flag",1);
		            } else {
		            	List<Vul> weakPass = new ArrayList<Vul>();
		            	  wlist= CheckPwd.getWeakList();
		            	//weakPwdID=CheckPwd.getWeakPwdType();
		            	  vultask1 = new Task("弱口令扫描", 1 , 3, 0 , 0, "", userId); 
		            	  ts.updateTask(vultask1, taskId);     //更新数据库里存放的任务属性
		                	vs = new VulService();
		            	for(int i =0; i<wlist.size();i++) {
		            		weakPwdID=wlist.get(i);
		            		weakPwdType=weakPwdType+vs.findWeakPwdByID(weakPwdID).getWeakPwdType()+" | ";
		            	}
		            	//weakPwdType=vs.findWeakPwdByID(weakPwdID).getWeakPwdType();
						  Vul v =new Vul("弱口令",weakPwdType,"",  t.getTaskID(), u.getUserID());  
						  weakPass.add(v);
					//	  ts.updateTaskState(2, taskId);     //更新数据库里存放的任务状态属性
		              //  System.out.println("secret failed.\n");
						  session.setAttribute("flag", 0);
		            	session.setAttribute("weakPass", weakPass);
		            }
			}
			ts.updateTaskState(2, taskId);     //更新数据库里存放的任务状态属性
			response.sendRedirect(request.getContextPath() +"/holeresult.jsp");
			//request.getRequestDispatcher("holeresult.jsp").forward(request, response);
	    	break;
	    case "hole":
	    	String ip1 = request.getParameter("ip1");
			String ip2 = request.getParameter("ip2");
			String ip3 = request.getParameter("ip3");
			String ip4 = request.getParameter("ip4");
			List<Vul> vuls = new ArrayList<Vul>();
			if("".equals(ip1 )|| "".equals(ip2) || "".equals(ip3) || "".equals(ip4) ) {
			    response.sendRedirect("vulmanager.jsp?destipempty=yes");
			}else {
				String dest_ip=ip1+"."+ip2+"."+ip3+"."+ip4;

				 vultask1 = new Task("安全漏洞扫描", 1 , 5, 0 , 0, dest_ip, userId); 
				 System.out.println(taskId);
				  ts.updateTask(vultask1, taskId);     //更新数据库里存放的任务属性
				  
			vs=new VulService ();
			ArrayList<String> plugins = vs.getPlugin();  //获取jar
				/*
				 * for(String s:plugins) { System.out.println(s); }
				 */
				try {
	                 if(vs.pluginEngine(plugins, dest_ip)) {   //说明没有漏洞
	             		session.setAttribute("flag",1);
	                 }else {    
	                	List<String> vlist= new ArrayList<String>();
	                    vlist = VulService.getVuls();
	                    String log="";
	                    for(String s:vlist) {
	                    	 log= log+s;
	                    }
	                    System.out.println(log);
	              	  Vul v =new Vul("弱口令",log, dest_ip, t.getTaskID(), u.getUserID());  
					  vuls.add(v);
	              	    request.setAttribute("flag", 0);
	  	             	session.setAttribute("weakPass", vuls);
	                 }
			//		String log= vs.pluginEngine(plugins, dest_ip);
				 // Vul v =new Vul("安全漏洞",weakPwdType, t.getTaskID(), u.getUserID());  
				} catch (Exception e) {
					e.printStackTrace();
				}
				 ts.updateTaskState(2, taskId);     //更新数据库里存放的任务状态属性
			
	        	response.sendRedirect(request.getContextPath() +"/holeresult.jsp");
			}
	    	
	    	break;
	    case "third":
	    	String plaginname = request.getParameter("plagin");
	    	int userid = u.getUserID();
	    	PlaginService ps =new PlaginService();
	    	Plagin plag=ps.findPlaginByNameAndUserID(plaginname, userid);
	    	String conf=plag.getConfig();
	    	
	    	response.sendRedirect(conf);
	    	break;
	    default:
	    	break;
	    }

	   
	
	}

}
