package com.zhscan.servlet.scan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Asset_User;
import com.zhscan.entity.Task;
import com.zhscan.entity.User;
import com.zhscan.service.AssetService;
import com.zhscan.service.TaskService;
import com.zhscan.util.TaskMapUtil;

@WebServlet("/initOsIdentify")
public class InitOsIdentifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public InitOsIdentifyServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		HttpSession session =request.getSession();
		User u =(User)session.getAttribute("user");
		AssetService as =new AssetService();
	
		int uid=u.getUserID();
		List<Asset_User> asset=as.listPortResultsByUserID(uid);
		List<String>  ips = new ArrayList<String>();
		for(Asset_User au : asset) {
			String ip=au.getAssetIP();
			System.out.println(ip);
			if(!isInList(ips, ip))
			  ips.add(ip);
		}
		
		String tt = request.getParameter("taskType");
		int taskType=Integer.parseInt(tt);
		Map<Integer ,String> map = TaskMapUtil.getMap();
		String taskName = map.get(taskType); 
		Task  task= new Task(taskName, 0, 4, "", "", 0,0, "" , uid);
		
		TaskService service = new TaskService();
		 int taskid=service.addTask(task);   //将该任务添加到数据库
		 System.out.println(taskid);
		 task.setTaskID(taskid);
		session.setAttribute("task", task);
		session.setAttribute("ips", ips);
		
 		request.getRequestDispatcher("osmanager.jsp") .forward(request,response);
	}
	
	public boolean isInList(List<String> l, String ip) {
		for(int i=0;i<l.size();i++) {
			if(l.get(i).equals(ip))
				return true;
		}
		return false;
	}

}
