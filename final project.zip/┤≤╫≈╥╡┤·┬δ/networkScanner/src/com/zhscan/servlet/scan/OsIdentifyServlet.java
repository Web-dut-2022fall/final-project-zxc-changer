package com.zhscan.servlet.scan;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Task;
import com.zhscan.entity.User;
import com.zhscan.service.OsIdentify;
import com.zhscan.service.TaskService;

@WebServlet("/osIdentify")
public class OsIdentifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public OsIdentifyServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		Task orgTask =(Task)session.getAttribute("task");
		String IP = request.getParameter("destIP");
		if(null== orgTask) {
		    request.getRequestDispatcher("osidentify.jsp").forward(request,response);
		    return;
		}
		int userId = user.getUserID();
		int taskId = orgTask.getTaskID();
		
		//System.out.println(taskId);
		Task ostask = new Task("操作系统识别", 1 , 4, "", "", IP, userId);
		ostask.setTaskID(taskId);
		TaskService ts= new TaskService();
		ts.updateTask(ostask, taskId);     //更新数据库里存放的任务属性
		
		String s = OsIdentify.getOsAndBrowserInfo(request);
		
	    ts.updateTaskState(2, taskId);     //更新数据库里存放的任务状态属性
		
		request.getSession().setAttribute("ostype", s);	
		request.setAttribute("finished", 1);	
		request.setAttribute("ip", IP);		
	     request.getRequestDispatcher("osmanager.jsp") .forward(request,response);
	}

}
