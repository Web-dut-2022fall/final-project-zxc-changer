package com.zhscan.servlet.scan;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "setThread", urlPatterns = { "/setThread" })
public class SetThreadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public SetThreadServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String  hostcount= request.getParameter("perhostcount");
		String  portcount = request.getParameter("perportcount" );
		if(null==hostcount||("").equals(hostcount)) {
			request.getSession().setAttribute("hostcount", 10 );
		}else {
			request.getSession().setAttribute("hostcount", hostcount );
		}
		if(null==portcount||("").equals(portcount)) {
			request.getSession().setAttribute("portcount", 20 );
		}else {
			request.getSession().setAttribute("portcount", portcount );
		}
		request.setAttribute("success", 1);
		request.getRequestDispatcher("scanstrategy.jsp").forward(request,response);
	}

}
