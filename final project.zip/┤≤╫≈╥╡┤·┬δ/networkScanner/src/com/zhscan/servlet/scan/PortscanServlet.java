package com.zhscan.servlet.scan;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Port;
import com.zhscan.entity.Task;
import com.zhscan.entity.User;
import com.zhscan.service.TaskService;
import com.zhscan.service.hostscan.HostScanService;
import com.zhscan.service.portscan.PortScan;

@WebServlet(name = "portscan", urlPatterns = { "/portscan" })
public class PortscanServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	TaskService ts;
	HttpSession session;
    public PortscanServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		// 1.获取进行端口扫描时的目标主机的IP
				String ip1 = request.getParameter("ip1");
				String ip2 = request.getParameter("ip2");
				String ip3 = request.getParameter("ip3");
				String ip4 = request.getParameter("ip4");
				//String dest_ip=ip1+"."+ip2+"."+ip3+"."+ip4;
				
				String type=request.getParameter("identity");
							
				if("".equals(ip1 )|| "".equals(ip2) || "".equals(ip3) || "".equals(ip4) ) {
				    response.sendRedirect("portmanager.jsp?destipempty=yes");
				}else {
					String dest_ip=ip1+"."+ip2+"."+ip3+"."+ip4;
					session = request.getSession();
					User user = (User) session.getAttribute("user");
					Task orgTask =(Task)session.getAttribute("task");
					if(null== orgTask) {
					    request.getRequestDispatcher("portscan.jsp") .forward(request,response);
					    return;
					}
					int userId = user.getUserID();
					int taskId = orgTask.getTaskID();
					 ts =new TaskService();
					 
					 //获取每线程扫描端口数
					 String count=(String)session.getAttribute("portcount");
					if(type.equals("usual")) {
						 Task porttask1 = new Task("常用端口扫描", 1 , 1, 0 , 8000, dest_ip, userId); 
						 System.out.println(taskId);
						  ts.updateTask(porttask1, taskId);     //更新数据库里存放的任务属性
						  PortScan ps1 =null;
						  if(null!=count&&(!("").equals(count))) {  //如果扫描策略中有设置
							  int portCount = Integer.parseInt(count);
								System.out.println(portCount);
								ps1= new PortScan(portCount, porttask1);
						  }else {
							  ps1= new PortScan(20, porttask1);  //默认是20
						  }
		
						 exe(ps1, request, response, taskId,userId);
					}else {
						String startPort=request.getParameter("port_start");
						String endPort=request.getParameter("port_end");
						if(""==startPort || ""==endPort) {
							response.sendRedirect("portmanager.jsp?portempty=yes");
						}else {
							
							int port_start = Integer.parseInt(startPort);
							int port_end =  Integer.parseInt(endPort);
							if(port_end<port_start) {
								 response.sendRedirect("portmanager.jsp?porterror=yes");
							}else {
								  Task porttask2 = new Task("选定端口扫描", 1 , 2, port_start , port_end, dest_ip, userId); 
								  ts.updateTask(porttask2, taskId);     //更新数据库里存放的任务属性
								  
								  PortScan ps2 =null;
								  if(null!=count&&(!("").equals(count))) {  //如果扫描策略中有设置
									  int portCount = Integer.parseInt(count);
										System.out.println(portCount);
										ps2= new PortScan(portCount, porttask2);
								  }else {
									  ps2= new PortScan(20, porttask2);  //默认是20
								  }		
									exe(ps2,request, response, taskId,userId);
							}
						}
					}
					}
	}
	
	public void exe(PortScan ps,HttpServletRequest request, HttpServletResponse response, int taskId,int userId) throws ServletException, IOException {
		List<Port> ports = null;
		 try {
			ports = ps.portScan();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 for(Port port:ports) {
				port.setTaskID(taskId);
				port.setUserID(userId);
				System.out.println(port.toString());
			}
		 
		 request.setAttribute("p_saved", 0);
	        session.setAttribute("port_result", ports);
	        //session.removeAttribute("task");
	        ts.updateTaskState(2, taskId);     //更新数据库里存放的任务状态属性
	        request.getRequestDispatcher("portresult.jsp") .forward(request,response);
	}

}
