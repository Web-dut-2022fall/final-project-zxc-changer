package com.zhscan.servlet.scan;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;

import com.zhscan.entity.Host;
import com.zhscan.service.TaskService;
import com.zhscan.service.hostscan.HostScanService;

@WebServlet(name = "threadCtrl", urlPatterns = { "/threadCtrl" })
public class ThreadCtrlServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	public ThreadCtrlServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		threadCtrl(request, response);
	}
	
	public void threadCtrl(HttpServletRequest request, HttpServletResponse response){
		HttpSession sn = request.getSession();
		HostScanService hss = (HostScanService)sn.getAttribute("hss");
		List<Host> hosts = null;
		PrintWriter out =null;
		JSONObject json;
		TaskService ts =(TaskService)sn.getAttribute("ts");
		int taskId = (Integer)sn.getAttribute("taskid") ;
		int userId = (Integer)sn.getAttribute("userid") ;
		
		  try {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json; charset=utf-8");

		Thread thread = new Thread(hss);
		String stop = request.getParameter("stop");
		if (null == stop) {
			thread.start();
			thread.join();
		//	while (!thread.isAlive()) {
				hosts = HostScanService.getHosts();
				if(null!=hosts) {
				for(Host host:hosts) {
					host.setUserID(userId); 
					host.setTaskID(taskId);
					System.out.println(host.toString());
					}
				request.setAttribute("saved", 0);
				 sn.setAttribute("result", hosts); 
				  ts.updateTaskState(2, taskId); //更新数据库里存放的任务状态属性
				
			request.getRequestDispatcher("hostresult.jsp").forward(request,response);
			}
				
	//		}

		} else {
				/*
				 * thread.interrupt(); thread.join();
				 */	
			    hss.setExit(true);
				out = response.getWriter();
				json=new JSONObject();
					json.put("sign", "已取消该任务！");
					 out.println(json); 
					 out.close();
		}
	
		
			} catch (ServletException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
	
				e.printStackTrace();
			} 
		  catch (JSONException e) {
				e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
