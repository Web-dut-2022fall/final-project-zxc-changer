package com.zhscan.servlet.scan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Plagin;
import com.zhscan.entity.Task;
import com.zhscan.entity.User;
import com.zhscan.service.PlaginService;
import com.zhscan.service.TaskService;
import com.zhscan.util.TaskMapUtil;

@WebServlet("/initHolescan")
public class InitHolescan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public InitHolescan() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String tt = request.getParameter("taskType");
		int taskType=Integer.parseInt(tt);
		Map<Integer ,String> map = TaskMapUtil.getMap();
		String taskName = map.get(taskType);  //根据任务类型，通过键值对获取任务名称
		//int uID = Integer.parseInt(request.getParameter("uid"));
		User u = (User)request.getSession().getAttribute("user");
		int uID=u.getUserID();
		
		
		
		 PlaginService ps =new PlaginService();
		 List<Plagin> plagins = ps.listPlaginByUserID(uID);
		 List<String>  plags = new ArrayList<String>();
		 for(Plagin p : plagins) {
				String plagname=p.getPlaginName();
				System.out.println(plagname);
				if(!isInList(plags, plagname))
				  plags.add(plagname);
			}
		 
		 HttpSession session =request.getSession();
		 
		 TaskService service = new TaskService();
			
		 Task task= new Task(taskName, 0, taskType, "", "", 0,0,"", uID);
		 int taskid=service.addTask(task);   //将该任务添加到数据库
		 System.out.println(taskid);
		 task.setTaskID(taskid);
		session.setAttribute("task", task);
        session.setAttribute("plagins", plags);
		
 		request.getRequestDispatcher("vulmanager.jsp") .forward(request,response);
        //response.sendRedirect(request.getContextPath() +"/vulmanager.jsp");
		
	}
	public boolean isInList(List<String> l, String ip) {
		for(int i=0;i<l.size();i++) {
			if(l.get(i).equals(ip))
				return true;
		}
		return false;
	}

}
