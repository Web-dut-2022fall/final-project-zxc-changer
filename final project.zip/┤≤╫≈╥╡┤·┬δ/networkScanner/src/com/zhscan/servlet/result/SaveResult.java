package com.zhscan.servlet.result;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhscan.entity.Host;
import com.zhscan.entity.Port;
import com.zhscan.entity.User;
import com.zhscan.entity.Vul;
import com.zhscan.service.AssetService;
import com.zhscan.service.TaskService;

@WebServlet(name = "saveResult", urlPatterns = { "/saveResult" })
public class SaveResult extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public SaveResult() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		TaskService ts = new TaskService();
		
		int type=Integer.parseInt(request.getParameter("tasktype"));
		switch(type) {
		case 0:
			List<Host> hosts =( List<Host>) request.getSession().getAttribute("result");
			if(null!=hosts) {
				for(Host h:hosts) {	
					ts.addResult(h);
				}
			}
			request.setAttribute("saved", 1);  //已保存
			request.getRequestDispatcher("hostresult.jsp").forward(request,response);
			break;
		case 1:
			List<Port> ports =( List<Port>) request.getSession().getAttribute("port_result");
			if(null!=ports) {
				for(Port p:ports) {	
					ts.addPortResult(p);
				}
			}
			request.setAttribute("p_saved", 1);  //已保存
			request.getRequestDispatcher("portresult.jsp").forward(request,response);
			break;
		case 3:
			List<Vul> vuls =( List<Vul>) request.getSession().getAttribute("weakPass");
			if(null!=vuls) {
				for(Vul v:vuls) {	
					ts.addVulResult(v);
				}
			}
			request.setAttribute("saved", 1);  //已保存
			request.getRequestDispatcher("holeresult.jsp").forward(request,response);
			break;
		case 4:   //系统识别
			String s = request.getParameter("ostype");
			User u = (User)request.getSession().getAttribute("user");
			String ip = request.getParameter("ip");
      		AssetService as =new AssetService();
			as.updateAssetByIPAndUserID(s, ip, u.getUserID());
			request.setAttribute("saved", 1);  //已保存
			request.getRequestDispatcher("osmanager.jsp").forward(request,response);
			break;
		 default:  
			 
			 break;
		}
	}
}
