package com.zhscan.servlet.result;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Host;
import com.zhscan.entity.Host_Task_User;
import com.zhscan.service.TaskService;

@WebServlet("/delHostResult")
public class DelHostResult extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
    public DelHostResult() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		TaskService service = new TaskService();
		int hostResultID =Integer.parseInt( request.getParameter("hostResultID"));
		System.out.println(hostResultID);
	    service.delHostResult(hostResultID);
		   HttpSession ses=request.getSession();
		   List<Host_Task_User> hs = (List<Host_Task_User>) ses.getAttribute("hostScanResult"); 
		   for(int i=0;i<hs.size();i++) {
			   if(hs.get(i).getHostResultID()==hostResultID) {
				   hs.remove(i); 
				   i--;
			   }
		   }
                    ses.setAttribute("hostScanResult", hs);
                    ses.setAttribute("delsuccess", 1);
			// 更改成功，跳转到mytask.jsp
		   request.getRequestDispatcher("showhostresults.jsp") .forward(request,response);
		
		
	}

}
