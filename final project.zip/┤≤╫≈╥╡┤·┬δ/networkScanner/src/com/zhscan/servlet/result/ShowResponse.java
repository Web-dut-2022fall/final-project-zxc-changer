package com.zhscan.servlet.result;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;


@WebServlet(name = "showResponse", urlPatterns = { "/showResponse" })
public class ShowResponse extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ShowResponse() {
        super();
    
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json; charset=utf-8");
		
		String code=request.getParameter("code");
		String helpmsg="show -info -p: 显示端口详情<br/>"
		                              +"show -info -w: 显示弱口令详情<br/>"
				+"show -result -h: 查看主机扫描结果<br/>"
				+"show -result -p: 查看端口扫描结果<br/>"                      
				+"show -result -v: 查看漏洞扫描结果<br/>"
				+"show -result -o: 查看操作系统识别结果<br/>"
				+"show -task -n: 显示待开始任务详情<br/>"
				+"show -task -u: 显示进行中任务详情<br/>"
				+"show -task -f: 显示已完成任务详情<br/>";
	
		String errormsg="Sorry, command'"+code+"' can not be identified, please input again!";
		JSONObject json=new JSONObject();
		
		PrintWriter out = response.getWriter();
		code=code+"- ";
		String[] cmd=code.split("-");
		
		/*
		 * for(int i=0;i<cmd.length;i++) { System.out.println(cmd[i]); }
		 */
		
		switch(cmd[0].trim()) {
		case "help":                //表示查看命令帮助
			try {
				json.put("msg", helpmsg);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			out.println(json);
			out.close();
			break;
		case "show":                
			switch(cmd[1].trim()) {
				case "info":                  //命令：查看信息
					switch(cmd[2].trim()) {
					case "p":                    //查看端口详情
						//request.getRequestDispatcher("portinfo.jsp").forward(request,response);
						//break;
						try {
							json.put("msg", "portinfo.jsp");
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						out.println(json);
						out.close();
						break;
					case "w":                  //显示弱口令详情
						try {
							json.put("msg", "weakPassInfo.jsp");
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						out.println(json);
						out.close();
						//request.getRequestDispatcher("weakPassInfo.jsp") .forward(request,response);
						break;
					default:
						try {
							json.put("msg", errormsg);
						} catch (JSONException e) {
							e.printStackTrace();
						}
						out.println(json);
						out.close();
					}
					break;
				case "result":                 //命令：查看扫描结果
					switch(cmd[2].trim()) {
					case "h":                    //查看主机扫描结果
						try {
							json.put("msg", "url");
							json.put("url", "showResults?tkType=0&findway=0&time=-1");
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						out.println(json);
						out.close();
						//response.sendRedirect("showResults?tkType=0&findway=0");
						break;
					case "p":                  //查看端口扫描结果
						try {
							json.put("msg", "url");
							json.put("url", "showResults?tkType=1&findway=0&time=-1");
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						out.println(json);
						out.close();
//						response.sendRedirect("showResults?tkType=1&findway=0");
						break;
                    case "v":                  //查看漏洞扫描结果
                    	try {
                    		json.put("msg", "url");
							json.put("url", "showResults?tkType=3&findway=0&time=-1");
						} catch (JSONException e1) {
							e1.printStackTrace();
						}
						out.println(json);
						out.close();
                    	//response.sendRedirect("showResults?tkType=3&findway=0");
						break;
                      case "o":                  //查看系统类型识别结果
                    		try {
                    			json.put("msg", "url");
    							json.put("url", "showResults?tkType=4&findway=0&time=-1");
    						} catch (JSONException e1) {
    							e1.printStackTrace();
    						}
    						out.println(json);
    						out.close();
                   // 	  response.sendRedirect("showResults?tkType=4&findway=0");
						break;
					default:
						try {
							json.put("msg", errormsg);
						} catch (JSONException e) {
							e.printStackTrace();
						}
						out.println(json);
						out.close();
							break;
					}
					break;
				case "task":                       //命令：查看任务
					switch(cmd[2].trim()) {
				
						  case "a":            //查看全部任务
							  try {
								  json.put("msg", "url");
	    							json.put("url", "listTasks?taskState=3&tType=-1");
	    						} catch (JSONException e1) {
	    							e1.printStackTrace();
	    						}
	    						out.println(json);
	    						out.close();
							//  response.sendRedirect("listTasks?taskState=3");
							  break;
						  case "n":          //查看待开始的任务
							  try {
								  json.put("msg", "url");
	    							json.put("url", "listTasks?taskState=0&tType=-1");
	    						} catch (JSONException e1) {
	    							e1.printStackTrace();
	    						}
	    						out.println(json);
	    						out.close();
							//  response.sendRedirect("listTasks?taskState=0");
							  break;
						  case "u":          //查看进行中的任务
							  try {
								  json.put("msg", "url");
	    							json.put("url", "listTasks?taskState=1&tType=-1");
	    						} catch (JSONException e1) {
	    							e1.printStackTrace();
	    						}
	    						out.println(json);
	    						out.close();
							//  response.sendRedirect("listTasks?taskState=1");
					           break;
						  case "f":          //查看已完成的任务
							  try {
								  json.put("msg", "url");
	    							json.put("url", "listTasks?taskState=2&tType=-1");
	    						} catch (JSONException e1) {
	    							e1.printStackTrace();
	    						}
	    						out.println(json);
	    						out.close();
							//  response.sendRedirect("listTasks?taskState=2");
							  break;
						  default:
							  try {
								  
									json.put("msg", errormsg);
								} catch (JSONException e) {
									e.printStackTrace();
								}
								out.println(json);
								out.close();
								 break;
						}
						break;
				default:
					try {
						json.put("msg", errormsg);
					} catch (JSONException e) {
						e.printStackTrace();
					}
					out.println(json);
					out.close();
				   break;
			}
			break;
		default:
			try {
				json.put("msg", errormsg);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			out.println(json);
			out.close();
			break;
		}
		
	}

}
