package com.zhscan.servlet.result;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Host_Task_User;
import com.zhscan.entity.Port_Task_User;
import com.zhscan.entity.User;
import com.zhscan.entity.Vul_Task_User;
import com.zhscan.service.TaskService;

@WebServlet(name = "showResults", urlPatterns = { "/showResults" })
public class ShowResults extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ShowResults() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		HttpSession session =request.getSession();
		TaskService service = new TaskService();
		User curUser = (User)session.getAttribute("user");
		String findway=request.getParameter("findway");
        int  tkType=Integer.parseInt(request.getParameter("tkType"));
        
        String name = request.getParameter("name");
        String t = request.getParameter("time");
        if(t!=null) {
        	int time=Integer.parseInt(t);
        	if(time==-1) {                                      //默认查看全部时间段
        		  if(null!=name&&!("").equals(name)) {               //只查看某个发起人的结果
                     	switch(tkType) {
                 	    case 0:   //主机扫描
                 	    	List<Host_Task_User> hostScanResult =null;
                 	    	if(null!=findway) {
                 	    	hostScanResult= service.listHostResultsByUserName(name);
                 	    	
                 	    		 for(Host_Task_User htu: hostScanResult) {
                 	    		//	 System.out.println(htu.getHostResultID());
                  					Date now = htu.getResultTime();
                 				        //时区转换
                  					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                 				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
                 				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
                 				        try {
                 							Date date = gmtDateFormat.parse(format1.format (now));
                 							htu.setResultTime(date);
                 						} catch (ParseException e) {
                 							e.printStackTrace();
                 						}
                 				        
                  			  }
                 		 		session.setAttribute("hostScanResult", hostScanResult);
                 		 		request.getRequestDispatcher("showhostresults.jsp") .forward(request,response);
                 			} 
                 	    	break;
                 	    case 1:       //端口扫描
                 	    	  
                 	    	List<Port_Task_User> portScanResult =null;
                 	    	
                 	    		
                 	    			portScanResult= service.listPortResultsByUserName(name);
                 	    		
                 	    		 for(Port_Task_User ptu: portScanResult) {
                  					Date now = ptu.getPortResultTime();
                 				        //时区转换
                  					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                 				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
                 				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
                 				        try {
                 							Date date = gmtDateFormat.parse(format1.format (now));
                 							ptu.setPortResultTime(date);
                 						} catch (ParseException e) {
                 							
                 						}
                  			  }
                 		 		session.setAttribute("portScanResult", portScanResult);
                 		 		request.getRequestDispatcher("showportresults.jsp") .forward(request,response);
                 	    	
                 	    	break;
                 	    case 3:
                 	    	  
                 	    	List<Vul_Task_User> vulScanResult =service.listVulResultsByUserName(name);
                 	    	
                 	    		 for(Vul_Task_User vtu: vulScanResult) {
                  					Date now = vtu.getVulResultTime();
                 				        //时区转换
                  					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                 				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
                 				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
                 				        try {
                 							Date date = gmtDateFormat.parse(format1.format (now));
                 							vtu.setVulResultTime(date);
                 						} catch (ParseException e) {
                 							
                 						}
                  			  }
                 		 		session.setAttribute("vulScanResult", vulScanResult);
                 		 		request.getRequestDispatcher("showvulresults.jsp") .forward(request,response);
                 	    
                 	    	break;
                 	    default:
                 	    	break;
                 	    }
                     	
                     }else {                             //没有发起人用户名的限制
                     	switch(tkType) {
                 	    case 0:   //主机扫描
                 	    	List<Host_Task_User> hostScanResult =null;

                 	    	if(null!=findway) {
                 	    		if(curUser.getUserRole()==0||Integer.parseInt(findway)==1) {   //管理员只查看自己的扫描结果
                 	    			  int id = curUser.getUserID();
                 	    			  hostScanResult= service.listHostResultsByUserID(id);
                 	    			
                 	    		}else if(Integer.parseInt(findway)==0&&curUser.getUserRole()==1){
                 	    			
                 	    	         hostScanResult= service.listAllHostResults();
                 	    	      
                 	    		}
                 	    		 for(Host_Task_User htu: hostScanResult) {
                 	    			 System.out.println(htu.getHostResultID());
                  					Date now = htu.getResultTime();
                 				        //时区转换
                  					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                 				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
                 				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
                 				        try {
                 							Date date = gmtDateFormat.parse(format1.format (now));
                 							htu.setResultTime(date);
                 						} catch (ParseException e) {
                 							e.printStackTrace();
                 						}
                 				        
                  			  }
                 		 		session.setAttribute("hostScanResult", hostScanResult);
                 		 		request.getRequestDispatcher("showhostresults.jsp") .forward(request,response);
                 			} 
                 	    	break;
                 	    case 1:       //端口扫描
                 	    	  
                 	    	List<Port_Task_User> portScanResult =null;
                 	    	if(null!=findway) {
                 	    		if(Integer.parseInt(findway)==1) {   //管理员只查看自己的扫描结果
                 	    			  int id = curUser.getUserID();
                 	    			  portScanResult= service.listPortResultsByUserID(id);
                 	    			 
                 	    		}else {
                 	    			portScanResult= service.listAllPortResults();
                 	    		}
                 	    		 for(Port_Task_User ptu: portScanResult) {
                  					Date now = ptu.getPortResultTime();
                 				        //时区转换
                  					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                 				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
                 				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
                 				        try {
                 							Date date = gmtDateFormat.parse(format1.format (now));
                 							ptu.setPortResultTime(date);
                 						} catch (ParseException e) {
                 							
                 						}
                  			  }
                 		 		session.setAttribute("portScanResult", portScanResult);
                 		 		request.getRequestDispatcher("showportresults.jsp") .forward(request,response);
                 	    	}
                 	    	break;
                 	    case 3:
                 	    	  
                 	    	List<Vul_Task_User> vulScanResult =null;
                 	    	if(null!=findway) {
                 	    		if(Integer.parseInt(findway)==1) {   //管理员只查看自己的扫描结果
                 	    			  int id = curUser.getUserID();
                 	    			  vulScanResult= service.listVulResultsByUserID(id);
                 	    			 
                 	    		}else {
                 	    			vulScanResult= service.listAllVulResults();
                 	    		}
                 	    		 for(Vul_Task_User vtu: vulScanResult) {
                  					Date now = vtu.getVulResultTime();
                 				        //时区转换
                  					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                 				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
                 				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
                 				        try {
                 							Date date = gmtDateFormat.parse(format1.format (now));
                 							vtu.setVulResultTime(date);
                 						} catch (ParseException e) {
                 							
                 						}
                  			  }
                 		 		session.setAttribute("vulScanResult", vulScanResult);
                 		 		request.getRequestDispatcher("showvulresults.jsp") .forward(request,response);
                 	    	}
                 	    	break;
                 	    default:
                 	    	break;
                 	    }
                     }
        	}else {             //查看固定时间段
        		if(null!=name&&!("").equals(name)) {               //只查看某个发起人的结果
                 	switch(tkType) {
             	    case 0:   //主机扫描
             	    	List<Host_Task_User> hostScanResult =null;
             	    	hostScanResult= service.listHostResultsByUserNameAndTime(name,time);
             	    	if(null!=findway) {
             	    		 for(Host_Task_User htu: hostScanResult) {
             	    		//	 System.out.println(htu.getHostResultID());
              					Date now = htu.getResultTime();
             				        //时区转换
              					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
             				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
             				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
             				        try {
             							Date date = gmtDateFormat.parse(format1.format (now));
             							htu.setResultTime(date);
             						} catch (ParseException e) {
             							e.printStackTrace();
             						}
             				        
              			  }
             		 		session.setAttribute("hostScanResult", hostScanResult);
             		 		request.getRequestDispatcher("showhostresults.jsp") .forward(request,response);
             			} 
             	    	break;
             	    case 1:       //端口扫描
             	    	  
             	    	List<Port_Task_User> portScanResult =null;
             	    
             	    		
             	    			portScanResult= service.listPortResultsByUserNameAndTime(name, time);
             	    		
             	    		 for(Port_Task_User ptu: portScanResult) {
              					Date now = ptu.getPortResultTime();
             				        //时区转换
              					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
             				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
             				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
             				        try {
             							Date date = gmtDateFormat.parse(format1.format (now));
             							ptu.setPortResultTime(date);
             						} catch (ParseException e) {
             							
             						}
              			  }
             		 		session.setAttribute("portScanResult", portScanResult);
             		 		request.getRequestDispatcher("showportresults.jsp") .forward(request,response);
             	    	
             	    	break;
             	    case 3:
             	    	  
             	    	List<Vul_Task_User> vulScanResult =null;
             	    	if(null!=findway) {
             	    	
             	    			vulScanResult= service.listVulResultsByUserNameAndTime(name, time);
             	    	
             	    		 for(Vul_Task_User vtu: vulScanResult) {
              					Date now = vtu.getVulResultTime();
             				        //时区转换
              					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
             				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
             				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
             				        try {
             							Date date = gmtDateFormat.parse(format1.format (now));
             							vtu.setVulResultTime(date);
             						} catch (ParseException e) {
             							
             						}
              			  }
             		 		session.setAttribute("vulScanResult", vulScanResult);
             		 		request.getRequestDispatcher("showvulresults.jsp") .forward(request,response);
             	    	}
             	    	break;
             	    default:
             	    	break;
             	    }
                 	
                 }else {
                 	switch(tkType) {
             	    case 0:   //主机扫描
             	    	List<Host_Task_User> hostScanResult =null;

             	    	if(null!=findway) {
             	    		
             	    	         hostScanResult= service.listHostResultsByTime(time);
             	    	      
             	    		 for(Host_Task_User htu: hostScanResult) {
             	    			 System.out.println(htu.getHostResultID());
              					Date now = htu.getResultTime();
             				        //时区转换
              					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
             				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
             				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
             				        try {
             							Date date = gmtDateFormat.parse(format1.format (now));
             							htu.setResultTime(date);
             						} catch (ParseException e) {
             							e.printStackTrace();
             						}
             				        
              			  }
             		 		session.setAttribute("hostScanResult", hostScanResult);
             		 		request.getRequestDispatcher("showhostresults.jsp") .forward(request,response);
             			} 
             	    	break;
             	    case 1:       //端口扫描
             	    	  
             	    	List<Port_Task_User> portScanResult =null;
             	    	if(null!=findway) {
             	    		portScanResult= service.listPortResultsByTime(time);
             	    		
             	    		 for(Port_Task_User ptu: portScanResult) {
              					Date now = ptu.getPortResultTime();
             				        //时区转换
              					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
             				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
             				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
             				        try {
             							Date date = gmtDateFormat.parse(format1.format (now));
             							ptu.setPortResultTime(date);
             						} catch (ParseException e) {
             							
             						}
              			  }
             		 		session.setAttribute("portScanResult", portScanResult);
             		 		request.getRequestDispatcher("showportresults.jsp") .forward(request,response);
             	    	}
             	    	break;
             	    case 3:
             	    	  
             	    	List<Vul_Task_User> vulScanResult =null;
             	    	
             	    	
             	    			vulScanResult= service.listVulResultsByTime(time);
             	    		
             	    		 for(Vul_Task_User vtu: vulScanResult) {
              					Date now = vtu.getVulResultTime();
             				        //时区转换
              					SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
             				        DateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
             				        gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+16:00"));
             				        try {
             							Date date = gmtDateFormat.parse(format1.format (now));
             							vtu.setVulResultTime(date);
             						} catch (ParseException e) {
             							
             						}
              			  }
             		 		session.setAttribute("vulScanResult", vulScanResult);
             		 		request.getRequestDispatcher("showvulresults.jsp") .forward(request,response);
             
             	    	break;
             	    default:
             	    	break;
             	    }
                 }

        		
        	}
        	 
        }

	}

}
