package com.zhscan.servlet.plagin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Host_Task_User;
import com.zhscan.entity.Plagin;
import com.zhscan.service.PlaginService;

@WebServlet(name = "delPlagin", urlPatterns = { "/delPlagin" })
public class DelPlaginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DelPlaginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		int plaginID = Integer.parseInt(request.getParameter("plaginID"));
		
		PlaginService ps =new PlaginService();
		ps.delPlagin(plaginID);
		
		 HttpSession ses=request.getSession();
		   List<Plagin> p = (List<Plagin>) ses.getAttribute("plagins"); 
		   for(int i=0;i<p.size();i++) {
			   if(p.get(i).getPlaginID()==plaginID) {
				   p.remove(i); 
				   i--;
			   }
		   }
             ses.setAttribute("plagins", p);
		
		request.setAttribute("delsuccess", 1 );
		   request.getRequestDispatcher("myplagin.jsp") .forward(request,response);
		
	}

}
