package com.zhscan.servlet.plagin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Plagin;
import com.zhscan.entity.User;
import com.zhscan.service.PlaginService;

@WebServlet(name = "listPlagins", urlPatterns = { "/listPlagins" })
public class ListPlaginsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ListPlaginsServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	       doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		HttpSession session =request.getSession();
		User u =(User)session.getAttribute("user");
		int userid = u.getUserID();
		
		PlaginService ps =new PlaginService();
		int way = Integer.parseInt(request.getParameter("way"));
		List<Plagin> plagins=null ;
		if(way!=1&&u.getUserRole()==1) {   //管理员可查看所有的
			plagins=ps.listAllPlagins(); 
		}else {
			plagins=ps.listPlaginByUserID(userid); 
		}	
		session.setAttribute("plagins", plagins);
		request.getRequestDispatcher("myplagin.jsp") .forward(request, response);
		
	}

}
