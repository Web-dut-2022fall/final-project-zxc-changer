package com.zhscan.servlet.plagin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.Plagin;
import com.zhscan.entity.User;
import com.zhscan.service.PlaginService;

@WebServlet(name = "modifyPlagin", urlPatterns = { "/modifyPlagin" })
public class ModifyPlaginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ModifyPlaginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		// 获取登录页面输入的用户名、电话、邮箱等信息
		HttpSession session=request.getSession();
		User u =(User)session.getAttribute("user");
		String id=request.getParameter("id");
		System.out.println(id);
		int plaginID = Integer.parseInt(id);
		String plaginName = request.getParameter("name");
	
		String plaginPath= request.getParameter("path");
		String plaginConfig = request.getParameter("conf");
	
		Plagin newPlagin =new Plagin(plaginID, plaginName, plaginPath, plaginConfig, u.getUserID());
		// 调用service完成修改操作。
		PlaginService service = new PlaginService();
	   service.modifyInfo(newPlagin, plaginID);
	   
	   List<Plagin> p = (List<Plagin>) session.getAttribute("plagins"); 
	   for(int i=0;i<p.size();i++) {
		   if(p.get(i).getPlaginID()==plaginID) {
			   p.remove(i); 
			   p.add(newPlagin);
		   }
	   }
         session.setAttribute("plagins", p);

	   request.setAttribute("updatesuccess", 1);
		// 更改成功，跳转到mgrxx.jsp
	//	response.sendRedirect(request.getContextPath() + "/registersuccess.jsp");
	   request.getRequestDispatcher("myplagin.jsp") .forward(request,response);
		
		
	}

}
