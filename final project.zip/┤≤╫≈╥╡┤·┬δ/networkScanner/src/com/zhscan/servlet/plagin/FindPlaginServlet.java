package com.zhscan.servlet.plagin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.zhscan.entity.Plagin;
import com.zhscan.service.PlaginService;

@WebServlet(name = "findPlagin", urlPatterns = { "/findPlagin" })
public class FindPlaginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FindPlaginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json; charset=utf-8");
		int plaginID=Integer.parseInt(request.getParameter("pid"));
		
		System.out.println(plaginID);
		
		PlaginService ps=new PlaginService();
		Plagin p = ps.findPlaginByPlaginID(plaginID);
		
		//request.getSession().setAttribute("tu", tu);
		JSONObject json=new JSONObject();
	
		try {
			json.put("id", plaginID);
			json.put("name", p.getPlaginName());
			json.put("path", p.getPlaginPath());
			json.put("conf", p.getConfig());
		
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter out = response.getWriter();
		out.println(json);
		out.close();
		
		
	}

}
