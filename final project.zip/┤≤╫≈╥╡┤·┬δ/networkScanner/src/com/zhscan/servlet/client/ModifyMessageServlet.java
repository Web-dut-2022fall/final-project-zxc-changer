package com.zhscan.servlet.client;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhscan.entity.User;
import com.zhscan.service.UserService;


@WebServlet(name = "modifyMessage", urlPatterns = { "/modifyMessage" })
public class ModifyMessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ModifyMessageServlet() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		// 获取登录页面输入的用户名、电话、邮箱等信息
		User orgUser = (User)request.getSession().getAttribute("user");
		int orgId=orgUser.getUserID();
		
		String userName = request.getParameter("userName");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		User newUser = new User();
		newUser.setUserName(userName);
		newUser.setPhoneNum(phone);
		newUser.setEmail(email);
		// 调用service完成修改操作。
		UserService service = new UserService();
	   service.ModifyInfo(newUser, orgId);
	   request.getSession().setAttribute("user", newUser);
	   request.setAttribute("success1",1);
		// 更改成功，跳转到mgrxx.jsp
	//	response.sendRedirect(request.getContextPath() + "/registersuccess.jsp");
	   request.getRequestDispatcher("mygrxx.jsp").forward(request,response);
	}
}
