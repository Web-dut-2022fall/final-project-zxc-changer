package com.zhscan.servlet.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhscan.entity.User;
import com.zhscan.exception.RegisterException;
import com.zhscan.service.UserService;

@WebServlet("/register")
public class RegistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RegistServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// 将表单提交的数据封装到javaBean
				User user = new User();
					request.setCharacterEncoding("utf-8");
					response.setCharacterEncoding("utf-8");
					response.setContentType("text/html; charset=utf-8");
					// 1.获取登录页面输入的用户名与密码
					String username = request.getParameter("userName");
					String password = request.getParameter("passWord");
					String telephone = request.getParameter("mobile");
					String email = request.getParameter("email");
					
					
					//获取request中的，也就是输入的veryCode，也就是那个input标签的内容
					String activecode=request.getParameter("veryCode");
					//获取存入session的码
					String activecode1=(String)request.getSession().getAttribute("veryCode");
					//获取之后得删除，防止下次验证错误
				
					request.getSession().removeAttribute("veryCode");
					PrintWriter out =null ;
					if(!(activecode!=null&&activecode1.equals(activecode))) {
						//回复错误信息并转发到原来的页面
						out= response.getWriter();
						out.write("<script>");
						out.write("alert('验证码输入错误！');");
		     			out.write("location.href='reg.jsp'");
		     			out.write("</script>");
		     			out.close();
						return;
					}
					
					user.setUserName(username);
					user.setUserPass(password);
					user.setPhoneNum(telephone);
					user.setEmail(email);
					user.setUserRole(0);
					
				// 调用service完成注册操作。
				UserService service = new UserService();
				try {
					service.regist(user);
				} catch (RegisterException e) {
					e.printStackTrace();
					out = response.getWriter();
					out.write("<script>");
					out.write("alert('用户注册失败！');");
	     			out.write("location.href='reg.jsp'");
	     			out.write("</script>");
					out.close();
					return;
				}
				// 注册成功，跳转到registersuccess.jsp
				response.sendRedirect(request.getContextPath() + "/registersuccess.jsp");
	}

}
