package com.zhscan.servlet.client;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhscan.entity.User;
import com.zhscan.service.UserService;

@WebServlet(name = "modifyRole", urlPatterns = { "/modifyRole" })
public class ModifyRoleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ModifyRoleServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String role = request.getParameter("userRole");
		String id = request.getParameter("userID");
		
		if(null!=role&&null!=id&&(!("").equals(role))&&(!("").equals(id))) {
			int urole = Integer.parseInt(role);
			int uid=Integer.parseInt(id);
			UserService service = new UserService();
			   service.ModifyRole(urole, uid);
			   List<User> users =  service.listAllUsers();
			   request.getSession().setAttribute("users", users);
			   request.setAttribute("updatesuccess", 1);
			   request.getRequestDispatcher("usermanager.jsp") .forward(request,response);
		}else {
			PrintWriter out =null ;
				//回复错误信息并转发到原来的页面
				out= response.getWriter();
				out.write("<script>");
				out.write("alert('修改权限失败！');");
	 			out.write("location.href='usermanager.jsp'");
	 			out.write("</script>");
	 			out.close();
				return;
		}
	}

}
