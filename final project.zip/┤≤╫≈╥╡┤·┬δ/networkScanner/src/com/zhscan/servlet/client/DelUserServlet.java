package com.zhscan.servlet.client;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zhscan.entity.User;
import com.zhscan.service.UserService;

/**
 * Servlet implementation class DelUser
 */
@WebServlet(name = "delUser", urlPatterns = { "/delUser" })
public class DelUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DelUserServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		// 获取用户id
	
		String userId=request.getParameter("userID");
		// 调用service完成删除操作。
		UserService service = new UserService();
		   service.delUser(userId);
		   HttpSession hs=request.getSession();
	   List<User> us = (List<User>) hs.getAttribute("users"); 
	   for(int i=0;i<us.size();i++) {
		   if(String.valueOf(us.get(i).getUserID()).equals(userId)) {
			   us.remove(i); 
			   i--;
		   }
	   }
	   hs.setAttribute("users", us);
		// 更改成功，跳转到usermanager.jsp
	   request.setAttribute("delsuccess", 1);
	   request.getRequestDispatcher("usermanager.jsp") .forward(request,response);
	}

}
