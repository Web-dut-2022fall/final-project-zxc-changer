package com.zhscan.servlet.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zhscan.dao.UserDao;
import com.zhscan.entity.User;
import com.zhscan.service.UserService;
import com.zhscan.util.AESUtils;

@WebServlet(name = "modifyPassword", urlPatterns = { "/modifyPassword" })
public class ModifyPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ModifyPasswordServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
	
		// 获取登录页面输入的用户名、电话、邮箱等信息
		User orgUser = (User)request.getSession().getAttribute("user");
		String orgPass = orgUser.getUserPass();
		
		
		  //System.out.println(orgPass); 
		
		String orgPassword = request.getParameter("orgPassWord");
		PrintWriter out =null ;
		if(null!=orgPassword&&null!=orgPass) {
			String orgPasswd = AESUtils.decryptData(UserDao.getKey(), orgPass);
			String newPassword = request.getParameter("passWord");
			
			
			if(null!=orgPasswd) {
				if(!orgPasswd.equals(orgPassword)) {
					//回复错误信息并转发到原来的页面
					out= response.getWriter();
					out.write("<script>");
					out.write("alert('原密码为空或输入错误！');");
		 			out.write("location.href='mygrxx.jsp'");
		 			out.write("</script>");
		 			out.close();
					return;
				}else {
					int orgId=orgUser.getUserID();
					// 调用service完成数据库修改操作。
					UserService service = new UserService();
				   String key=service.ModifyPass(newPassword, orgId);
				   
					orgUser.setUserPass(AESUtils.encryptData(key, newPassword));
					
				   request.getSession().setAttribute("user", orgUser);
				   request.setAttribute("success",1);
					// 更改成功，跳转到修改成功界面
				   request.getRequestDispatcher("modifyPassSuccess.jsp") .forward(request,response);
				}
			}else {
				out= response.getWriter();
				out.write("<script>");
				out.write("alert('原密码为空或输入错误！');");
	 			out.write("location.href='mygrxx.jsp'");
	 			out.write("</script>");
	 			out.close();
				return;
			}
		}else {
			out= response.getWriter();
			out.write("<script>");
			out.write("alert('原密码为空或输入错误！');");
 			out.write("location.href='mygrxx.jsp'");
 			out.write("</script>");
 			out.close();
			return;
		}
		
	
		
	}

}
