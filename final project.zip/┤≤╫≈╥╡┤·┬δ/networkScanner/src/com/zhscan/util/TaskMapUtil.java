package com.zhscan.util;

import java.util.HashMap;
import java.util.Map;

public class TaskMapUtil {
	    
	    static Map<Integer, String> map = new HashMap<>();
	    static Map<Integer, String> map2 = new HashMap<>();
	    public static void putMap() {
	    	map.put(0,"主机扫描");
			map.put(1, "常用端口扫描");
			map.put(2, "选定端口扫描");
			map.put(3, "弱口令扫描");
			map.put(4, "操作系统识别");
			map.put(5, "安全漏洞扫描");
	    }
	    public static void putMap2() {
	    	map2.put(0,"待开始");
			map2.put(1, "进行中");
			map2.put(2, "已完成");
	
	    }
	    public static Map<Integer, String> getMap() {
	    	putMap();
	    	return map;
	    }
	    public static Map<Integer, String> getMap2() {
	    	putMap2();
	    	return map2;
	    }
}
