package com.zhscan.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.zhscan.dao.TaskDao;
import com.zhscan.entity.Host;
import com.zhscan.entity.Host_Task_User;
import com.zhscan.entity.Port;
import com.zhscan.entity.Port_Task_User;
import com.zhscan.entity.Task;
import com.zhscan.entity.Task_User;
import com.zhscan.entity.Vul;
import com.zhscan.entity.Vul_Task_User;
import com.zhscan.util.DataSourceUtils;

public class TaskService {
	
	private TaskDao tdao = new TaskDao();
	
	public int addTask(Task task) {     //添加新任务
		// 调用dao完成注册操作
		int id=0;
					try {
                          id=tdao.addTask(task);
					} catch (Exception e) {
						e.printStackTrace();
					}
					return id;
	}

	
	public void delTask(int taskID) {    //删除任务
		try {
            tdao.delTask(taskID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public List<Task> findTaskByUserID(int userID) {    //根据用户ID列出任务
		List<Task> tasks=null;
		try {
			tasks=tdao. findTaskByUserID(userID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tasks;
	}
	
	public List<Task> findTaskByUserName(String userName) { //根据用户姓名和任务类型列出任务
		List<Task> tasks=null;
		try {
			tasks=tdao. findTaskByUserName(userName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tasks;
	}
	
	public List<Task> findTaskByUserNameAndState(String userName , int taskState) { //根据用户姓名和任务类型列出任务
		List<Task> tasks=null;
		try {
			tasks=tdao. findTaskByUserNameAndState(userName, taskState);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tasks;
	}
	
	public List<Task> findTaskByUserNameAndType(String userName , int taskType) { //根据用户姓名和任务类型列出任务
		List<Task> tasks=null;
		try {
			tasks=tdao. findTaskByUserNameAndState(userName, taskType);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tasks;
	}
	public List<Task> findTaskByUserNameAndTypeAndState(String userName, int taskType, int taskState){  
		//根据用户ID和任务状态查找任务
		List<Task> tasks=null;
		   try {
			tasks=tdao.findTaskByUserNameAndTypeAndState(userName ,taskType, taskState);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	 return tasks;
	}
	
	public List<Task> findTaskByUserIDAndState(int userID,  int taskState){  
		//根据用户ID和任务状态查找任务
		List<Task> tasks=null;
		   try {
			tasks=tdao. findTaskByUserIDAndState(userID , taskState);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	 return tasks;
	}
	
	public List<Task> findTaskByUserIDAndStateAndType(int userID,  int taskState, int taskType){
		List<Task> tasks=null;
		   try {
			tasks=tdao. findTaskByUserIDAndStateAndType(userID , taskState, taskType);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	 return tasks;
	}
	
	public List<Task> findTaskByUserIDAndType(int userID, int taskType){
		List<Task> tasks=null;
		   try {
			tasks=tdao. findTaskByUserIDAndType(userID, taskType);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	 return tasks;
	}
	
	public List<Task> findTaskByState(int taskState){  
		//根据任务状态查找任务
		List<Task> tasks=null;
		   try {
			tasks=tdao. findTaskByState( taskState);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	 return tasks;
	}

	
	public Task_User findTaskByTaskID(int taskID) {    //根据任务ID列出任务
		Task_User tu=null;
		try {
			tu=tdao. findTaskByTaskID(taskID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tu;
	}
	
	public List<Task> listAllTasks(){
		List<Task> tasks=null;
		try {
			tasks=tdao. listAllTasks();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tasks;
	}
	
	public List<Task> findTaskByType(int taskType){
		List<Task> tasks=null;
		try {
			tasks=tdao. findTaskByType(taskType);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tasks;
	}
	
	public List<Task> findTaskByStateAndType(int taskState, int taskType){
		List<Task> tasks=null;
		try {
			tasks=tdao. findTaskByStateAndType(taskState, taskType);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tasks;
	}
	
	public void updateTask(Task newTask, int taskID) {   //根据任务id更新任务
		try {
			tdao.updateTask(newTask, taskID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//更新任务状态
	public void updateTaskState(int taskType, int taskID) {  
		try {
			tdao.updateTaskState(taskType, taskID);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//将主机扫描结果插入数据库
	public void addResult(Host host) {
		try {
			tdao.addHostResult(host);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//将端口扫描结果插入数据库
	public void addPortResult(Port port) {
		try {
			tdao.addPortResult(port);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//三表连接查询的结果，列出所有扫描结果
	public List<Host_Task_User> listAllHostResults(){
		List<Host_Task_User> hosts=null;
		try {
			hosts = tdao.listAllHostResults();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hosts;
	}
	
	public List<Host_Task_User> listHostResultsByUserID(int userid){
		List<Host_Task_User> hosts=null;
		try {
			hosts = tdao.listHostResultsByUserID(userid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hosts;
	}
	
	public List<Port_Task_User> listAllPortResults(){
		List<Port_Task_User> posts=null;
		try {
			posts = tdao.listAllPortResults();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return posts;
	}
	
	public List<Port_Task_User> listPortResultsByUserID(int userid){
		List<Port_Task_User> posts=null;
		try {
			posts = tdao.listPortResultsByUserID(userid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return posts;
	}
	
	public List<Vul_Task_User> listAllVulResults(){
		List<Vul_Task_User> vul=null;
		try {
			vul = tdao.listAllVulResults();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vul;
	}
	
	
	
	public List<Vul_Task_User> listVulResultsByUserID(int userid){
		List<Vul_Task_User> vul=null;
		try {
			vul = tdao.listVulResultsByUserID(userid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vul;
	}
	
	
	
	public void delHostResult(int hostResultID) {    //删除主机扫描结果
		try {
            tdao.delHostResult(hostResultID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void delPortResult(int portResultID) {    //删除端口扫描结果
		try {
            tdao.delPortResult(portResultID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void delVulResult(int vulResultID) {
		try {
            tdao.delVulResult(vulResultID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Host findHostByHostResultID(long resultID) {
		Host h=null;
		try {
           h= tdao. findHostByHostResultID(resultID);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return h;
	}


	public void addVulResult(Vul v) {
		try {
			tdao.addVulResult(v);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	//根据用户名模糊查询所有主机扫描结果
		public List<Host_Task_User> listHostResultsByUserName(String userName)  {
			List<Host_Task_User> list=null;
			try {
				list = tdao.listHostResultsByUserName(userName);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
	
	
		//根据用户名模糊查询所有端口扫描结果
		public List<Port_Task_User> listPortResultsByUserName(String userName)  {
			List<Port_Task_User> list=null;
			try {
				list = tdao.listPortResultsByUserName(userName);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
	
		public List<Vul_Task_User> listVulResultsByUserName(String userName)  {
			List<Vul_Task_User> list=null;
			try {
				list = tdao.listVulResultsByUserName(userName);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
	
		public List<Host_Task_User> listHostResultsByUserNameAndTime(String userName, int time){
			List<Host_Task_User> list=null;
			try {
				switch(time) {
				case 0:
					list = tdao.listHostResultsByUserNameAndTime0(userName);
					break;
				case 1:
					list = tdao.listHostResultsByUserNameAndTime1(userName);
					break;
				case 2:
					list = tdao.listHostResultsByUserNameAndTime2(userName);
			     	break;
				case 3:
					list = tdao.listHostResultsByUserNameAndTime3(userName);
			     	break;
			     default:
			    	 break;
				}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
	
		public List<Port_Task_User> listPortResultsByUserNameAndTime(String userName, int time){
			List<Port_Task_User> list=null;
			try {
				switch(time) {
				case 0:
					list = tdao.listPortResultsByUserNameAndTime0(userName);
					break;
				case 1:
					list = tdao.listPortResultsByUserNameAndTime1(userName);
					break;
				case 2:
					list = tdao.listPortResultsByUserNameAndTime2(userName);
			     	break;
				case 3:
					list = tdao.listPortResultsByUserNameAndTime3(userName);
			     	break;
			     default:
			    	 break;
				}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
		
		public List<Vul_Task_User> listVulResultsByUserNameAndTime(String userName, int time){
			List<Vul_Task_User> list=null;
			try {
				switch(time) {
				case 0:
					list = tdao.listVulResultsByUserNameAndTime0(userName);
					break;
				case 1:
					list = tdao.listVulResultsByUserNameAndTime1(userName);
					break;
				case 2:
					list = tdao.listVulResultsByUserNameAndTime2(userName);
			     	break;
				case 3:
					list = tdao.listVulResultsByUserNameAndTime3(userName);
			     	break;
			     default:
			    	 break;
				}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
		
		
		
		public List<Host_Task_User> listHostResultsByTime(int time){
			List<Host_Task_User> list=null;
			try {
				switch(time) {
				case 0:
					list = tdao.listHostResultsByTime0();
					break;
				case 1:
					list = tdao.listHostResultsByTime1();
					break;
				case 2:
					list = tdao.listHostResultsByTime2();
			     	break;
				case 3:
					list = tdao.listHostResultsByTime3();
			     	break;
			     default:
			    	 break;
				}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
		
		public List<Port_Task_User> listPortResultsByTime(int time){
			List<Port_Task_User> list=null;
			try {
				switch(time) {
				case 0:
					list = tdao.listPortResultsByTime0();
					break;
				case 1:
					list = tdao.listPortResultsByTime1();
					break;
				case 2:
					list = tdao.listPortResultsByTime2();
			     	break;
				case 3:
					list = tdao.listPortResultsByTime3();
			     	break;
			     default:
			    	 break;
				}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
		
		public List<Vul_Task_User> listVulResultsByTime(int time){
			List<Vul_Task_User> list=null;
			try {
				switch(time) {
				case 0:
					list = tdao.listVulResultsByTime0();
					break;
				case 1:
					list = tdao.listVulResultsByTime1();
					break;
				case 2:
					list = tdao.listVulResultsByTime2();
			     	break;
				case 3:
					list = tdao.listVulResultsByTime3();
			     	break;
			     default:
			    	 break;
				}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
	
	
	
	
	
	
}
