package com.zhscan.service;

import java.sql.SQLException;
import java.util.List;

import com.zhscan.dao.AssetDao;
import com.zhscan.entity.Asset;
import com.zhscan.entity.Asset_User;

public class AssetService {
	private AssetDao adao = new AssetDao();
	
	public List<Asset_User> listAllPortResults(){
		List<Asset_User> assets=null;
		try {
			assets = adao.listAllAssets();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return assets;
	}
	
	public List<Asset_User> listPortResultsByUserID(int userid){
		List<Asset_User> assets=null;
		try {
			assets = adao.listAssetsByUserID(userid);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return assets;
	}
	
	public void delAsset(int assetID) {
		try {
			adao.delAsset(assetID);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Asset findAssetByID(int assetID) {
		Asset asset=null;
		try {
			asset = adao.findAssetByID(assetID);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return asset;
	}
	
	public void addAsset(Asset a) {
		try {
			adao.addAsset(a);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updateAssetByIPAndUserID(String osType, String ip, int userID) {
		try {
			adao.updateAssetByIPAndUserID(osType, ip, userID);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
