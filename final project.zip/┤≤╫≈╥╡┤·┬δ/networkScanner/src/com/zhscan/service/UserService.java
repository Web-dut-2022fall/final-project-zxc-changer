package com.zhscan.service;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.zhscan.dao.UserDao;
import com.zhscan.entity.User;
import com.zhscan.exception.LoginException;
import com.zhscan.exception.RegisterException;

public class UserService {
	    private UserDao dao = new UserDao();
	
	    //注册操作
	    public void regist(User user) throws RegisterException {
			// 调用dao完成注册操作
			try {
				dao.addUser(user);
			} catch (Exception e) {
				e.printStackTrace();
				throw new RegisterException("注冊失败");
			}
		}
	    
	    
	 // 登录操作
		public User login(String username, String password) throws LoginException {
			try {
				String PHONE_NUMBER_REG = "^(1[3-9])\\d{9}$";
				Pattern pattern = Pattern.compile(PHONE_NUMBER_REG); // 编译正则表达式
				Matcher matcher = pattern.matcher(username); // 创建给定输入模式的匹配器
				boolean bool = matcher.matches();
				User user=null;
				if(bool) { // 如果验证通过，说明输入的是电话号
					//根据登录时表单输入的电话号和密码，查找用户
					 user = dao.findUserByPhoneAndPassword(username, password);
				} else {
					 user = dao.findUserByUsernameAndPassword(username, password);
				}
				
				//根据登录时表单输入的用户名和密码，查找用户
				if (user != null) {
						return user;
				}else {
					throw new LoginException("用户名或密码错误");
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new LoginException("登录失败");
			}
		}
		
		 //修改密码外其他信息
        public void ModifyInfo(User user, int userID) {
        	try {
				dao.updateUser(user,userID);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
        //修改密码
        public String ModifyPass(String newPass, int userID) {
        	String key="";
        	try {
				key=dao.updateUserPass(newPass,userID);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	return key;
		}
        
        //根据id删除用户
        public void delUser(String userID) {
        	try {
				dao.delUser(userID);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
        
        //显示所有用户
        public List<User> listAllUsers() {
        	try {
				return dao.listAllUsers();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
		}
        
        //根据用户ID修改用户权限
        public void ModifyRole(int userRole, int userID) {
        	try {
				dao.updateUserRole(userRole, userID);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
        
        
	
	  //根据ID找用户名 
        public User findUserById(int userID) { User u= null; try { u=
	  dao.findUserById(userID); } catch (SQLException e) { e.printStackTrace(); }
	  return u; }
	 
		
}
