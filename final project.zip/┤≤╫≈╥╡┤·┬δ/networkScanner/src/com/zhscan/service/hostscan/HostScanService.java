package com.zhscan.service.hostscan;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.zhscan.entity.Host;
import com.zhscan.entity.Task;
import com.zhscan.util.IpUtils;

public class HostScanService implements Runnable{
    private int step;
    private Task task;
    private static List<Host> hosts ;
    private volatile boolean exit = false;  

    public HostScanService(int step, Task task) {
		super();
		this.step = step;
		this.task = task;
	}

	public int getStep() {
		return step;
	}

	public void setStep(int step) {
		this.step = step;
	}

	public static List<Host> getHosts() {
		return hosts;
	}
	
	public void setExit(boolean exit) {
		this.exit = exit;
	}

	public void run() {
		while (!exit) {
			try {
			      hosts = begin();
				} catch (InterruptedException e) {
		
				}
      }
	}
	
	public  List<Host> begin() throws InterruptedException {
		    long beginIP = IpUtils.ipToLong(task.getBeginIP());
		    long endIP = IpUtils.ipToLong(task.getEndIP());
        setStep(step);
        List<Long> list = new LinkedList<>();
        for (long i = beginIP; i <endIP ; i+=step) {
            list.add(i);
        }

        ExecutorService service = Executors.newFixedThreadPool(list.size());
        long startTime = System.currentTimeMillis();
        int length = list.size() - 1;
        for (int i = 0; i <= length&&(!exit); i++) {

            ScanHandler scanHandler = new ScanHandler();            
            long start = list.get(i);
            long end = start + step;
            if (i == length) {
                scanHandler.setParams(start,Math.min(end, endIP),endIP);
            } else {
                scanHandler.setParams(start,end,endIP);
            }
            service.execute(scanHandler);
            
        }

        service.shutdown();
        
        List<Host> success =null;
        while(!exit){
            if(service.isTerminated()){
                long end = System.currentTimeMillis();
                System.out.println("耗费时间为：" + (end - startTime) + "ms");
                System.out.println("---------------------------------------");
               
                success = new OpenList().getSuccess();
               // System.out.println(success);
                for(int i=0;i< success.size();i++){  
                   success.get(i).setResponseTime(end-startTime);
                   // System.out.println(success.get(i).toString());
                }
                break;
            }
        }
        exit=true;
        return success;
    }
}

