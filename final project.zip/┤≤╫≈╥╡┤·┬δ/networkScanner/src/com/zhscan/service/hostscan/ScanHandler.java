package com.zhscan.service.hostscan;

import java.io.IOException;
import java.net.InetAddress;

import com.zhscan.util.IpUtils;

public class ScanHandler implements Runnable{

    private OpenList openIP=new OpenList();

    private long start;

    private long end;
    private long end_IP;
    
    
//	private boolean isSleep = true;
//	private boolean isStop = false;
	/*
	 * public void setStop(boolean stop) { this.isStop = stop; }
	 */

    public void setParams(long start, long end,long end_IP){
        this.start=start;
        this.end=end;
        this.end_IP=end_IP;
    }

    public void scan(long item){
        String currentIp=IpUtils.longToIp(item);        
        System.out.println("testing ip: "+currentIp);   
        //输出测试，便于观察到正在扫描的主机IP
        try{
            InetAddress address = InetAddress.getByName(currentIp);
            if(address.isReachable(100))
                openIP.addList(currentIp);
        }catch (IOException e) {
        }
    }


    @Override
    public void run() {
        for(long item = start; item < end; item++){
            if (Thread.currentThread().isInterrupted()) {
                System.out.println("interrupted!");
                break;
            }
            scan(item);
        }
        if(end== end_IP){
            scan(end);
        }
        
    	}
}

