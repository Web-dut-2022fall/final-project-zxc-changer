package com.zhscan.service.hostscan;

import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.zhscan.entity.Host;


public class OpenList{

	private  static List<Host> success=new ArrayList<>();
    public List<Host> getSuccess() {
        return success;
    }

    void addList(String i){
        Host host=new Host(i,getHostNameByAdress(i),getMacByIp(i),0);
        success.add(host);
    }

    public String getHostNameByAdress(String ip){
        String[] ii=ip.split("\\.");
        byte[] ips=new byte[4];
        for(int i=0;i<4;i++){
            ips[i]=(byte)(Integer.parseInt(ii[i]));
        }
        try {
        	InetAddress inetAddress = InetAddress.getByAddress(ips);
        	if (inetAddress .getHostName().equals(ip)) {  
        		return " ";
        	}
        	return InetAddress.getByAddress(ips).getHostName();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return " ";
    }

    public static String command(String cmd) throws Exception{
        Process process = Runtime.getRuntime().exec(cmd);

        process.waitFor();

        InputStream in = process.getInputStream();

        StringBuilder result = new StringBuilder();

        byte[] data = new byte[256];

        while(in.read(data) != -1){
            String encoding = System.getProperty("sun.jnu.encoding");

            result.append(new String(data,encoding));

        }
        return result.toString();
    }

    public  String getMacByIp(String ip){
        String result = null;
        try {
            //result = command("ping "+ip+" -n 2");
           // if(result.contains("TTL")){
               result = command("arp -a "+ip);
            // }
        } catch (Exception e) {
            e.printStackTrace();
        }
        String regExp = "([0-9A-Fa-f]{2})([-:][0-9A-Fa-f]{2}){5}";

        Pattern pattern = Pattern.compile(regExp);

        Matcher matcher = pattern.matcher(result);

        StringBuilder mac = new StringBuilder();

        while (matcher.find()) {
            String temp = matcher.group();
            mac.append(temp);
        }
        return mac.toString();
    }
}