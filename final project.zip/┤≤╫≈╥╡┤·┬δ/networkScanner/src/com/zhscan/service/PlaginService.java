package com.zhscan.service;

import java.sql.SQLException;
import java.util.List;

import com.zhscan.dao.PlaginDao;
import com.zhscan.entity.Plagin;

public class PlaginService {
	private PlaginDao pdao = new PlaginDao();

	public List<Plagin> listAllPlagins() {
		List<Plagin> plagins = null;
		try {
			plagins = pdao.listAllPlagins();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return plagins;
	}

	public List<Plagin> listPlaginByUserID(int userid) {
		List<Plagin> plagins = null;
		try {
			plagins = pdao.listPlaginByUserID(userid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return plagins;
	}

	public Plagin findPlaginByNameAndUserID(String plaginname, int userid) {
		Plagin plagins = null;
		try {
			plagins = pdao.findPlaginByNameAndUserID(plaginname, userid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return plagins;
	}

	public Plagin findPlaginByPlaginID(int plaginid) { 
		Plagin plagin = null;
		try {
	 plagin= pdao.findPlaginByPlaginID(plaginid); }
		catch (SQLException e) { 
			e.printStackTrace();
		}
	return plagin;
	}

	public void addPlagin(Plagin p) {
		try {
			pdao.addPlagin(p);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void delPlagin(int plaginID) {
		try {
			pdao.delPlagin(plaginID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void modifyInfo(Plagin newPlag, int plaginID) {
		try {
			pdao.modifyInfo(newPlag, plaginID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
