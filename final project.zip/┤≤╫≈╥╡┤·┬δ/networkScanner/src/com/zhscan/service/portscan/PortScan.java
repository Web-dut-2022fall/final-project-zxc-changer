package com.zhscan.service.portscan;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.zhscan.entity.Port;
import com.zhscan.entity.Task;


public class PortScan {
   
	private int step;
    private Task task;
   
    public PortScan(int step, Task task) {
		super();
		this.step = step;
		this.task = task;
	}
	public int getStep() {
		return step;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public Task getTask() {
		return task;
	}
	public void setTask(Task task) {
		this.task = task;
	}
	

	public  List<Port> portScan () throws InterruptedException {
		 int begin_port = task.getBeginPort();
		 int end_port = task.getEndPort();		   
         setStep(step);
         String ip = task.getDestHostIP();
         
        List<Integer> list = new LinkedList<>();
        for (int i = begin_port; i < end_port ; i+=step) {
            list.add(i);
        }

        ExecutorService service = Executors.newFixedThreadPool(list.size());
        long startTime = System.currentTimeMillis();
        int length = list.size() - 1;
        for (int i = 0; i <= length; i++) {
            ScannerThread scannerThread = new ScannerThread();
            int start = list.get(i);
            int end = start + step;
            if (i == length) {
                scannerThread.setParams(start,Math.min(end, end_port), ip,  end_port);
            } else {
                scannerThread.setParams(start,end, ip , end_port);
            }
            service.execute(scannerThread);
        }

        service.shutdown();
        
        List<Port> success =null;
        while(true){
            if(service.isTerminated()){
                long end = System.currentTimeMillis();
                System.out.println("耗费时间为：" + (end - startTime) + "ms");
                System.out.println("---------------------------------------");
               
                success = new SuccessList().getSuccess();
                for(int i=0;i< success.size();i++){  
                	success.get(i).setDestHostIP(ip);
                    success.get(i).setResTime(end-startTime);
                    // System.out.println(success.get(i).toString());
                 }
                //System.out.println(success);
                break;
            }
        }
        return success;
    }

}



