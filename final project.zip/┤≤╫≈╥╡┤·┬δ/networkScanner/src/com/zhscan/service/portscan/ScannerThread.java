package com.zhscan.service.portscan;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class ScannerThread implements Runnable {
    private SuccessList OpenPort=new SuccessList();
    private int start;
    private int end;
    private String IP;
    private int lastPort;

    public void setParams(int start, int end, String IP, int lastPort) {
        this.start = start;
        this.end = end;
        this.IP = IP;
        this.lastPort = lastPort;
    }

public void scan(int item){
    System.out.println("testing Prot"+item);
    Socket socket=null;
    try{
        socket=new Socket();
        SocketAddress address=new InetSocketAddress(IP, item);
        socket.connect(address,100);
        socket.close();
        OpenPort.addList(item);
    }catch (IOException e) {
    }
}


    @Override
    public void run() {
        for(int item = start; item < end; item++){
            scan(item);
        }
        if(end==lastPort){
           scan(end);
        }
    }
}