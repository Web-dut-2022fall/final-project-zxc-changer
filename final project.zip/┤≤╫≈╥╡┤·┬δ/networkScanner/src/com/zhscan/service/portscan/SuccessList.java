package com.zhscan.service.portscan;

import java.util.ArrayList;
import java.util.List;

import com.zhscan.entity.Port;

public class SuccessList {
    //private static StringBuffer success = new StringBuffer();
    private static List<Port> success=new ArrayList<>();
    
    public  List<Port> getSuccess() {
        return success;
    }
    
    void addList(int i) {
    	Port port = new Port("", i, 0);
        success.add(port);
    }
}
