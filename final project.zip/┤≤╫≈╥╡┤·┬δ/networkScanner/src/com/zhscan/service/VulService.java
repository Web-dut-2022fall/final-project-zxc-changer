package com.zhscan.service;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.zhscan.dao.VulDao;
import com.zhscan.entity.WeakPwd;

public class VulService {
//	String log="";
	private VulDao vdao = new VulDao();
	private static List<String> vuls = new ArrayList<String>(); 

	public static List<String> getVuls() {
		return vuls;
	}

	public WeakPwd findWeakPwdByID(int weakPwdID) {
		WeakPwd weakPwd=null;
		try {
			weakPwd = vdao.findAssetByID(weakPwdID);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return weakPwd;
	}
	
	//扫描引擎后续会完善代码提高效率
    public boolean  pluginEngine(ArrayList<String> al,String iphost)throws Exception{
          List<Boolean> bool =new ArrayList<Boolean>();
    	
    	//加载外部lib文件下jar包和vuln下的POC
        System.out.println(iphost);
        ArrayList<URL> urllist=new ArrayList<>();

        File file=new File("D:/eclipse/workspace/graduationDesign/networkScanner/vuln");
       // System.out.println(file.getPath());
        URL url=file.toURI().toURL();
       // System.out.println(url);
        urllist.add(url);

        ArrayList<String> jars=getJar();
        for(String jar:jars){
        
        	urllist.add((new File("D:/eclipse/workspace/graduationDesign/networkScanner/lib/"+jar)).toURI().toURL());
        }
        URL[] urls=urllist.toArray(new URL[urllist.size()]);

        ClassLoader loader=new URLClassLoader(urls);//创建类载入器
        for(String vuln:al) {
           // System.out.println(vuln);
           System.out.println(vuln.split("\\.")[0]);
            Class<?> cls = loader.loadClass(vuln.split("\\.")[0]);
            Object obj=cls.newInstance();

            //获取POC的info
            HashMap<String,String> hm=new HashMap<>();   //存放属性对
            Field[] fields = cls.getDeclaredFields();
            for(Field field:fields){
                if(field.getGenericType().toString().equals("class java.lang.String")){
                    field.setAccessible(true);
                    hm.put(field.getName(),(String) field.get(obj));
                }else{
                  //log=log+obj.getClass().getName()+"插件属性应该为String类型"+"\r\n";
                }
            }
            System.out.println(hm.toString());
            //调用check
            Method method=cls.getMethod("check", String.class);
            try {
              Object o = method.invoke(obj, "http://"+iphost+":8080");
            //	Object o = method.invoke(obj, iphost);
                String result = String.valueOf(o);
                if (!result.equals("NOT_FIND_BUG")) {
             //     log=log+hm.toString()+"\r\n"+hm.get("name") + ":\t" + result +"\t"+iphost+"\r\n";
                 vuls.add(hm.toString());
                	bool.add(false);
                }else{
                //	log=log+result+"\r\n";
                }
            }catch (Exception e){
                e.printStackTrace();
             String  log="插件："+obj.getClass().getName()+"，扫描目标("+iphost+")发生异常，请检查，并重新扫描 ";
                vuls.add(log);
                bool.add(false);
            }
        }
      //  boolean flag=true;    //程序状态反馈，true为正常执行，false为异常状态。
       // return log;
        if(bool.isEmpty()) {
        	return true;
        }
        return false;
    }
    
    //加载lib下的jar包
    public static ArrayList<String> getJar(){
        ArrayList<String> jars=new ArrayList<>();
       // File file=new File("D:/eclipse/workspace/graduationDesign/networkScanner/WebContent/WEB-INF/lib");
        File file=new File("D:/eclipse/workspace/graduationDesign/networkScanner/lib");
        try {
            if (file.exists() & file.isDirectory()) {
                for (String jar : file.list()) {
                    if(jar.endsWith(".jar")) {
                        jars.add(jar);
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return jars;
    }
    
    //收集插件
    public ArrayList<String> getPlugin() {
        ArrayList<String> plugins=new ArrayList<>();

      //  File file=new File("vuln");
        File file=new File("D:/eclipse/workspace/graduationDesign/networkScanner/vuln");
        try {
            if (file.exists() & file.isDirectory()) {
                for (String vuln : file.list()) {
                    plugins.add(vuln);
                }
            }
        }catch (Exception e){
        
    }
        return plugins;
    }
}
