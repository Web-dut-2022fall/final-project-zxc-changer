package com.zhscan.entity;

import java.io.Serializable;

public class Task_User implements Serializable{
	private int taskID;
	private String taskName;
	private int taskState;
	private int taskType;
	private String beginIP;
	private String endIP;
	private int beginPort;
	private int endPort;
	private String destHostIP;
	private int userID;
	private String userName;
	public int getTaskID() {
		return taskID;
	}
	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public int getTaskState() {
		return taskState;
	}
	public void setTaskState(int taskState) {
		this.taskState = taskState;
	}
	public int getTaskType() {
		return taskType;
	}
	public void setTaskType(int taskType) {
		this.taskType = taskType;
	}
	public String getBeginIP() {
		return beginIP;
	}
	public void setBeginIP(String beginIP) {
		this.beginIP = beginIP;
	}
	public String getEndIP() {
		return endIP;
	}
	public void setEndIP(String endIP) {
		this.endIP = endIP;
	}
	public int getBeginPort() {
		return beginPort;
	}
	public void setBeginPort(int beginPort) {
		this.beginPort = beginPort;
	}
	public int getEndPort() {
		return endPort;
	}
	public void setEndPort(int endPort) {
		this.endPort = endPort;
	}
	public String getDestHostIP() {
		return destHostIP;
	}
	public void setDestHostIP(String destHostIP) {
		this.destHostIP = destHostIP;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public Task_User() {
		super();
	}
	public Task_User(int taskID, String taskName, int taskState, int taskType, String beginIP, String endIP,
			int beginPort, int endPort, String destHostIP, int userID, String userName) {
		super();
		this.taskID = taskID;
		this.taskName = taskName;
		this.taskState = taskState;
		this.taskType = taskType;
		this.beginIP = beginIP;
		this.endIP = endIP;
		this.beginPort = beginPort;
		this.endPort = endPort;
		this.destHostIP = destHostIP;
		this.userID = userID;
		this.userName = userName;
	}
	
}
