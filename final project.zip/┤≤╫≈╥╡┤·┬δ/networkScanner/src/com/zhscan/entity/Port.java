package com.zhscan.entity;

import java.io.Serializable;
import java.util.Date;

public class Port implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long portResultID;
	private String destHostIP;
	private int openPort;
	private long resTime;
	private int taskID;
	private int userID;
	private Date  portResultTime;

	
	public long getPortResultID() {
		return portResultID;
	}
	public void setPortResultID(int portResultID) {
		this.portResultID = portResultID;
	}
	public String getDestHostIP() {
		return destHostIP;
	}
	public void setDestHostIP(String destHostIP) {
		this.destHostIP = destHostIP;
	}
	public int getOpenPort() {
		return openPort;
	}
	public void setOpenPort(int openPort) {
		this.openPort = openPort;
	}
	public long getResTime() {
		return resTime;
	}
	public void setResTime(long resTime) {
		this.resTime = resTime;
	}
	public Date getPortResultTime() {
		return portResultTime;
	}
	public void setPortResultTime(Date portResultTime) {
		this.portResultTime = portResultTime;
	}
	public int getTaskID() {
		return taskID;
	}
	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}

	
	public Port() {
		super();
	}
	public Port(String destHostIP, int openPort, long resTime) {
		super();
		this.destHostIP = destHostIP;
		this.openPort = openPort;
		this.resTime = resTime;
	}
    
	@Override
	public String toString() {
		 return "portID="+portResultID+", destHostIP="+destHostIP+",  openPort="+openPort+", responseTime="+resTime+"\n";
	}
}
