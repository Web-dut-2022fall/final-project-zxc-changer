package com.zhscan.entity;

import java.io.Serializable;

public class Asset_User implements Serializable {
	    private int assetID;
	    private String assetName;
	    private String assetIP;
	    private String osType;
	    private int userID;
	    private String userName;
		public int getAssetID() {
			return assetID;
		}
		public void setAssetID(int assetID) {
			this.assetID = assetID;
		}
		public String getAssetName() {
			return assetName;
		}
		public void setAssetName(String assetName) {
			this.assetName = assetName;
		}
		public String getAssetIP() {
			return assetIP;
		}
		public void setAssetIP(String assetIP) {
			this.assetIP = assetIP;
		}
		public String getOsType() {
			return osType;
		}
		public void setOsType(String osType) {
			this.osType = osType;
		}
		public int getUserID() {
			return userID;
		}
		public void setUserID(int userID) {
			this.userID = userID;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
	    
	
}
