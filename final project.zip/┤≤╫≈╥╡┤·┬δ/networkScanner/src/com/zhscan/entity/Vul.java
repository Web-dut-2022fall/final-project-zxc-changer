package com.zhscan.entity;

import java.io.Serializable;
import java.util.Date;

public class Vul implements Serializable{
      /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long vulID;
      private String vulName;
      private String vulDesp;
      private Date vulResultTime;
      private String destHostIP;
        private int taskID;
        private int userID;
        
		public Vul() {
			super();
		}
		
	/*
	 * public Vul(String vulName, String vulDesp, int taskID, int userID) { super();
	 * this.vulName = vulName; this.vulDesp = vulDesp; this.taskID = taskID;
	 * this.userID = userID; }
	 */
		
		public Vul(String vulName, String vulDesp, String destHostIP,  int taskID, int userID) {
			super();
			this.vulName = vulName;
			this.vulDesp = vulDesp;
			this.destHostIP=destHostIP;
			this.taskID = taskID;
			this.userID = userID;
		}
		

		public long getVulID() {
			return vulID;
		}
		public void setVulID(long vulID) {
			this.vulID = vulID;
		}
		public String getVulName() {
			return vulName;
		}
		public void setVulName(String vulName) {
			this.vulName = vulName;
		}
		public String getVulDesp() {
			return vulDesp;
		}
		public void setVulDesp(String vulDesp) {
			this.vulDesp = vulDesp;
		}

		public int getTaskID() {
			return taskID;
		}
		public void setTaskID(int taskID) {
			this.taskID = taskID;
		}
		
		public Date getVulResultTime() {
			return vulResultTime;
		}

		public void setVulResultTime(Date vulResultTime) {
			this.vulResultTime = vulResultTime;
		}

		public int getUserID() {
			return userID;
		}
		public void setUserID(int userID) {
			this.userID = userID;
		}

		public String getDestHostIP() {
			return destHostIP;
		}

		public void setDestHostIP(String destHostIP) {
			this.destHostIP = destHostIP;
		}
		
        
}
