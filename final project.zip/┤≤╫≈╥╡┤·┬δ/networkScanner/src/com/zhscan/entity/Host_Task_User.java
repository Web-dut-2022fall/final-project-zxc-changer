package com.zhscan.entity;

import java.io.Serializable;
import java.util.Date;

public class Host_Task_User implements Serializable{
	private long hostResultID;
	private String hostIP;
	private String hostName;
    private String hostMAC;
    private long responseTime;
    private int taskID;
    private int userID;
    private Date  resultTime;
   private String userName;
   private String taskName;

public long getHostResultID() {
	return hostResultID;
}
public void setHostResultID(long hostResultID) {
	this.hostResultID = hostResultID;
}
public String getHostIP() {
	return hostIP;
}
public void setHostIP(String hostIP) {
	this.hostIP = hostIP;
}
public String getHostName() {
	return hostName;
}
public void setHostName(String hostName) {
	this.hostName = hostName;
}
public String getHostMAC() {
	return hostMAC;
}
public void setHostMAC(String hostMAC) {
	this.hostMAC = hostMAC;
}
public long getResponseTime() {
	return responseTime;
}
public void setResponseTime(long responseTime) {
	this.responseTime = responseTime;
}
public int getTaskID() {
	return taskID;
}
public void setTaskID(int taskID) {
	this.taskID = taskID;
}
public int getUserID() {
	return userID;
}
public void setUserID(int userID) {
	this.userID = userID;
}
public Date getResultTime() {
	return resultTime;
}
public void setResultTime(Date resultTime) {
	this.resultTime = resultTime;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getTaskName() {
	return taskName;
}
public void setTaskName(String taskName) {
	this.taskName = taskName;
}

public Host_Task_User() {
	
}

	
}
