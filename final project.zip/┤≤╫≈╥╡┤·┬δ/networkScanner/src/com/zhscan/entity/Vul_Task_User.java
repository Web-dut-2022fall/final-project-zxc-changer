package com.zhscan.entity;

import java.io.Serializable;
import java.util.Date;

public class Vul_Task_User implements Serializable{
	private long vulID;
    private String vulName;
    private String vulDesp;
    private Date vulResultTime;
    
    private int taskID;
    private int userID;
    private String taskName;
      private String userName;
	
	
	public long getVulID() {
		return vulID;
	}
	public void setVulID(long vulID) {
		this.vulID = vulID;
	}
	
	public String getVulName() {
		return vulName;
	}
	public void setVulName(String vulName) {
		this.vulName = vulName;
	}
	public String getVulDesp() {
		return vulDesp;
	}
	public void setVulDesp(String vulDesp) {
		this.vulDesp = vulDesp;
	}
	public Date getVulResultTime() {
		return vulResultTime;
	}
	public void setVulResultTime(Date vulResultTime) {
		this.vulResultTime = vulResultTime;
	}
	public int getTaskID() {
		return taskID;
	}
	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Vul_Task_User() {
		super();
	}

      
}
