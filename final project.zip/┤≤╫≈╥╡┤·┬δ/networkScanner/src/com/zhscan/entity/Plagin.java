package com.zhscan.entity;

import java.io.Serializable;

public class Plagin implements Serializable{
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int plaginID;
	private String plaginName;
	private String plaginPath;
	private String config;
	private int userID;
	public int getPlaginID() {
		return plaginID;
	}
	public void setPlaginID(int plaginID) {
		this.plaginID = plaginID;
	}
	public String getPlaginName() {
		return plaginName;
	}
	public void setPlaginName(String plaginName) {
		this.plaginName = plaginName;
	}
	public String getPlaginPath() {
		return plaginPath;
	}
	public void setPlaginPath(String plaginPath) {
		this.plaginPath = plaginPath;
	}
	
	public String getConfig() {
		return config;
	}
	public void setConfig(String config) {
		this.config = config;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public Plagin() {
		
	}
	public Plagin(int plaginID, String plaginName, String plaginPath, String config, int userID) {
		super();
		this.plaginID= plaginID;
		this.plaginName = plaginName;
		this.plaginPath = plaginPath;
		this.config = config;
		this.userID = userID;
	}
	public Plagin(String plaginName, String plaginPath, String config, int userID) {
		super();
		this.plaginName = plaginName;
		this.plaginPath = plaginPath;
		this.config = config;
		this.userID = userID;
	}
	
}
