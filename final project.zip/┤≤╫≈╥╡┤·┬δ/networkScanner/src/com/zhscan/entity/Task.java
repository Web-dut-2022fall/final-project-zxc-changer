package com.zhscan.entity;

import java.io.Serializable;
import java.util.Collection;

public class Task implements Serializable{
	/*
	 *
	 */
	private static final long serialVersionUID = 1L;
	private int taskID;
	private String taskName;
	private int taskState;
	private int taskType;
	private String beginIP;
	private String endIP;
	private int beginPort;
	private int endPort;
	private String destHostIP;
	private int userID;

	public int getTaskID() {
		return taskID;
	}
	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public int getTaskState() {
		return taskState;
	}
	public void setTaskState(int taskState) {
		this.taskState = taskState;
	}
	public int getTaskType() {
		return taskType;
	}
	public void setTaskType(int taskType) {
		this.taskType = taskType;
	}
	public String getBeginIP() {
		return beginIP;
	}
	public void setBeginIP(String beginIP) {
		this.beginIP = beginIP;
	}
	public String getEndIP() {
		return endIP;
	}
	public void setEndIP(String endIP) {
		this.endIP = endIP;
	}
	public int getBeginPort() {
		return beginPort;
	}
	public void setBeginPort(int beginPort) {
		this.beginPort = beginPort;
	}
	public int getEndPort() {
		return endPort;
	}
	public void setEndPort(int endPort) {
		this.endPort = endPort;
	}
	public String getDestHostIP() {
		return destHostIP;
	}
	public void setDestHostIP(String destHostIP) {
		this.destHostIP = destHostIP;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	
	public Task() {
		
	}
	public Task(String taskName, int taskState, int taskType, String beginIP, String endIP, String destHostIP,int userID) {
		super();
		this.taskName = taskName;
		this.taskState = taskState;
		this.taskType = taskType;
		this.beginIP = beginIP;
		this.endIP = endIP;
		this.destHostIP = destHostIP;
		this.userID = userID;
	}
	
	public Task(String taskName, int taskState, int taskType, int beginPort, int endPort, String destHostIP,
			int userID) {
		super();
		this.taskName = taskName;
		this.taskState = taskState;
		this.taskType = taskType;
		this.beginIP="";
		this.endIP="";
		this.beginPort = beginPort;
		this.endPort = endPort;
		this.destHostIP = destHostIP;
		this.userID = userID;
	}
	public Task(String taskName, int taskState, int taskType, String beginIP, String endIP, int beginPort,
			int endPort, String destHostIP, int userID) {
		super();
		this.taskName = taskName;
		this.taskState = taskState;
		this.taskType = taskType;
		this.beginIP = beginIP;
		this.endIP = endIP;
		this.beginPort = beginPort;
		this.endPort = endPort;
		this.destHostIP = destHostIP;
		this.userID = userID;
	}
	
	
}
