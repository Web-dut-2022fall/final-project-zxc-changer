package com.zhscan.entity;

import java.io.Serializable;
import java.util.Date;

public class Port_Task_User implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long portResultID;
	private String destHostIP;
	private int openPort;
	private String portType;
	private String portDesp;
	private long resTime;
	private Date portResultTime;
	private int taskID;
	private int userID;
	 private String userName;
	   private String taskName;
	public long getPortResultID() {
		return portResultID;
	}
	public void setPortResultID(long portResultID) {
		this.portResultID = portResultID;
	}
	public String getDestHostIP() {
		return destHostIP;
	}
	public void setDestHostIP(String destHostIP) {
		this.destHostIP = destHostIP;
	}
	public int getOpenPort() {
		return openPort;
	}
	public void setOpenPort(int openPort) {
		this.openPort = openPort;
	}
	
	public String getPortType() {
		return portType;
	}
	public void setPortType(String portType) {
		this.portType = portType;
	}
	public String getPortDesp() {
		return portDesp;
	}
	public void setPortDesp(String portDesp) {
		this.portDesp = portDesp;
	}
	public long getResTime() {
		return resTime;
	}
	public void setResTime(long resTime) {
		this.resTime = resTime;
	}
	public int getTaskID() {
		return taskID;
	}
	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public Date getPortResultTime() {
		return portResultTime;
	}
	public void setPortResultTime(Date portResultTime) {
		this.portResultTime = portResultTime;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	   
	public Port_Task_User(){
		
	}
	   
}
