package com.zhscan.entity;

import java.io.Serializable;

public class Asset implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int assetID;
    private String assetName;
    private String assetIP;
    private String osType;
    private int userID;
	
	public int getAssetID() {
		return assetID;
	}
	public void setAssetID(int assetID) {
		this.assetID = assetID;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetIP() {
		return assetIP;
	}
	public void setAssetIP(String assetIP) {
		this.assetIP = assetIP;
	}
	public String getOsType() {
		return osType;
	}
	public void setOsType(String osType) {
		this.osType = osType;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public Asset() {
		
	}
	public Asset(String assetName, String assetIP, String osType, int userID) {
		super();
		this.assetName = assetName;
		this.assetIP = assetIP;
		this.osType = osType;
		this.userID = userID;
	}
}
