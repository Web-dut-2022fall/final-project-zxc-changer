package com.zhscan.entity;

public class WeakPwd {
	private int weakPwd;
	private String weakPwdType;
	public int getWeakPwd() {
		return weakPwd;
	}
	public void setWeakPwd(int weakPwd) {
		this.weakPwd = weakPwd;
	}
	public String getWeakPwdType() {
		return weakPwdType;
	}
	public void setWeakPwdType(String weakPwdType) {
		this.weakPwdType = weakPwdType;
	}
	
	public WeakPwd() {
		super();
	}
	public WeakPwd(int weakPwd, String weakPwdType) {
		super();
		this.weakPwd = weakPwd;
		this.weakPwdType = weakPwdType;
	}
	
}
