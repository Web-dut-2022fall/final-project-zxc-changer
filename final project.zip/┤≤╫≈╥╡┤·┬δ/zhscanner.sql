/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 80016
 Source Host           : localhost:3306
 Source Schema         : zhscanner

 Target Server Type    : MySQL
 Target Server Version : 80016
 File Encoding         : 65001

 Date: 17/06/2021 11:56:09
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for asset
-- ----------------------------
DROP TABLE IF EXISTS `asset`;
CREATE TABLE `asset`  (
  `assetID` int(10) NOT NULL AUTO_INCREMENT,
  `assetName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `assetIP` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `osType` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userID` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`assetID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of asset
-- ----------------------------
INSERT INTO `asset` VALUES (13, 'B0KYZYNQYZ8A7PP', '192.168.43.1', 'Windows --- Chrome-90.0.4430.93', 18);
INSERT INTO `asset` VALUES (17, 'B0KYZYNQYZ8A7PP', '192.168.43.1', '', 18);

-- ----------------------------
-- Table structure for host
-- ----------------------------
DROP TABLE IF EXISTS `host`;
CREATE TABLE `host`  (
  `hostResultID` bigint(10) NOT NULL AUTO_INCREMENT,
  `hostIP` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `hostName` char(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `hostMAC` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `responseTime` bigint(10) NULL DEFAULT NULL,
  `taskID` int(10) NULL DEFAULT NULL,
  `userID` int(10) NULL DEFAULT NULL,
  `resultTime` timestamp(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`hostResultID`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 142 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of host
-- ----------------------------
INSERT INTO `host` VALUES (139, '192.168.43.97', 'B0KYZYNQYZ8A7PP', '', 9768, 452, 18, '2021-05-12 15:24:50.000000');
INSERT INTO `host` VALUES (138, '192.168.43.1', 'B0KYZYNQYZ8A7PP', '04-d3-b5-9a-6e-33', 9768, 452, 18, '2021-05-12 15:24:50.000000');
INSERT INTO `host` VALUES (137, '192.168.43.97', 'B0KYZYNQYZ8A7PP', '', 9892, 450, 18, '2021-05-12 15:09:57.000000');
INSERT INTO `host` VALUES (136, '192.168.43.1', 'B0KYZYNQYZ8A7PP', '04-d3-b5-9a-6e-33', 9892, 450, 18, '2021-05-12 15:09:57.000000');
INSERT INTO `host` VALUES (140, '192.168.43.1', 'B0KYZYNQYZ8A7PP', '04-d3-b5-9a-6e-33', 9885, 459, 18, '2021-05-21 19:31:09.000000');
INSERT INTO `host` VALUES (141, '192.168.43.97', 'B0KYZYNQYZ8A7PP', '', 9885, 459, 18, '2021-05-21 19:31:09.000000');

-- ----------------------------
-- Table structure for plagin
-- ----------------------------
DROP TABLE IF EXISTS `plagin`;
CREATE TABLE `plagin`  (
  `plaginID` int(10) NOT NULL AUTO_INCREMENT,
  `plaginName` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `plaginPath` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `config` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userID` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`plaginID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of plagin
-- ----------------------------
INSERT INTO `plagin` VALUES (3, 'Nmap - Zenmap', 'D:/zh学习/NMAP/zenmap.exe', 'nz://', 18);
INSERT INTO `plagin` VALUES (13, 'Burpsuite.bat', 'D:/eclipse/workspace/graduationDesign/networkScanner/WebContent/WEB-INF/upload/Burpsuite.bat', 'Burpsuit', 18);

-- ----------------------------
-- Table structure for port
-- ----------------------------
DROP TABLE IF EXISTS `port`;
CREATE TABLE `port`  (
  `portResultID` bigint(20) NOT NULL AUTO_INCREMENT,
  `destHostIP` char(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `openPort` int(10) NULL DEFAULT NULL,
  `resTime` bigint(10) NULL DEFAULT NULL,
  `taskID` int(10) NULL DEFAULT NULL,
  `userID` int(10) NULL DEFAULT NULL,
  `portResultTime` timestamp(0) NOT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`portResultID`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 489 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of port
-- ----------------------------
INSERT INTO `port` VALUES (488, '192.168.43.1', 139, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (487, '192.168.43.1', 5476, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (486, '192.168.43.1', 135, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (485, '192.168.43.1', 4174, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (484, '192.168.43.1', 4173, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (483, '192.168.43.1', 3832, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (482, '192.168.43.1', 1034, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (481, '192.168.43.1', 912, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (480, '192.168.43.1', 1030, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (479, '192.168.43.1', 3306, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (478, '192.168.43.1', 1027, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (477, '192.168.43.1', 1026, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (476, '192.168.43.1', 1025, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (475, '192.168.43.1', 445, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (473, '192.168.43.97', 139, 2017, 138, 18, '2021-05-12 15:27:44');
INSERT INTO `port` VALUES (472, '192.168.43.97', 135, 2017, 138, 18, '2021-05-12 15:27:44');
INSERT INTO `port` VALUES (471, '192.168.43.1', 139, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (474, '192.168.43.1', 902, 2623, 462, 18, '2021-05-21 20:04:10');
INSERT INTO `port` VALUES (469, '192.168.43.1', 1036, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (438, '192.168.43.1', 1025, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (437, '192.168.43.1', 902, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (461, '192.168.43.1', 902, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (462, '192.168.43.1', 445, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (463, '192.168.43.1', 1025, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (464, '192.168.43.1', 1026, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (465, '192.168.43.1', 1027, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (466, '192.168.43.1', 3306, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (467, '192.168.43.1', 1031, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (468, '192.168.43.1', 912, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (411, '192.168.43.1', 139, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (410, '192.168.43.1', 135, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (409, '192.168.43.1', 912, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (408, '192.168.43.1', 1036, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (407, '192.168.43.1', 1031, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (406, '192.168.43.1', 3306, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (405, '192.168.43.1', 445, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (404, '192.168.43.1', 1027, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (403, '192.168.43.1', 1026, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (402, '192.168.43.1', 1025, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (401, '192.168.43.1', 902, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (412, '192.168.43.1', 2719, 2259, 446, 54, '2021-05-12 15:00:14');
INSERT INTO `port` VALUES (460, '192.168.43.1', 139, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (459, '192.168.43.1', 135, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (458, '192.168.43.1', 1036, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (457, '192.168.43.1', 912, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (456, '192.168.43.1', 1031, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (455, '192.168.43.1', 3306, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (454, '192.168.43.1', 1027, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (453, '192.168.43.1', 1026, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (452, '192.168.43.1', 1025, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (451, '192.168.43.1', 445, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (450, '192.168.43.1', 902, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (449, '192.168.43.1', 3440, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (448, '192.168.43.1', 2719, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (447, '192.168.43.1', 139, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (445, '192.168.43.1', 912, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (444, '192.168.43.1', 1036, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (443, '192.168.43.1', 1031, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (442, '192.168.43.1', 3306, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (441, '192.168.43.1', 445, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (440, '192.168.43.1', 1027, 2167, 436, 18, '2021-05-12 15:03:40');
INSERT INTO `port` VALUES (439, '192.168.43.1', 1026, 2167, 436, 18, '2021-05-12 15:03:40');

-- ----------------------------
-- Table structure for portinfo
-- ----------------------------
DROP TABLE IF EXISTS `portinfo`;
CREATE TABLE `portinfo`  (
  `portInfoID` int(10) NOT NULL AUTO_INCREMENT,
  `portID` int(10) NULL DEFAULT NULL,
  `portType` char(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `portDesp` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`portInfoID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 662 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of portinfo
-- ----------------------------
INSERT INTO `portinfo` VALUES (1, 0, 'TCP', 'Reserved');
INSERT INTO `portinfo` VALUES (2, 1, 'TCP', 'TCP Port Service Multiplexer');
INSERT INTO `portinfo` VALUES (3, 2, 'TCP', 'Death');
INSERT INTO `portinfo` VALUES (4, 5, 'TCP', 'Remote Job Entry,yoyo');
INSERT INTO `portinfo` VALUES (5, 7, 'TCP', 'Echo');
INSERT INTO `portinfo` VALUES (6, 11, 'TCP', 'Skun');
INSERT INTO `portinfo` VALUES (7, 12, 'TCP', 'Bomber');
INSERT INTO `portinfo` VALUES (8, 16, 'TCP', 'Skun');
INSERT INTO `portinfo` VALUES (9, 17, 'TCP', 'Skun');
INSERT INTO `portinfo` VALUES (10, 18, 'TCP', '消息传输协议，skun');
INSERT INTO `portinfo` VALUES (11, 19, 'TCP', 'Skun');
INSERT INTO `portinfo` VALUES (12, 20, 'TCP', 'FTP Data,Amanda');
INSERT INTO `portinfo` VALUES (13, 21, 'TCP', '文件传输,Back Construction,Blade Runner,Doly Trojan,Fore,FTP trojan,Invisible FTP,Larva,WebEx,WinCrash');
INSERT INTO `portinfo` VALUES (14, 22, 'TCP', '远程登录协议');
INSERT INTO `portinfo` VALUES (15, 23, 'TCP', '远程登录（Telnet),Tiny Telnet Server (');
INSERT INTO `portinfo` VALUES (16, 25, 'TCP', '电子邮件(SMTP),Ajan,Antigen,Email Password Sender,Happy 99,Kuang2,ProMail trojan,Shtrilitz,Stealth,Tapiras,Terminator,WinPC,WinSpy,Haebu Coceda');
INSERT INTO `portinfo` VALUES (17, 27, 'TCP', 'Assasin');
INSERT INTO `portinfo` VALUES (18, 28, 'TCP', 'Amanda');
INSERT INTO `portinfo` VALUES (19, 29, 'TCP', 'MSG ICP');
INSERT INTO `portinfo` VALUES (20, 30, 'TCP', 'Agent 40421');
INSERT INTO `portinfo` VALUES (21, 31, 'TCP', 'Agent 31,Hackers Paradise,Masters Paradise,Agent 40421');
INSERT INTO `portinfo` VALUES (22, 37, 'TCP', 'Time,ADM worm');
INSERT INTO `portinfo` VALUES (23, 39, 'TCP', 'SubSARI');
INSERT INTO `portinfo` VALUES (24, 41, 'TCP', 'DeepThroat,Foreplay');
INSERT INTO `portinfo` VALUES (25, 42, 'TCP', 'Host Name Server');
INSERT INTO `portinfo` VALUES (26, 43, 'TCP', 'WHOIS');
INSERT INTO `portinfo` VALUES (27, 44, 'TCP', 'Arctic');
INSERT INTO `portinfo` VALUES (28, 48, 'TCP', 'DRAT');
INSERT INTO `portinfo` VALUES (29, 49, 'TCP', '主机登录协议');
INSERT INTO `portinfo` VALUES (30, 50, 'TCP', 'DRAT');
INSERT INTO `portinfo` VALUES (31, 51, 'TCP', 'IMP Logical Address Maintenance,Fuck Lamers Backdoor');
INSERT INTO `portinfo` VALUES (32, 52, 'TCP', 'MuSka52,Skun');
INSERT INTO `portinfo` VALUES (33, 53, 'TCP', 'DNS,Bonk (DOS Exploit)');
INSERT INTO `portinfo` VALUES (34, 54, 'TCP', 'MuSka52');
INSERT INTO `portinfo` VALUES (35, 58, 'TCP', 'DMSetup');
INSERT INTO `portinfo` VALUES (36, 59, 'TCP', 'DMSetup');
INSERT INTO `portinfo` VALUES (37, 63, 'TCP', 'whois++');
INSERT INTO `portinfo` VALUES (38, 64, 'TCP', 'Communications Integrator');
INSERT INTO `portinfo` VALUES (39, 65, 'TCP', 'TACACS-Database Service');
INSERT INTO `portinfo` VALUES (40, 66, 'TCP', 'Oracle SQL*NET,AL-Bareki');
INSERT INTO `portinfo` VALUES (41, 67, 'TCP', 'Bootstrap Protocol Server');
INSERT INTO `portinfo` VALUES (42, 68, 'TCP', 'Bootstrap Protocol Client');
INSERT INTO `portinfo` VALUES (43, 69, 'TCP', 'TFTP,W32.Evala.Worm,BackGate Kit,Nimda,Pasana,Storm,Storm worm,Theef,Worm.Cycle.a');
INSERT INTO `portinfo` VALUES (44, 70, 'TCP', 'Gopher服务，ADM worm');
INSERT INTO `portinfo` VALUES (45, 79, 'TCP', '用户查询（Finger),Firehotcker,ADM worm');
INSERT INTO `portinfo` VALUES (46, 80, 'TCP', '超文本服务器（Http),Executor,RingZero');
INSERT INTO `portinfo` VALUES (47, 81, 'TCP', 'Chubo,Worm.Bbeagle.q');
INSERT INTO `portinfo` VALUES (48, 82, 'TCP', 'Netsky-Z');
INSERT INTO `portinfo` VALUES (49, 88, 'TCP', 'Kerberos krb5服务');
INSERT INTO `portinfo` VALUES (50, 99, 'TCP', 'Hidden Port');
INSERT INTO `portinfo` VALUES (51, 102, 'TCP', '消息传输代理');
INSERT INTO `portinfo` VALUES (52, 108, 'TCP', 'SNA网关访问服务器');
INSERT INTO `portinfo` VALUES (53, 109, 'TCP', 'Pop2');
INSERT INTO `portinfo` VALUES (54, 110, 'TCP', '电子邮件（Pop3),ProMail');
INSERT INTO `portinfo` VALUES (55, 113, 'TCP', 'Kazimas,Auther Idnet');
INSERT INTO `portinfo` VALUES (56, 115, 'TCP', '简单文件传输协议');
INSERT INTO `portinfo` VALUES (57, 118, 'TCP', 'SQL Services,Infector 1.4.2');
INSERT INTO `portinfo` VALUES (58, 119, 'TCP', '新闻组传输协议（Newsgroup(Nntp)),Happy 99');
INSERT INTO `portinfo` VALUES (59, 121, 'TCP', 'JammerKiller,Bo jammerkillah');
INSERT INTO `portinfo` VALUES (60, 123, 'TCP', '网络时间协议(NTP),Net Controller');
INSERT INTO `portinfo` VALUES (61, 129, 'TCP', 'Password Generator Protocol');
INSERT INTO `portinfo` VALUES (62, 133, 'TCP', 'Infector 1.x');
INSERT INTO `portinfo` VALUES (63, 135, 'TCP', '微软DCE RPC end-point mapper服务');
INSERT INTO `portinfo` VALUES (64, 137, 'TCP', '微软Netbios Name服务（网上邻居传输文件使用）');
INSERT INTO `portinfo` VALUES (65, 138, 'TCP', '微软Netbios Name服务（网上邻居传输文件使用）');
INSERT INTO `portinfo` VALUES (66, 139, 'TCP', '微软Netbios Name服务（用于文件及打印机共享）');
INSERT INTO `portinfo` VALUES (67, 142, 'TCP', 'NetTaxi');
INSERT INTO `portinfo` VALUES (68, 143, 'TCP', 'Internet 邮件访问协议版本 4（IMAP4)');
INSERT INTO `portinfo` VALUES (69, 146, 'TCP', 'FC Infector,Infector');
INSERT INTO `portinfo` VALUES (70, 150, 'TCP', 'NetBIOS Session Service');
INSERT INTO `portinfo` VALUES (71, 156, 'TCP', 'SQL服务器');
INSERT INTO `portinfo` VALUES (72, 161, 'TCP', 'Snmp');
INSERT INTO `portinfo` VALUES (73, 162, 'TCP', 'Snmp-Trap');
INSERT INTO `portinfo` VALUES (74, 170, 'TCP', 'A-Trojan');
INSERT INTO `portinfo` VALUES (75, 177, 'TCP', 'X Display管理控制协议');
INSERT INTO `portinfo` VALUES (76, 179, 'TCP', 'Border网关协议（BGP)');
INSERT INTO `portinfo` VALUES (77, 190, 'TCP', '网关访问控制协议（GACP)');
INSERT INTO `portinfo` VALUES (78, 194, 'TCP', 'Irc');
INSERT INTO `portinfo` VALUES (79, 197, 'TCP', '目录定位服务（DLS)');
INSERT INTO `portinfo` VALUES (80, 220, 'TCP', 'Internet 邮件访问协议版本 3（IMAP3)');
INSERT INTO `portinfo` VALUES (81, 256, 'TCP', 'Nirvana');
INSERT INTO `portinfo` VALUES (82, 315, 'TCP', 'The Invasor');
INSERT INTO `portinfo` VALUES (83, 371, 'TCP', 'ClearCase版本管理软件');
INSERT INTO `portinfo` VALUES (84, 389, 'TCP', 'Lightweight Directory Access Protocol (LDAP)');
INSERT INTO `portinfo` VALUES (85, 396, 'TCP', 'Novell Netware over IP');
INSERT INTO `portinfo` VALUES (86, 420, 'TCP', 'Breach');
INSERT INTO `portinfo` VALUES (87, 421, 'TCP', 'TCP Wrappers');
INSERT INTO `portinfo` VALUES (88, 443, 'TCP', '安全服务（HTTPS）');
INSERT INTO `portinfo` VALUES (89, 444, 'TCP', 'Simple Network Paging Protocol(SNPP)');
INSERT INTO `portinfo` VALUES (90, 445, 'TCP', 'Microsoft-DS');
INSERT INTO `portinfo` VALUES (91, 455, 'TCP', 'Fatal Connections');
INSERT INTO `portinfo` VALUES (92, 456, 'TCP', 'Hackers paradise,FuseSpark');
INSERT INTO `portinfo` VALUES (93, 458, 'TCP', '苹果公司QuickTime');
INSERT INTO `portinfo` VALUES (94, 513, 'TCP', 'Grlogin');
INSERT INTO `portinfo` VALUES (95, 514, 'TCP', 'RPC Backdoor');
INSERT INTO `portinfo` VALUES (96, 531, 'TCP', 'Rasmin,Net666');
INSERT INTO `portinfo` VALUES (97, 544, 'TCP', 'kerberos kshell');
INSERT INTO `portinfo` VALUES (98, 546, 'TCP', 'DHCP Client');
INSERT INTO `portinfo` VALUES (99, 547, 'TCP', 'DHCP Server');
INSERT INTO `portinfo` VALUES (100, 548, 'TCP', 'Macintosh文件服务');
INSERT INTO `portinfo` VALUES (101, 555, 'TCP', 'Ini-Killer,Phase Zero,Stealth Spy');
INSERT INTO `portinfo` VALUES (102, 569, 'TCP', 'MSN');
INSERT INTO `portinfo` VALUES (103, 605, 'TCP', 'SecretService');
INSERT INTO `portinfo` VALUES (104, 606, 'TCP', 'Noknok8');
INSERT INTO `portinfo` VALUES (105, 660, 'TCP', 'DeepThroat');
INSERT INTO `portinfo` VALUES (106, 661, 'TCP', 'Noknok8');
INSERT INTO `portinfo` VALUES (107, 666, 'TCP', 'Attack FTP,Satanz Backdoor,Back Construction,Dark Connection Inside 1.2');
INSERT INTO `portinfo` VALUES (108, 667, 'TCP', 'Noknok7.2');
INSERT INTO `portinfo` VALUES (109, 668, 'TCP', 'Noknok6');
INSERT INTO `portinfo` VALUES (110, 669, 'TCP', 'DP trojan');
INSERT INTO `portinfo` VALUES (111, 692, 'TCP', 'GayOL');
INSERT INTO `portinfo` VALUES (112, 707, 'TCP', 'Welchia,nachi');
INSERT INTO `portinfo` VALUES (113, 777, 'TCP', 'AIM Spy');
INSERT INTO `portinfo` VALUES (114, 808, 'TCP', 'RemoteControl,WinHole');
INSERT INTO `portinfo` VALUES (115, 815, 'TCP', 'Everyone Darling');
INSERT INTO `portinfo` VALUES (116, 901, 'TCP', 'Backdoor.Devil');
INSERT INTO `portinfo` VALUES (117, 911, 'TCP', 'Dark Shadow');
INSERT INTO `portinfo` VALUES (118, 990, 'TCP', 'ssl加密');
INSERT INTO `portinfo` VALUES (119, 993, 'TCP', 'IMAP');
INSERT INTO `portinfo` VALUES (120, 999, 'TCP', 'DeepThroat');
INSERT INTO `portinfo` VALUES (121, 1000, 'TCP', 'Der Spaeher');
INSERT INTO `portinfo` VALUES (122, 1001, 'TCP', 'Silencer,WebEx,Der Spaeher');
INSERT INTO `portinfo` VALUES (123, 1003, 'TCP', 'BackDoor');
INSERT INTO `portinfo` VALUES (124, 1010, 'TCP', 'Doly');
INSERT INTO `portinfo` VALUES (125, 1011, 'TCP', 'Doly');
INSERT INTO `portinfo` VALUES (126, 1012, 'TCP', 'Doly');
INSERT INTO `portinfo` VALUES (127, 1015, 'TCP', 'Doly');
INSERT INTO `portinfo` VALUES (128, 1016, 'TCP', 'Doly');
INSERT INTO `portinfo` VALUES (129, 1020, 'TCP', 'Vampire');
INSERT INTO `portinfo` VALUES (130, 1023, 'TCP', 'Worm.Sasser.e');
INSERT INTO `portinfo` VALUES (131, 1024, 'TCP', 'NetSpy.698(YAI)');
INSERT INTO `portinfo` VALUES (132, 1025, 'TCP', 'NetSpy.698,Unused Windows Services Block');
INSERT INTO `portinfo` VALUES (133, 1026, 'TCP', 'Unused Windows Services Block');
INSERT INTO `portinfo` VALUES (134, 1027, 'TCP', 'Unused Windows Services Block');
INSERT INTO `portinfo` VALUES (135, 1028, 'TCP', 'Unused Windows Services Block');
INSERT INTO `portinfo` VALUES (136, 1029, 'TCP', 'Unused Windows Services Block');
INSERT INTO `portinfo` VALUES (137, 1030, 'TCP', 'Unused Windows Services Block');
INSERT INTO `portinfo` VALUES (138, 1033, 'TCP', 'Netspy');
INSERT INTO `portinfo` VALUES (139, 1035, 'TCP', 'Multidropper');
INSERT INTO `portinfo` VALUES (140, 1042, 'TCP', 'Bla');
INSERT INTO `portinfo` VALUES (141, 1045, 'TCP', 'Rasmin');
INSERT INTO `portinfo` VALUES (142, 1047, 'TCP', 'GateCrasher');
INSERT INTO `portinfo` VALUES (143, 1050, 'TCP', 'MiniCommand');
INSERT INTO `portinfo` VALUES (144, 1059, 'TCP', 'nimreg');
INSERT INTO `portinfo` VALUES (145, 1069, 'TCP', 'Backdoor.TheefServer.202');
INSERT INTO `portinfo` VALUES (146, 1070, 'TCP', 'Voice,Psyber Stream Server,Streaming Audio Trojan');
INSERT INTO `portinfo` VALUES (147, 1080, 'TCP', 'Wingate,Worm.BugBear.B,Worm.Novarg.B');
INSERT INTO `portinfo` VALUES (148, 1090, 'TCP', 'Xtreme,VDOLive');
INSERT INTO `portinfo` VALUES (149, 1092, 'TCP', 'LoveGate');
INSERT INTO `portinfo` VALUES (150, 1095, 'TCP', 'Rat');
INSERT INTO `portinfo` VALUES (151, 1097, 'TCP', 'Rat');
INSERT INTO `portinfo` VALUES (152, 1098, 'TCP', 'Rat');
INSERT INTO `portinfo` VALUES (153, 1099, 'TCP', 'Rat');
INSERT INTO `portinfo` VALUES (154, 1110, 'TCP', 'nfsd-keepalive');
INSERT INTO `portinfo` VALUES (155, 1111, 'TCP', 'Backdoor.AIMVision');
INSERT INTO `portinfo` VALUES (156, 1155, 'TCP', 'Network File Access');
INSERT INTO `portinfo` VALUES (157, 1170, 'TCP', 'Psyber Stream Server,Streaming Audio trojan,Voice');
INSERT INTO `portinfo` VALUES (158, 1200, 'TCP', 'NoBackO');
INSERT INTO `portinfo` VALUES (159, 1201, 'TCP', 'NoBackO');
INSERT INTO `portinfo` VALUES (160, 1207, 'TCP', 'Softwar');
INSERT INTO `portinfo` VALUES (161, 1212, 'TCP', 'Nirvana,Visul Killer');
INSERT INTO `portinfo` VALUES (162, 1234, 'TCP', 'Ultors');
INSERT INTO `portinfo` VALUES (163, 1243, 'TCP', 'BackDoor-G,SubSeven,SubSeven Apocalypse');
INSERT INTO `portinfo` VALUES (164, 1245, 'TCP', 'VooDoo Doll');
INSERT INTO `portinfo` VALUES (165, 1269, 'TCP', 'Mavericks Matrix');
INSERT INTO `portinfo` VALUES (166, 1313, 'TCP', 'Nirvana');
INSERT INTO `portinfo` VALUES (167, 1349, 'TCP', 'BioNet');
INSERT INTO `portinfo` VALUES (168, 1433, 'TCP', 'Microsoft SQL服务');
INSERT INTO `portinfo` VALUES (169, 1441, 'TCP', 'Remote Storm');
INSERT INTO `portinfo` VALUES (170, 1492, 'TCP', 'FTP99CMP(BackOriffice.FTP)');
INSERT INTO `portinfo` VALUES (171, 1503, 'TCP', 'NetMeeting T.120');
INSERT INTO `portinfo` VALUES (172, 1509, 'TCP', 'Psyber Streaming Server');
INSERT INTO `portinfo` VALUES (173, 1600, 'TCP', 'Shivka-Burka');
INSERT INTO `portinfo` VALUES (174, 1688, 'TCP', 'Key Management Service(密钥管理服务)');
INSERT INTO `portinfo` VALUES (175, 1703, 'TCP', 'Exloiter 1.1');
INSERT INTO `portinfo` VALUES (176, 1720, 'TCP', 'NetMeeting H.233 call Setup');
INSERT INTO `portinfo` VALUES (177, 1723, 'TCP', 'VPN 网关（PPTP）');
INSERT INTO `portinfo` VALUES (178, 1731, 'TCP', 'NetMeeting音频调用控制');
INSERT INTO `portinfo` VALUES (179, 1807, 'TCP', 'SpySender');
INSERT INTO `portinfo` VALUES (180, 1966, 'TCP', 'Fake FTP 2000');
INSERT INTO `portinfo` VALUES (181, 1976, 'TCP', 'Custom port');
INSERT INTO `portinfo` VALUES (182, 1981, 'TCP', 'Shockrave');
INSERT INTO `portinfo` VALUES (183, 1990, 'TCP', 'stun-p1 cisco STUN Priority 1 port');
INSERT INTO `portinfo` VALUES (184, 1990, 'TCP', 'stun-p1 cisco STUN Priority 1 port');
INSERT INTO `portinfo` VALUES (185, 1991, 'TCP', 'stun-p2 cisco STUN Priority 2 port');
INSERT INTO `portinfo` VALUES (186, 1992, 'TCP', 'stun-p3 cisco STUN Priority 3 port,ipsendmsg IPsendmsg');
INSERT INTO `portinfo` VALUES (187, 1993, 'TCP', 'snmp-tcp-port cisco SNMP TCP port');
INSERT INTO `portinfo` VALUES (188, 1994, 'TCP', 'stun-port cisco serial tunnel port');
INSERT INTO `portinfo` VALUES (189, 1995, 'TCP', 'perf-port cisco perf port');
INSERT INTO `portinfo` VALUES (190, 1996, 'TCP', 'tr-rsrb-port cisco Remote SRB port');
INSERT INTO `portinfo` VALUES (191, 1997, 'TCP', 'gdp-port cisco Gateway Discovery Protocol');
INSERT INTO `portinfo` VALUES (192, 1998, 'TCP', 'x25-svc-port cisco X.25 service (XOT)');
INSERT INTO `portinfo` VALUES (193, 1999, 'TCP', 'BackDoor,TransScout');
INSERT INTO `portinfo` VALUES (194, 2000, 'TCP', 'Der Spaeher,INsane Network');
INSERT INTO `portinfo` VALUES (195, 2002, 'TCP', 'W32. Beagle .AX @mm');
INSERT INTO `portinfo` VALUES (196, 2001, 'TCP', 'Transmisson scout');
INSERT INTO `portinfo` VALUES (197, 2002, 'TCP', 'Transmisson scout');
INSERT INTO `portinfo` VALUES (198, 2003, 'TCP', 'Transmisson scout');
INSERT INTO `portinfo` VALUES (199, 2004, 'TCP', 'Transmisson scout');
INSERT INTO `portinfo` VALUES (200, 2005, 'TCP', 'TTransmisson scout');
INSERT INTO `portinfo` VALUES (201, 2011, 'TCP', 'cypress');
INSERT INTO `portinfo` VALUES (202, 2015, 'TCP', 'raid-cs');
INSERT INTO `portinfo` VALUES (203, 2023, 'TCP', 'Ripper,Pass Ripper,Hack City Ripper Pro');
INSERT INTO `portinfo` VALUES (204, 2049, 'TCP', 'NFS');
INSERT INTO `portinfo` VALUES (205, 2115, 'TCP', 'Bugs');
INSERT INTO `portinfo` VALUES (206, 2121, 'TCP', 'Nirvana');
INSERT INTO `portinfo` VALUES (207, 2140, 'TCP', 'Deep Throat,The Invasor');
INSERT INTO `portinfo` VALUES (208, 2155, 'TCP', 'Nirvana');
INSERT INTO `portinfo` VALUES (209, 2208, 'TCP', 'RuX');
INSERT INTO `portinfo` VALUES (210, 2255, 'TCP', 'Illusion Mailer');
INSERT INTO `portinfo` VALUES (211, 2283, 'TCP', 'HVL Rat5');
INSERT INTO `portinfo` VALUES (212, 2300, 'TCP', 'PC Explorer');
INSERT INTO `portinfo` VALUES (213, 2311, 'TCP', 'Studio54');
INSERT INTO `portinfo` VALUES (214, 2556, 'TCP', 'Worm.Bbeagle.q');
INSERT INTO `portinfo` VALUES (215, 2565, 'TCP', 'Striker');
INSERT INTO `portinfo` VALUES (216, 2583, 'TCP', 'WinCrash');
INSERT INTO `portinfo` VALUES (217, 2600, 'TCP', 'Digital RootBeer');
INSERT INTO `portinfo` VALUES (218, 2716, 'TCP', 'Prayer Trojan');
INSERT INTO `portinfo` VALUES (219, 2745, 'TCP', 'Worm.BBeagle.k');
INSERT INTO `portinfo` VALUES (220, 2773, 'TCP', 'Backdoor,SubSeven');
INSERT INTO `portinfo` VALUES (221, 2774, 'TCP', 'SubSeven2.1&2.2');
INSERT INTO `portinfo` VALUES (222, 2801, 'TCP', 'Phineas Phucker');
INSERT INTO `portinfo` VALUES (223, 2989, 'TCP', 'Rat');
INSERT INTO `portinfo` VALUES (224, 3024, 'TCP', 'WinCrash trojan');
INSERT INTO `portinfo` VALUES (225, 3127, 'TCP', 'Worm.Novarg');
INSERT INTO `portinfo` VALUES (226, 3128, 'TCP', 'RingZero,Worm.Novarg.B');
INSERT INTO `portinfo` VALUES (227, 3129, 'TCP', 'Masters Paradise');
INSERT INTO `portinfo` VALUES (228, 3150, 'TCP', 'Deep Throat,The Invasor');
INSERT INTO `portinfo` VALUES (229, 3198, 'TCP', 'Worm.Novarg');
INSERT INTO `portinfo` VALUES (230, 3210, 'TCP', 'SchoolBus');
INSERT INTO `portinfo` VALUES (231, 3332, 'TCP', 'Worm.Cycle.a');
INSERT INTO `portinfo` VALUES (232, 3333, 'TCP', 'Prosiak');
INSERT INTO `portinfo` VALUES (233, 3389, 'TCP', '超级终端（远程桌面）');
INSERT INTO `portinfo` VALUES (234, 3456, 'TCP', 'Terror');
INSERT INTO `portinfo` VALUES (235, 3459, 'TCP', 'Eclipse 2000');
INSERT INTO `portinfo` VALUES (236, 3700, 'TCP', 'Portal of Doom');
INSERT INTO `portinfo` VALUES (237, 3791, 'TCP', 'Eclypse');
INSERT INTO `portinfo` VALUES (238, 3801, 'TCP', 'Eclypse');
INSERT INTO `portinfo` VALUES (239, 3996, 'TCP', 'Portal of Doom,RemoteAnything');
INSERT INTO `portinfo` VALUES (240, 4000, 'TCP', '腾讯QQ客户端');
INSERT INTO `portinfo` VALUES (241, 4060, 'TCP', 'Portal of Doom,RemoteAnything');
INSERT INTO `portinfo` VALUES (242, 4092, 'TCP', 'WinCrash');
INSERT INTO `portinfo` VALUES (243, 4242, 'TCP', 'VHM');
INSERT INTO `portinfo` VALUES (244, 4267, 'TCP', 'SubSeven2.1&2.2');
INSERT INTO `portinfo` VALUES (245, 4321, 'TCP', 'BoBo');
INSERT INTO `portinfo` VALUES (246, 4444, 'TCP', 'Prosiak,Swift remote');
INSERT INTO `portinfo` VALUES (247, 4500, 'TCP', 'W32.HLLW.Tufas');
INSERT INTO `portinfo` VALUES (248, 4567, 'TCP', 'File Nail');
INSERT INTO `portinfo` VALUES (249, 4590, 'TCP', 'ICQTrojan');
INSERT INTO `portinfo` VALUES (250, 4899, 'TCP', 'Remote Administrator服务器');
INSERT INTO `portinfo` VALUES (251, 4950, 'TCP', 'ICQTrojan');
INSERT INTO `portinfo` VALUES (252, 5000, 'TCP', 'WindowsXP服务器，Blazer 5,Bubbel,Back Door Setup,Sockets de Troie');
INSERT INTO `portinfo` VALUES (253, 5001, 'TCP', 'Back Door Setup,Sockets de Troie');
INSERT INTO `portinfo` VALUES (254, 5002, 'TCP', 'cd00r,Shaft');
INSERT INTO `portinfo` VALUES (255, 5011, 'TCP', 'One of the Last Trojans (OOTLT)');
INSERT INTO `portinfo` VALUES (256, 5025, 'TCP', 'WM Remote KeyLogger');
INSERT INTO `portinfo` VALUES (257, 5031, 'TCP', 'Firehotcker,Metropolitan,NetMetro');
INSERT INTO `portinfo` VALUES (258, 5032, 'TCP', 'Metropolitan');
INSERT INTO `portinfo` VALUES (259, 5190, 'TCP', 'ICQ Query');
INSERT INTO `portinfo` VALUES (260, 5321, 'TCP', 'Firehotcker');
INSERT INTO `portinfo` VALUES (261, 5333, 'TCP', 'Backage Trojan Box 3');
INSERT INTO `portinfo` VALUES (262, 5343, 'TCP', 'WCrat');
INSERT INTO `portinfo` VALUES (263, 5400, 'TCP', 'Blade Runner,BackConstruction1.2');
INSERT INTO `portinfo` VALUES (264, 5401, 'TCP', 'Blade Runner,Back Construction');
INSERT INTO `portinfo` VALUES (265, 5402, 'TCP', 'Blade Runner,Back Construction');
INSERT INTO `portinfo` VALUES (266, 5471, 'TCP', 'WinCrash');
INSERT INTO `portinfo` VALUES (267, 5512, 'TCP', 'Illusion Mailer');
INSERT INTO `portinfo` VALUES (268, 5521, 'TCP', 'Illusion Mailer');
INSERT INTO `portinfo` VALUES (269, 5550, 'TCP', 'Xtcp,INsane Network');
INSERT INTO `portinfo` VALUES (270, 5554, 'TCP', 'Worm.Sasser');
INSERT INTO `portinfo` VALUES (271, 5555, 'TCP', 'ServeMe');
INSERT INTO `portinfo` VALUES (272, 5556, 'TCP', 'BO Facil');
INSERT INTO `portinfo` VALUES (273, 5557, 'TCP', 'BO Facil');
INSERT INTO `portinfo` VALUES (274, 5569, 'TCP', 'Robo-Hack');
INSERT INTO `portinfo` VALUES (275, 5598, 'TCP', 'BackDoor 2.03');
INSERT INTO `portinfo` VALUES (276, 5631, 'TCP', 'PCAnyWhere data');
INSERT INTO `portinfo` VALUES (277, 5632, 'TCP', 'PCAnyWhere');
INSERT INTO `portinfo` VALUES (278, 5637, 'TCP', 'PC Crasher');
INSERT INTO `portinfo` VALUES (279, 5638, 'TCP', 'PC Crasher');
INSERT INTO `portinfo` VALUES (280, 5698, 'TCP', 'BackDoor');
INSERT INTO `portinfo` VALUES (281, 5714, 'TCP', 'Wincrash3');
INSERT INTO `portinfo` VALUES (282, 5741, 'TCP', 'WinCrash3');
INSERT INTO `portinfo` VALUES (283, 5742, 'TCP', 'WinCrash');
INSERT INTO `portinfo` VALUES (284, 5760, 'TCP', 'Portmap Remote Root Linux Exploit');
INSERT INTO `portinfo` VALUES (285, 5880, 'TCP', 'Y3K RAT');
INSERT INTO `portinfo` VALUES (286, 5881, 'TCP', 'Y3K RAT');
INSERT INTO `portinfo` VALUES (287, 5882, 'TCP', 'Y3K RAT');
INSERT INTO `portinfo` VALUES (288, 5888, 'TCP', 'Y3K RAT');
INSERT INTO `portinfo` VALUES (289, 5889, 'TCP', 'Y3K RAT');
INSERT INTO `portinfo` VALUES (290, 5900, 'TCP', 'WinVnc');
INSERT INTO `portinfo` VALUES (291, 6000, 'TCP', 'Backdoor.AB');
INSERT INTO `portinfo` VALUES (292, 6006, 'TCP', 'Noknok8');
INSERT INTO `portinfo` VALUES (293, 6129, 'TCP', 'Dameware Nt Utilities服务器');
INSERT INTO `portinfo` VALUES (294, 6272, 'TCP', 'SecretService');
INSERT INTO `portinfo` VALUES (295, 6267, 'TCP', '广外女生');
INSERT INTO `portinfo` VALUES (296, 6400, 'TCP', 'Backdoor.AB,The Thing');
INSERT INTO `portinfo` VALUES (297, 6500, 'TCP', 'Devil 1.03');
INSERT INTO `portinfo` VALUES (298, 6661, 'TCP', 'Teman');
INSERT INTO `portinfo` VALUES (299, 6666, 'TCP', 'TCPshell.c');
INSERT INTO `portinfo` VALUES (300, 6667, 'TCP', 'NT Remote Control,Wise 播放器接收端口');
INSERT INTO `portinfo` VALUES (301, 6668, 'TCP', 'Wise Video广播端口');
INSERT INTO `portinfo` VALUES (302, 6669, 'TCP', 'Vampyre');
INSERT INTO `portinfo` VALUES (303, 6670, 'TCP', 'DeepThroat,iPhone');
INSERT INTO `portinfo` VALUES (304, 6671, 'TCP', 'Deep Throat 3.0');
INSERT INTO `portinfo` VALUES (305, 6711, 'TCP', 'SubSeven');
INSERT INTO `portinfo` VALUES (306, 6712, 'TCP', 'SubSeven1.x');
INSERT INTO `portinfo` VALUES (307, 6713, 'TCP', 'SubSeven');
INSERT INTO `portinfo` VALUES (308, 6723, 'TCP', 'Mstream');
INSERT INTO `portinfo` VALUES (309, 6767, 'TCP', 'NT Remote Control');
INSERT INTO `portinfo` VALUES (310, 6771, 'TCP', 'DeepThroat');
INSERT INTO `portinfo` VALUES (311, 6776, 'TCP', 'BackDoor-G,SubSeven,2000 Cracks');
INSERT INTO `portinfo` VALUES (312, 6777, 'TCP', 'Worm.BBeagle');
INSERT INTO `portinfo` VALUES (313, 6789, 'TCP', 'Doly Trojan');
INSERT INTO `portinfo` VALUES (314, 6838, 'TCP', 'Mstream');
INSERT INTO `portinfo` VALUES (315, 6883, 'TCP', 'DeltaSource');
INSERT INTO `portinfo` VALUES (316, 6912, 'TCP', 'Shit Heep');
INSERT INTO `portinfo` VALUES (317, 6939, 'TCP', 'Indoctrination');
INSERT INTO `portinfo` VALUES (318, 6969, 'TCP', 'GateCrasher,Priority,IRC 3');
INSERT INTO `portinfo` VALUES (319, 6970, 'TCP', 'RealAudio,GateCrasher');
INSERT INTO `portinfo` VALUES (320, 7000, 'TCP', 'Remote Grab,NetMonitor,SubSeven1.x');
INSERT INTO `portinfo` VALUES (321, 7001, 'TCP', 'Freak88');
INSERT INTO `portinfo` VALUES (322, 7201, 'TCP', 'NetMonitor');
INSERT INTO `portinfo` VALUES (323, 7215, 'TCP', 'BackDoor-G,SubSeven');
INSERT INTO `portinfo` VALUES (324, 7001, 'TCP', 'Freak88,Freak2k');
INSERT INTO `portinfo` VALUES (325, 7300, 'TCP', 'NetMonitor');
INSERT INTO `portinfo` VALUES (326, 7301, 'TCP', 'NetMonitor');
INSERT INTO `portinfo` VALUES (327, 7306, 'TCP', 'NetMonitor,NetSpy 1.0');
INSERT INTO `portinfo` VALUES (328, 7307, 'TCP', 'NetMonitor,ProcSpy');
INSERT INTO `portinfo` VALUES (329, 7308, 'TCP', 'NetMonitor,X Spy');
INSERT INTO `portinfo` VALUES (330, 7323, 'TCP', 'Sygate服务器端');
INSERT INTO `portinfo` VALUES (331, 7424, 'TCP', 'Host Control');
INSERT INTO `portinfo` VALUES (332, 7511, 'TCP', '聪明基因');
INSERT INTO `portinfo` VALUES (333, 7597, 'TCP', 'Qaz');
INSERT INTO `portinfo` VALUES (334, 7609, 'TCP', 'Snid X2');
INSERT INTO `portinfo` VALUES (335, 7626, 'TCP', '冰河');
INSERT INTO `portinfo` VALUES (336, 7777, 'TCP', 'The Thing');
INSERT INTO `portinfo` VALUES (337, 7789, 'TCP', 'Back Door Setup,ICQKiller');
INSERT INTO `portinfo` VALUES (338, 7983, 'TCP', 'Mstream');
INSERT INTO `portinfo` VALUES (339, 8000, 'TCP', '腾讯OICQ服务器端，XDMA');
INSERT INTO `portinfo` VALUES (340, 8010, 'TCP', 'Wingate,Logfile');
INSERT INTO `portinfo` VALUES (341, 8011, 'TCP', 'WAY2.4');
INSERT INTO `portinfo` VALUES (342, 8080, 'TCP', 'WWW 代理，Ring Zero,Chubo,Worm.Novarg.B');
INSERT INTO `portinfo` VALUES (343, 8102, 'TCP', '网络神偷');
INSERT INTO `portinfo` VALUES (344, 8181, 'TCP', 'W32.Erkez.D@mm');
INSERT INTO `portinfo` VALUES (345, 8520, 'TCP', 'W32.Socay.Worm');
INSERT INTO `portinfo` VALUES (346, 8594, 'TCP', 'I-Worm/Bozori.a');
INSERT INTO `portinfo` VALUES (347, 8787, 'TCP', 'BackOfrice 2000');
INSERT INTO `portinfo` VALUES (348, 8888, 'TCP', 'Winvnc');
INSERT INTO `portinfo` VALUES (349, 8897, 'TCP', 'Hack Office,Armageddon');
INSERT INTO `portinfo` VALUES (350, 8989, 'TCP', 'Recon');
INSERT INTO `portinfo` VALUES (351, 9000, 'TCP', 'Netministrator');
INSERT INTO `portinfo` VALUES (352, 9325, 'TCP', 'Mstream');
INSERT INTO `portinfo` VALUES (353, 9400, 'TCP', 'InCommand 1.0');
INSERT INTO `portinfo` VALUES (354, 9401, 'TCP', 'InCommand 1.0');
INSERT INTO `portinfo` VALUES (355, 9402, 'TCP', 'InCommand 1.0');
INSERT INTO `portinfo` VALUES (356, 9872, 'TCP', 'Portal of Doom');
INSERT INTO `portinfo` VALUES (357, 9873, 'TCP', 'Portal of Doom');
INSERT INTO `portinfo` VALUES (358, 9874, 'TCP', 'Portal of Doom');
INSERT INTO `portinfo` VALUES (359, 9875, 'TCP', 'Portal of Doom');
INSERT INTO `portinfo` VALUES (360, 9876, 'TCP', 'Cyber Attacker');
INSERT INTO `portinfo` VALUES (361, 9878, 'TCP', 'TransScout');
INSERT INTO `portinfo` VALUES (362, 9989, 'TCP', 'Ini-Killer');
INSERT INTO `portinfo` VALUES (363, 9898, 'TCP', 'Worm.Win32.Dabber.a');
INSERT INTO `portinfo` VALUES (364, 9999, 'TCP', 'Prayer Trojan');
INSERT INTO `portinfo` VALUES (365, 10067, 'TCP', 'Portal of Doom');
INSERT INTO `portinfo` VALUES (366, 10080, 'TCP', 'Worm.Novarg.B');
INSERT INTO `portinfo` VALUES (367, 10084, 'TCP', 'Syphillis');
INSERT INTO `portinfo` VALUES (368, 10085, 'TCP', 'Syphillis');
INSERT INTO `portinfo` VALUES (369, 10086, 'TCP', 'Syphillis');
INSERT INTO `portinfo` VALUES (370, 10101, 'TCP', 'BrainSpy');
INSERT INTO `portinfo` VALUES (371, 10167, 'TCP', 'Portal Of Doom');
INSERT INTO `portinfo` VALUES (372, 10168, 'TCP', 'Worm.Supnot.78858.c,Worm.LovGate.T');
INSERT INTO `portinfo` VALUES (373, 10520, 'TCP', 'Acid Shivers');
INSERT INTO `portinfo` VALUES (374, 10607, 'TCP', 'Coma trojan');
INSERT INTO `portinfo` VALUES (375, 10666, 'TCP', 'Ambush');
INSERT INTO `portinfo` VALUES (376, 11000, 'TCP', 'Senna Spy');
INSERT INTO `portinfo` VALUES (377, 11050, 'TCP', 'Host Control');
INSERT INTO `portinfo` VALUES (378, 11051, 'TCP', 'Host Control');
INSERT INTO `portinfo` VALUES (379, 11223, 'TCP', 'Progenic,Hack ’99KeyLogger');
INSERT INTO `portinfo` VALUES (380, 11831, 'TCP', 'TROJ_LATINUS.SVR');
INSERT INTO `portinfo` VALUES (381, 12076, 'TCP', 'Gjamer,MSH.104b');
INSERT INTO `portinfo` VALUES (382, 12223, 'TCP', 'Hack’99 KeyLogger');
INSERT INTO `portinfo` VALUES (383, 12345, 'TCP', 'GabanBus,NetBus 1.6/1.7,Pie Bill Gates,X-bill');
INSERT INTO `portinfo` VALUES (384, 12346, 'TCP', 'GabanBus,NetBus 1.6/1.7,X-bill');
INSERT INTO `portinfo` VALUES (385, 12349, 'TCP', 'BioNet');
INSERT INTO `portinfo` VALUES (386, 12361, 'TCP', 'Whack-a-mole');
INSERT INTO `portinfo` VALUES (387, 12362, 'TCP', 'Whack-a-mole');
INSERT INTO `portinfo` VALUES (388, 12363, 'TCP', 'Whack-a-mole');
INSERT INTO `portinfo` VALUES (389, 12378, 'TCP', 'W32/Gibe@MM');
INSERT INTO `portinfo` VALUES (390, 12456, 'TCP', 'NetBus');
INSERT INTO `portinfo` VALUES (391, 12623, 'TCP', 'DUN Control');
INSERT INTO `portinfo` VALUES (392, 12624, 'TCP', 'Buttman');
INSERT INTO `portinfo` VALUES (393, 12631, 'TCP', 'WhackJob,WhackJob.NB1.7');
INSERT INTO `portinfo` VALUES (394, 12701, 'TCP', 'Eclipse2000');
INSERT INTO `portinfo` VALUES (395, 12754, 'TCP', 'Mstream');
INSERT INTO `portinfo` VALUES (396, 13000, 'TCP', 'Senna Spy');
INSERT INTO `portinfo` VALUES (397, 13010, 'TCP', 'Hacker Brazil');
INSERT INTO `portinfo` VALUES (398, 13013, 'TCP', 'Psychward');
INSERT INTO `portinfo` VALUES (399, 13223, 'TCP', 'Tribal Voice的聊天程序PowWow');
INSERT INTO `portinfo` VALUES (400, 13700, 'TCP', 'Kuang2 The Virus');
INSERT INTO `portinfo` VALUES (401, 14456, 'TCP', 'Solero');
INSERT INTO `portinfo` VALUES (402, 14500, 'TCP', 'PC Invader');
INSERT INTO `portinfo` VALUES (403, 14501, 'TCP', 'PC Invader');
INSERT INTO `portinfo` VALUES (404, 14502, 'TCP', 'PC Invader');
INSERT INTO `portinfo` VALUES (405, 14503, 'TCP', 'PC Invader');
INSERT INTO `portinfo` VALUES (406, 15000, 'TCP', 'NetDaemon 1.0');
INSERT INTO `portinfo` VALUES (407, 15092, 'TCP', 'Host Control');
INSERT INTO `portinfo` VALUES (408, 15104, 'TCP', 'Mstream');
INSERT INTO `portinfo` VALUES (409, 16484, 'TCP', 'Mosucker');
INSERT INTO `portinfo` VALUES (410, 16660, 'TCP', 'Stacheldraht (DDoS)');
INSERT INTO `portinfo` VALUES (411, 16772, 'TCP', 'ICQ Revenge');
INSERT INTO `portinfo` VALUES (412, 16959, 'TCP', 'Priority');
INSERT INTO `portinfo` VALUES (413, 16969, 'TCP', 'Priority');
INSERT INTO `portinfo` VALUES (414, 17027, 'TCP', '提供广告服务的Conducent”adbot”共享软件');
INSERT INTO `portinfo` VALUES (415, 17166, 'TCP', 'Mosaic');
INSERT INTO `portinfo` VALUES (416, 17300, 'TCP', 'Kuang2 The Virus');
INSERT INTO `portinfo` VALUES (417, 17490, 'TCP', 'CrazyNet');
INSERT INTO `portinfo` VALUES (418, 17500, 'TCP', 'CrazyNet');
INSERT INTO `portinfo` VALUES (419, 17569, 'TCP', 'Infector 1.4.x + 1.6.x');
INSERT INTO `portinfo` VALUES (420, 17777, 'TCP', 'Nephron');
INSERT INTO `portinfo` VALUES (421, 18753, 'TCP', 'Shaft (DDoS)');
INSERT INTO `portinfo` VALUES (422, 19191, 'TCP', '蓝色火焰');
INSERT INTO `portinfo` VALUES (423, 19864, 'TCP', 'ICQ Revenge');
INSERT INTO `portinfo` VALUES (424, 20000, 'TCP', 'Millennium II (GrilFriend)');
INSERT INTO `portinfo` VALUES (425, 20001, 'TCP', 'Millennium II (GrilFriend)');
INSERT INTO `portinfo` VALUES (426, 20002, 'TCP', 'AcidkoR');
INSERT INTO `portinfo` VALUES (427, 20034, 'TCP', 'NetBus 2 Pro');
INSERT INTO `portinfo` VALUES (428, 20168, 'TCP', 'Lovgate');
INSERT INTO `portinfo` VALUES (429, 20203, 'TCP', 'Logged,Chupacabra');
INSERT INTO `portinfo` VALUES (430, 20331, 'TCP', 'Bla');
INSERT INTO `portinfo` VALUES (431, 20432, 'TCP', 'Shaft (DDoS)');
INSERT INTO `portinfo` VALUES (432, 20808, 'TCP', 'Worm.LovGate.v.QQ');
INSERT INTO `portinfo` VALUES (433, 21335, 'TCP', 'Tribal Flood Network,Trinoo');
INSERT INTO `portinfo` VALUES (434, 21544, 'TCP', 'Schwindler 1.82,GirlFriend');
INSERT INTO `portinfo` VALUES (435, 21554, 'TCP', 'Schwindler 1.82,GirlFriend,Exloiter 1.0.1.2');
INSERT INTO `portinfo` VALUES (436, 22222, 'TCP', 'Prosiak,RuXUploader2.0');
INSERT INTO `portinfo` VALUES (437, 22784, 'TCP', 'Backdoor.Intruzzo');
INSERT INTO `portinfo` VALUES (438, 23432, 'TCP', 'Asylum 0.1.3');
INSERT INTO `portinfo` VALUES (439, 23444, 'TCP', '网络公牛');
INSERT INTO `portinfo` VALUES (440, 23456, 'TCP', 'Evil FTP,Ugly FTP,WhackJob');
INSERT INTO `portinfo` VALUES (441, 23476, 'TCP', 'Donald Dick');
INSERT INTO `portinfo` VALUES (442, 23477, 'TCP', 'Donald Dick');
INSERT INTO `portinfo` VALUES (443, 23777, 'TCP', 'INet Spy');
INSERT INTO `portinfo` VALUES (444, 26274, 'TCP', 'Delta');
INSERT INTO `portinfo` VALUES (445, 26681, 'TCP', 'Spy Voice');
INSERT INTO `portinfo` VALUES (446, 27374, 'TCP', 'Sub Seven 2.0+,Backdoor.Baste');
INSERT INTO `portinfo` VALUES (447, 27444, 'TCP', 'Tribal Flood Network,Trinoo');
INSERT INTO `portinfo` VALUES (448, 27665, 'TCP', 'Tribal Flood Network,Trinoo');
INSERT INTO `portinfo` VALUES (449, 29431, 'TCP', 'Hack Attack');
INSERT INTO `portinfo` VALUES (450, 29432, 'TCP', 'Hack Attack');
INSERT INTO `portinfo` VALUES (451, 29104, 'TCP', 'Host Control');
INSERT INTO `portinfo` VALUES (452, 29559, 'TCP', 'TROJ_LATINUS.SVR');
INSERT INTO `portinfo` VALUES (453, 29891, 'TCP', 'The Unexplained');
INSERT INTO `portinfo` VALUES (454, 30001, 'TCP', 'Terr0r32');
INSERT INTO `portinfo` VALUES (455, 30003, 'TCP', 'Death,Lamers Death');
INSERT INTO `portinfo` VALUES (456, 30029, 'TCP', 'AOL trojan');
INSERT INTO `portinfo` VALUES (457, 30100, 'TCP', 'NetSphere 1.27a,NetSphere 1.31');
INSERT INTO `portinfo` VALUES (458, 30101, 'TCP', 'NetSphere 1.31,NetSphere 1.27a');
INSERT INTO `portinfo` VALUES (459, 30102, 'TCP', 'NetSphere 1.27a,NetSphere 1.31');
INSERT INTO `portinfo` VALUES (460, 30103, 'TCP', 'NetSphere 1.31');
INSERT INTO `portinfo` VALUES (461, 30303, 'TCP', 'Sockets de Troie');
INSERT INTO `portinfo` VALUES (462, 30722, 'TCP', 'W32.Esbot.A');
INSERT INTO `portinfo` VALUES (463, 30947, 'TCP', 'Intruse');
INSERT INTO `portinfo` VALUES (464, 30999, 'TCP', 'Kuang2');
INSERT INTO `portinfo` VALUES (465, 31336, 'TCP', 'Bo Whack');
INSERT INTO `portinfo` VALUES (466, 31337, 'TCP', 'Baron Night,BO client,BO2,Bo Facil,BackFire,Back Orifice,DeepBO,Freak2k,NetSpy');
INSERT INTO `portinfo` VALUES (467, 31338, 'TCP', 'NetSpy,Back Orifice,DeepBO');
INSERT INTO `portinfo` VALUES (468, 31339, 'TCP', 'NetSpy DK');
INSERT INTO `portinfo` VALUES (469, 31554, 'TCP', 'Schwindler');
INSERT INTO `portinfo` VALUES (470, 31666, 'TCP', 'BOWhack');
INSERT INTO `portinfo` VALUES (471, 31778, 'TCP', 'Hack Attack');
INSERT INTO `portinfo` VALUES (472, 31785, 'TCP', 'Hack Attack');
INSERT INTO `portinfo` VALUES (473, 31787, 'TCP', 'Hack Attack');
INSERT INTO `portinfo` VALUES (474, 31789, 'TCP', 'Hack Attack');
INSERT INTO `portinfo` VALUES (475, 31791, 'TCP', 'Hack Attack');
INSERT INTO `portinfo` VALUES (476, 31792, 'TCP', 'Hack Attack');
INSERT INTO `portinfo` VALUES (477, 32100, 'TCP', 'PeanutBrittle');
INSERT INTO `portinfo` VALUES (478, 32418, 'TCP', 'Acid Battery');
INSERT INTO `portinfo` VALUES (479, 33333, 'TCP', 'Prosiak,Blakharaz 1.0');
INSERT INTO `portinfo` VALUES (480, 33577, 'TCP', 'Son Of Psychward');
INSERT INTO `portinfo` VALUES (481, 33777, 'TCP', 'Son Of Psychward');
INSERT INTO `portinfo` VALUES (482, 33911, 'TCP', 'Spirit 2001a');
INSERT INTO `portinfo` VALUES (483, 34324, 'TCP', 'BigGluck,TN,Tiny Telnet Server');
INSERT INTO `portinfo` VALUES (484, 34555, 'TCP', 'Trin00 (Windows) (DDoS)');
INSERT INTO `portinfo` VALUES (485, 35555, 'TCP', 'Trin00 (Windows) (DDoS)');
INSERT INTO `portinfo` VALUES (486, 36794, 'TCP', 'Worm.Bugbear-A');
INSERT INTO `portinfo` VALUES (487, 37651, 'TCP', 'YAT');
INSERT INTO `portinfo` VALUES (488, 40412, 'TCP', 'The Spy');
INSERT INTO `portinfo` VALUES (489, 40421, 'TCP', 'Agent 40421,Masters Paradise.96');
INSERT INTO `portinfo` VALUES (490, 40422, 'TCP', 'Masters Paradise');
INSERT INTO `portinfo` VALUES (491, 40423, 'TCP', 'Masters Paradise.97');
INSERT INTO `portinfo` VALUES (492, 40425, 'TCP', 'Masters Paradise');
INSERT INTO `portinfo` VALUES (493, 40426, 'TCP', 'Masters Paradise 3.x');
INSERT INTO `portinfo` VALUES (494, 41666, 'TCP', 'Remote Boot');
INSERT INTO `portinfo` VALUES (495, 43210, 'TCP', 'Schoolbus 1.6/2.0');
INSERT INTO `portinfo` VALUES (496, 44444, 'TCP', 'Delta Source');
INSERT INTO `portinfo` VALUES (497, 44445, 'TCP', 'Happypig');
INSERT INTO `portinfo` VALUES (498, 45576, 'TCP', '未知代理');
INSERT INTO `portinfo` VALUES (499, 47252, 'TCP', 'Prosiak');
INSERT INTO `portinfo` VALUES (500, 47262, 'TCP', 'Delta');
INSERT INTO `portinfo` VALUES (501, 47878, 'TCP', 'BirdSpy2');
INSERT INTO `portinfo` VALUES (502, 49301, 'TCP', 'Online Keylogger');
INSERT INTO `portinfo` VALUES (503, 50505, 'TCP', 'Sockets de Troie');
INSERT INTO `portinfo` VALUES (504, 50766, 'TCP', 'Fore,Schwindler');
INSERT INTO `portinfo` VALUES (505, 51966, 'TCP', 'CafeIni');
INSERT INTO `portinfo` VALUES (506, 53001, 'TCP', 'Remote Windows Shutdown');
INSERT INTO `portinfo` VALUES (507, 53217, 'TCP', 'Acid Battery 2000');
INSERT INTO `portinfo` VALUES (508, 54283, 'TCP', 'Back Door-G,Sub7');
INSERT INTO `portinfo` VALUES (509, 54320, 'TCP', 'Back Orifice 2000,Sheep');
INSERT INTO `portinfo` VALUES (510, 54321, 'TCP', 'School Bus .69-1.11,Sheep,BO2K');
INSERT INTO `portinfo` VALUES (511, 57341, 'TCP', 'NetRaider');
INSERT INTO `portinfo` VALUES (512, 58008, 'TCP', 'BackDoor.Tron');
INSERT INTO `portinfo` VALUES (513, 58009, 'TCP', 'BackDoor.Tron');
INSERT INTO `portinfo` VALUES (514, 58339, 'TCP', 'ButtFunnel');
INSERT INTO `portinfo` VALUES (515, 59211, 'TCP', 'BackDoor.DuckToy');
INSERT INTO `portinfo` VALUES (516, 60000, 'TCP', 'Deep Throat');
INSERT INTO `portinfo` VALUES (517, 60068, 'TCP', 'Xzip 6000068');
INSERT INTO `portinfo` VALUES (518, 60268, 'TCP', 'DaYangou_bigppig');
INSERT INTO `portinfo` VALUES (519, 60411, 'TCP', 'Connection');
INSERT INTO `portinfo` VALUES (520, 60606, 'TCP', 'TROJ_BCKDOR.G2.A');
INSERT INTO `portinfo` VALUES (521, 61466, 'TCP', 'Telecommando');
INSERT INTO `portinfo` VALUES (522, 61603, 'TCP', 'Bunker-kill');
INSERT INTO `portinfo` VALUES (523, 63485, 'TCP', 'Bunker-kill');
INSERT INTO `portinfo` VALUES (524, 65000, 'TCP', 'Devil,DDoS');
INSERT INTO `portinfo` VALUES (525, 65432, 'TCP', 'Th3tr41t0r,The Traitor');
INSERT INTO `portinfo` VALUES (526, 65530, 'TCP', 'TROJ_WINMITE.10');
INSERT INTO `portinfo` VALUES (527, 65535, 'TCP', 'RC,Adore Worm/Linux');
INSERT INTO `portinfo` VALUES (528, 1, 'UDP', 'Sockets des Troie');
INSERT INTO `portinfo` VALUES (529, 9, 'UDP', 'Chargen');
INSERT INTO `portinfo` VALUES (530, 19, 'UDP', 'Chargen');
INSERT INTO `portinfo` VALUES (531, 69, 'UDP', 'Pasana');
INSERT INTO `portinfo` VALUES (532, 80, 'UDP', 'Penrox');
INSERT INTO `portinfo` VALUES (533, 371, 'UDP', 'ClearCase版本管理软件');
INSERT INTO `portinfo` VALUES (534, 445, 'UDP', '公共Internet文件系统（CIFS)');
INSERT INTO `portinfo` VALUES (535, 500, 'UDP', 'Internet密钥交换（IP安全性 ,IKE)');
INSERT INTO `portinfo` VALUES (536, 520, 'UDP', 'Rip');
INSERT INTO `portinfo` VALUES (537, 1025, 'UDP', 'Maverick’s Matrix 1.2 - 2.0');
INSERT INTO `portinfo` VALUES (538, 1026, 'UDP', 'Remote Explorer 2000');
INSERT INTO `portinfo` VALUES (539, 1027, 'UDP', 'UC聊天软件，Trojan.Huigezi.e');
INSERT INTO `portinfo` VALUES (540, 1028, 'UDP', '3721上网助手（用途不明，建议用户警惕！），KiLo,SubSARI');
INSERT INTO `portinfo` VALUES (541, 1029, 'UDP', 'SubSARI');
INSERT INTO `portinfo` VALUES (542, 1031, 'UDP', 'Xot');
INSERT INTO `portinfo` VALUES (543, 1032, 'UDP', 'Akosch4');
INSERT INTO `portinfo` VALUES (544, 1104, 'UDP', 'RexxRave');
INSERT INTO `portinfo` VALUES (545, 1111, 'UDP', 'Daodan');
INSERT INTO `portinfo` VALUES (546, 1116, 'UDP', 'Lurker');
INSERT INTO `portinfo` VALUES (547, 1122, 'UDP', 'Last 2000,Singularity');
INSERT INTO `portinfo` VALUES (548, 1183, 'UDP', 'Cyn,SweetHeart');
INSERT INTO `portinfo` VALUES (549, 1200, 'UDP', 'NoBackO');
INSERT INTO `portinfo` VALUES (550, 1201, 'UDP', 'NoBackO');
INSERT INTO `portinfo` VALUES (551, 1342, 'UDP', 'BLA trojan');
INSERT INTO `portinfo` VALUES (552, 1344, 'UDP', 'Ptakks');
INSERT INTO `portinfo` VALUES (553, 1349, 'UDP', 'BO dll');
INSERT INTO `portinfo` VALUES (554, 1561, 'UDP', 'MuSka52');
INSERT INTO `portinfo` VALUES (555, 1701, 'UDP', 'VPN网关（L2TP）');
INSERT INTO `portinfo` VALUES (556, 1772, 'UDP', 'NetControle');
INSERT INTO `portinfo` VALUES (557, 1978, 'UDP', 'Slapper');
INSERT INTO `portinfo` VALUES (558, 1985, 'UDP', 'Black Diver');
INSERT INTO `portinfo` VALUES (559, 2000, 'UDP', 'A-trojan,Fear,Force,GOTHIC Intruder,Last 2000,Real 2000');
INSERT INTO `portinfo` VALUES (560, 2001, 'UDP', 'Scalper');
INSERT INTO `portinfo` VALUES (561, 2002, 'UDP', 'Slapper');
INSERT INTO `portinfo` VALUES (562, 2015, 'UDP', 'raid-cs');
INSERT INTO `portinfo` VALUES (563, 2018, 'UDP', 'rellpack');
INSERT INTO `portinfo` VALUES (564, 2130, 'UDP', 'Mini BackLash');
INSERT INTO `portinfo` VALUES (565, 2140, 'UDP', 'Deep Throat,Foreplay,The Invasor');
INSERT INTO `portinfo` VALUES (566, 2222, 'UDP', 'SweetHeart,Way');
INSERT INTO `portinfo` VALUES (567, 2339, 'UDP', 'Voice Spy');
INSERT INTO `portinfo` VALUES (568, 2702, 'UDP', 'Black Diver');
INSERT INTO `portinfo` VALUES (569, 2989, 'UDP', 'RAT');
INSERT INTO `portinfo` VALUES (570, 3150, 'UDP', 'Deep Throat');
INSERT INTO `portinfo` VALUES (571, 3215, 'UDP', 'XHX');
INSERT INTO `portinfo` VALUES (572, 3333, 'UDP', 'Daodan');
INSERT INTO `portinfo` VALUES (573, 3801, 'UDP', 'Eclypse');
INSERT INTO `portinfo` VALUES (574, 3996, 'UDP', 'Remote Anything');
INSERT INTO `portinfo` VALUES (575, 4128, 'UDP', 'RedShad');
INSERT INTO `portinfo` VALUES (576, 4156, 'UDP', 'Slapper');
INSERT INTO `portinfo` VALUES (577, 4500, 'UDP', 'sae-urn/ (IP安全性，IKE NAT遍历）');
INSERT INTO `portinfo` VALUES (578, 5419, 'UDP', 'DarkSky');
INSERT INTO `portinfo` VALUES (579, 5503, 'UDP', 'Remote Shell Trojan');
INSERT INTO `portinfo` VALUES (580, 5555, 'UDP', 'Daodan');
INSERT INTO `portinfo` VALUES (581, 5882, 'UDP', 'Y3K RAT');
INSERT INTO `portinfo` VALUES (582, 5888, 'UDP', 'Y3K RAT');
INSERT INTO `portinfo` VALUES (583, 6112, 'UDP', 'Battle .net Game');
INSERT INTO `portinfo` VALUES (584, 6666, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (585, 6667, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (586, 6766, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (587, 6767, 'UDP', 'KiLo,UandMe');
INSERT INTO `portinfo` VALUES (588, 6838, 'UDP', 'Mstream Agent-handler');
INSERT INTO `portinfo` VALUES (589, 7028, 'UDP', '未知木马');
INSERT INTO `portinfo` VALUES (590, 7424, 'UDP', 'Host Control');
INSERT INTO `portinfo` VALUES (591, 7788, 'UDP', 'Singularity');
INSERT INTO `portinfo` VALUES (592, 7983, 'UDP', 'MStream handler-agent');
INSERT INTO `portinfo` VALUES (593, 8012, 'UDP', 'Ptakks');
INSERT INTO `portinfo` VALUES (594, 8090, 'UDP', 'Aphex’s Remote Packet Sniffer');
INSERT INTO `portinfo` VALUES (595, 8127, 'UDP', '9_119,Chonker');
INSERT INTO `portinfo` VALUES (596, 8488, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (597, 8489, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (598, 8787, 'UDP', 'BackOrifice 2000');
INSERT INTO `portinfo` VALUES (599, 8879, 'UDP', 'BackOrifice 2000');
INSERT INTO `portinfo` VALUES (600, 9325, 'UDP', 'MStream Agent-handler');
INSERT INTO `portinfo` VALUES (601, 10000, 'UDP', 'XHX');
INSERT INTO `portinfo` VALUES (602, 10067, 'UDP', 'Portal of Doom');
INSERT INTO `portinfo` VALUES (603, 10084, 'UDP', 'Syphillis');
INSERT INTO `portinfo` VALUES (604, 10100, 'UDP', 'Slapper');
INSERT INTO `portinfo` VALUES (605, 10167, 'UDP', 'Portal of Doom');
INSERT INTO `portinfo` VALUES (606, 10498, 'UDP', 'Mstream');
INSERT INTO `portinfo` VALUES (607, 10666, 'UDP', 'Ambush');
INSERT INTO `portinfo` VALUES (608, 11225, 'UDP', 'Cyn');
INSERT INTO `portinfo` VALUES (609, 12321, 'UDP', 'Protoss');
INSERT INTO `portinfo` VALUES (610, 12345, 'UDP', 'BlueIce 2000');
INSERT INTO `portinfo` VALUES (611, 12378, 'UDP', 'W32/Gibe@MM');
INSERT INTO `portinfo` VALUES (612, 12623, 'UDP', 'ButtMan,DUN Control');
INSERT INTO `portinfo` VALUES (613, 15210, 'UDP', 'UDP remote shell backdoor server');
INSERT INTO `portinfo` VALUES (614, 15486, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (615, 16514, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (616, 16515, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (617, 18753, 'UDP', 'Shaft handler to Agent');
INSERT INTO `portinfo` VALUES (618, 20433, 'UDP', 'Shaft');
INSERT INTO `portinfo` VALUES (619, 21554, 'UDP', 'GirlFriend');
INSERT INTO `portinfo` VALUES (620, 22784, 'UDP', 'Backdoor.Intruzzo');
INSERT INTO `portinfo` VALUES (621, 23476, 'UDP', 'Donald Dick');
INSERT INTO `portinfo` VALUES (622, 25123, 'UDP', 'MOTD');
INSERT INTO `portinfo` VALUES (623, 26274, 'UDP', 'Delta Source');
INSERT INTO `portinfo` VALUES (624, 26374, 'UDP', 'Sub-7 2.1');
INSERT INTO `portinfo` VALUES (625, 26444, 'UDP', 'Trin00/TFN2K');
INSERT INTO `portinfo` VALUES (626, 26573, 'UDP', 'Sub-7 2.1');
INSERT INTO `portinfo` VALUES (627, 27184, 'UDP', 'Alvgus trojan 2000');
INSERT INTO `portinfo` VALUES (628, 27444, 'UDP', 'Trinoo');
INSERT INTO `portinfo` VALUES (629, 29589, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (630, 29891, 'UDP', 'The Unexplained');
INSERT INTO `portinfo` VALUES (631, 30103, 'UDP', 'NetSphere');
INSERT INTO `portinfo` VALUES (632, 31320, 'UDP', 'Little Witch');
INSERT INTO `portinfo` VALUES (633, 31335, 'UDP', 'Trin00 DoS Attack');
INSERT INTO `portinfo` VALUES (634, 31337, 'UDP', 'Baron Night,BO client,BO2,Bo Facil,BackFire,Back Orifice,DeepBO');
INSERT INTO `portinfo` VALUES (635, 31338, 'UDP', 'Back Orifice,NetSpy DK,DeepBO');
INSERT INTO `portinfo` VALUES (636, 31339, 'UDP', 'Little Witch');
INSERT INTO `portinfo` VALUES (637, 31340, 'UDP', 'Little Witch');
INSERT INTO `portinfo` VALUES (638, 31416, 'UDP', 'Lithium');
INSERT INTO `portinfo` VALUES (639, 31787, 'UDP', 'Hack aTack');
INSERT INTO `portinfo` VALUES (640, 31789, 'UDP', 'Hack aTack');
INSERT INTO `portinfo` VALUES (641, 31790, 'UDP', 'Hack aTack');
INSERT INTO `portinfo` VALUES (642, 31791, 'UDP', 'Hack aTack');
INSERT INTO `portinfo` VALUES (643, 33390, 'UDP', '未知木马');
INSERT INTO `portinfo` VALUES (644, 34555, 'UDP', 'Trinoo');
INSERT INTO `portinfo` VALUES (645, 35555, 'UDP', 'Trinoo');
INSERT INTO `portinfo` VALUES (646, 43720, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (647, 44014, 'UDP', 'Iani');
INSERT INTO `portinfo` VALUES (648, 44767, 'UDP', 'School Bus');
INSERT INTO `portinfo` VALUES (649, 46666, 'UDP', 'Taskman');
INSERT INTO `portinfo` VALUES (650, 47262, 'UDP', 'Delta Source');
INSERT INTO `portinfo` VALUES (651, 47785, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (652, 49301, 'UDP', 'OnLine keyLogger');
INSERT INTO `portinfo` VALUES (653, 49683, 'UDP', 'Fenster');
INSERT INTO `portinfo` VALUES (654, 49698, 'UDP', 'KiLo');
INSERT INTO `portinfo` VALUES (655, 52901, 'UDP', 'Omega');
INSERT INTO `portinfo` VALUES (656, 54320, 'UDP', 'Back Orifice');
INSERT INTO `portinfo` VALUES (657, 54321, 'UDP', 'Back Orifice 2000');
INSERT INTO `portinfo` VALUES (658, 54341, 'UDP', 'NetRaider Trojan');
INSERT INTO `portinfo` VALUES (659, 61746, 'UDP', 'KiLO');
INSERT INTO `portinfo` VALUES (660, 61747, 'UDP', 'KiLO');
INSERT INTO `portinfo` VALUES (661, 61748, 'UDP', 'KiLO');
INSERT INTO `portinfo` VALUES (662, 65432, 'UDP', 'The Traitor');

-- ----------------------------
-- Table structure for task
-- ----------------------------
DROP TABLE IF EXISTS `task`;
CREATE TABLE `task`  (
  `taskID` int(10) NOT NULL AUTO_INCREMENT,
  `taskName` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `taskState` int(6) UNSIGNED NOT NULL,
  `taskType` int(6) UNSIGNED NOT NULL,
  `beginIP` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `endIP` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `beginPort` int(10) UNSIGNED NULL DEFAULT NULL,
  `endPort` int(10) UNSIGNED NULL DEFAULT NULL,
  `destHostIP` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `userID` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`taskID`) USING BTREE,
  INDEX `userID`(`userID`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 474 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of task
-- ----------------------------
INSERT INTO `task` VALUES (462, '常用端口扫描', 2, 1, '', '', 0, 8000, '192.168.43.1', 18);
INSERT INTO `task` VALUES (461, '主机扫描', 0, 0, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (460, '主机扫描', 1, 0, '1.1.1.97', '192.168.255.255', 0, 0, '', 18);
INSERT INTO `task` VALUES (459, '主机扫描', 2, 0, '192.168.43.1', '192.168.43.255', 0, 0, '', 18);
INSERT INTO `task` VALUES (458, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (456, '主机扫描', 0, 0, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (457, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (454, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (453, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (452, '主机扫描', 2, 0, '192.168.43.1', '192.168.43.255', 0, 0, '', 18);
INSERT INTO `task` VALUES (451, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (450, '主机扫描', 2, 0, '192.168.43.1', '192.168.43.255', 0, 0, '', 18);
INSERT INTO `task` VALUES (449, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (448, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (447, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (463, '选定端口扫描', 2, 2, '', '', 1, 200, '192.168.43.97', 18);
INSERT INTO `task` VALUES (446, '常用端口扫描', 2, 1, '', '', 0, 8000, '192.168.43.1', 54);
INSERT INTO `task` VALUES (445, '弱口令扫描', 2, 3, '', '', 0, 0, '', 54);
INSERT INTO `task` VALUES (444, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (443, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (441, '弱口令扫描', 0, 3, '', '', 0, 0, '', 0);
INSERT INTO `task` VALUES (440, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (469, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (470, '弱口令扫描', 2, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (471, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (473, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (439, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (438, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (437, '主机扫描', 2, 0, '192.168.43.1', '192.168.43.255', 0, 0, '', 18);
INSERT INTO `task` VALUES (436, '常用端口扫描', 2, 1, '', '', 0, 8000, '192.168.43.1', 18);
INSERT INTO `task` VALUES (468, '操作系统识别', 0, 4, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (466, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (435, '主机扫描', 0, 0, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (434, '操作系统识别', 0, 4, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (433, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (432, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (431, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (465, '安全漏洞扫描', 2, 5, '', '', 0, 0, '192.168.43.1', 18);
INSERT INTO `task` VALUES (430, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (429, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (428, '常用端口扫描', 2, 1, '', '', 0, 8000, '192.168.43.1', 18);
INSERT INTO `task` VALUES (427, '主机扫描', 0, 0, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (423, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (426, '弱口令扫描', 0, 3, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (425, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (422, '主机扫描', 2, 0, '192.168.43.1', '192.168.43.255', 0, 0, '', 18);
INSERT INTO `task` VALUES (442, '主机扫描', 2, 0, '192.168.43.1', '192.168.43.255', 0, 0, '', 18);
INSERT INTO `task` VALUES (424, '主机扫描', 2, 0, '192.168.43.1', '192.168.43.255', 0, 0, '', 18);
INSERT INTO `task` VALUES (464, '常用端口扫描', 0, 1, '', '', 0, 0, '', 18);
INSERT INTO `task` VALUES (467, '选定端口扫描', 2, 2, '', '', 1, 200, '192.168.43.1', 18);
INSERT INTO `task` VALUES (472, '常用端口扫描', 0, 1, '', '', 0, 0, '192.168.43.1', 18);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `userID` int(10) NOT NULL AUTO_INCREMENT,
  `userName` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userPass` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userRole` int(6) NOT NULL,
  `phoneNum` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `registTime` timestamp(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`userID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 55 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (18, 'alanZhou', 'SFFXJDPm4ym+uxnrNgqqgg==', 1, '17860527697', '145787878920@126.com', '2021-05-21 19:18:22.263097');
INSERT INTO `user` VALUES (54, '朱开山', 't/aRIwGecohkodsKc5XHRw==', 1, '13522214445', '41478544688@163.com', '2021-05-21 19:22:55.258712');

-- ----------------------------
-- Table structure for vul
-- ----------------------------
DROP TABLE IF EXISTS `vul`;
CREATE TABLE `vul`  (
  `vulID` int(11) NOT NULL AUTO_INCREMENT,
  `vulName` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `vulDesp` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vulResultTime` timestamp(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `destHostIP` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `taskID` int(10) NOT NULL,
  `userID` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`vulID`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 89 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of vul
-- ----------------------------
INSERT INTO `vul` VALUES (78, '弱口令', '长度过短 | 无数字 | 无字母 | 有横向连续字符串 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 14:56:45', '', 134, 18);
INSERT INTO `vul` VALUES (79, '弱口令', '长度过短 | 无数字 | 无字母 | 有横向连续字符串 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 14:56:45', '', 134, 51);
INSERT INTO `vul` VALUES (80, '弱口令', '长度过短 | 无数字 | 无字母 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 14:59:18', '', 445, 54);
INSERT INTO `vul` VALUES (81, '弱口令', '长度过短 | 无数字 | 无字母 | 有横向连续字符串 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 15:04:16', '', 470, 18);
INSERT INTO `vul` VALUES (82, '弱口令', '长度过短 | 无数字 | 无字母 | 有横向连续字符串 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 15:04:16', '', 470, 51);
INSERT INTO `vul` VALUES (83, '弱口令', '长度过短 | 无数字 | 无字母 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 15:04:16', '', 470, 54);
INSERT INTO `vul` VALUES (84, '弱口令', '长度过短 | 无数字 | 无字母 | 有横向连续字符串 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 15:08:51', '', 450, 18);
INSERT INTO `vul` VALUES (85, '弱口令', '长度过短 | 无数字 | 无字母 | 有横向连续字符串 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 15:08:51', '', 450, 51);
INSERT INTO `vul` VALUES (86, '弱口令', '长度过短 | 无数字 | 无字母 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-12 15:08:51', '', 450, 54);
INSERT INTO `vul` VALUES (87, '弱口令', '长度过短 | 无数字 | 无字母 | 有斜向连续字符串 | 有相同连续字符串 | ', '2021-05-21 20:25:21', '', 470, 18);
INSERT INTO `vul` VALUES (88, '弱口令', '长度过短 | 无数字 | 无字母 | 有斜向连续字符串 | 有字母顺序连续字符串 | 有相同连续字符串 | ', '2021-05-21 20:25:21', '', 470, 54);

-- ----------------------------
-- Table structure for weakpwd
-- ----------------------------
DROP TABLE IF EXISTS `weakpwd`;
CREATE TABLE `weakpwd`  (
  `weakPwdID` int(10) NOT NULL AUTO_INCREMENT,
  `weakPwdType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`weakPwdID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of weakpwd
-- ----------------------------
INSERT INTO `weakpwd` VALUES (1, '长度过短');
INSERT INTO `weakpwd` VALUES (2, '无数字');
INSERT INTO `weakpwd` VALUES (3, '无字母');
INSERT INTO `weakpwd` VALUES (4, '无小写字母');
INSERT INTO `weakpwd` VALUES (5, '无大写字母');
INSERT INTO `weakpwd` VALUES (6, '无特殊符号');
INSERT INTO `weakpwd` VALUES (7, '有横向连续字符串');
INSERT INTO `weakpwd` VALUES (8, '有斜向连续字符串');
INSERT INTO `weakpwd` VALUES (9, '有字母顺序连续字符串');
INSERT INTO `weakpwd` VALUES (10, '有相同连续字符串');

-- ----------------------------
-- Triggers structure for table host
-- ----------------------------
DROP TRIGGER IF EXISTS `resultTime`;
delimiter ;;
CREATE TRIGGER `resultTime` BEFORE INSERT ON `host` FOR EACH ROW begin
         set new.resultTime = now();
end
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table port
-- ----------------------------
DROP TRIGGER IF EXISTS `portResultTime`;
delimiter ;;
CREATE TRIGGER `portResultTime` BEFORE INSERT ON `port` FOR EACH ROW begin
         set new.portResultTime = now();
end
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table user
-- ----------------------------
DROP TRIGGER IF EXISTS `registTime`;
delimiter ;;
CREATE TRIGGER `registTime` BEFORE INSERT ON `user` FOR EACH ROW begin
         set new.registTime = now();
end
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table vul
-- ----------------------------
DROP TRIGGER IF EXISTS `vulResultTime`;
delimiter ;;
CREATE TRIGGER `vulResultTime` BEFORE INSERT ON `vul` FOR EACH ROW begin
         set new.vulResultTime = now();
end
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
